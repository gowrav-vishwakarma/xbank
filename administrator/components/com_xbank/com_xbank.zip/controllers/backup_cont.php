<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
class backup_cont extends CI_Controller{

        function index() {
        set_time_limit(5000);
        // Load the DB utility class
        $this->load->dbutil();

// Backup your entire database and assign it to a variable
        $backup = & $this->dbutil->backup();

// Load the file helper and write the file to your server
//        $this->load->helper('file');
//        write_file('./backups/mybackup.gz', $backup);

// Load the download helper and send the file to your desktop
        $this->load->helper('download');
        force_download('jayasoft_'.  getNow("Y-m-d").'.gz', $backup);

//        delete_files('./backups/');
         re("com_xbank.index", " Database Backup taken Successfully ");
    }


}
?>
