<?php
/*------------------------------------------------------------------------
# com_xcideveloper - Seamless merging of CI Development Style with Joomla CMS
# ------------------------------------------------------------------------
# author    Xavoc International / Gowrav Vishwakarma
# copyright Copyright (C) 2011 xavoc.com. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://www.xavoc.com
# Technical Support:  Forum - http://xavoc.com/index.php?option=com_discussions&view=index&Itemid=157
-------------------------------------------------------------------------*/
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
?><?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class com_xbank extends CI_Controller {

	function __construct()
	{
		parent::__construct();
	}

	function index()
	{

            xDeveloperToolBars::getDefaultToolBar();
//            $document = JFactory::getDocument();
//            $script  ="shortcut.add('Alt+g',function() {
//	window.open('index.php?option=com_xbank&task=setdate_cont.setDateTimeForm', 'Set Date Window',
//        'menubar=no,location=yes,resizable=no,scrollbars=yes,status=yes,height=400,width=650,alwaysRaised=yes');
//            });";
//            $this->jq->addDomReadyScript($script);

//            $this->load->model('sample');
            $data['result']=array('a'=>'b');
            $this->load->view('welcome.html',$data,false,true);

	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */