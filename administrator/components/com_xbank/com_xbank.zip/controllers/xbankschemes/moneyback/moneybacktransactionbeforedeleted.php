<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
//$diff = my_date_diff($closing->halfyearly ,$t->updated_at);
//    if($diff['months_total'] >= 1){
//        throw new Exception("transaction cannot be deleted after closing has run");
//     }
?>
