<?php

/* ------------------------------------------------------------------------
  # com_xcideveloper - Seamless merging of CI Development Style with Joomla CMS
  # ------------------------------------------------------------------------
  # author    Xavoc International / Gowrav Vishwakarma
  # copyright Copyright (C) 2011 xavoc.com. All Rights Reserved.
  # @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
  # Websites: http://www.xavoc.com
  # Technical Support:  Forum - http://xavoc.com/index.php?option=com_discussions&view=index&Itemid=157
  ------------------------------------------------------------------------- */
// no direct access
defined('_JEXEC') or die('Restricted access');
?><?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

jimport('joomla.html.toolbar');

class xDeveloperToolBars extends JObject {

    function getDefaultToolBar() {
        $xc = new xConfig('toolbar');
        JToolBarHelper::title('xBank Software by Xavoc International (xavoc.com)', 'generic.png');
        $u = JFactory::getUser();
        if ($u->username == 'admin')
            JToolBarHelper::addNewX("config_cont.index", "Configurations");

        // IF DEFAULT BRANCH IS NOT CREATED, SHOW THIS TOOLBAR
        $b = new Branch();
        $b->get();
        if ($b->result_count() == 0) {
            JToolBarHelper::addNewX('branch_cont.addnewbranch', 'Setup Default Branch');
        } else {

            if ($xc->getkey('branch_toolbar'))
                JToolBarHelper::addNewX('branch_cont.dashboard', 'Branches');
            if ($xc->getkey('schemes_toolbar'))
                JToolBarHelper::addNewX('schemes_cont.dashboard', 'Schemes');
            if ($xc->getkey('staff_toolbar'))
                JToolBarHelper::addNewX('staff_cont.dashboard', 'Staff');
            if ($xc->getkey('member_toolbar'))
                JToolBarHelper::addNewX('member_cont.dashboard', 'Member');
            if ($xc->getkey('agent_toolbar'))
                JToolBarHelper::addNewX('agent_cont.dashboard', 'Agent');
            if ($xc->getkey('accounts_toolbar'))
                JToolBarHelper::addNewX('accounts_cont.index', 'Accounts');
            if ($xc->getkey('transaction_toolbar'))
                JToolBarHelper::addNewX('transaction_cont.index', 'Transactions');
            if ($xc->getkey('report_toolbar'))
                JToolBarHelper::addNewX('report_cont.dashboard', 'Reports');
            if ($xc->getkey('setdate_toolbar'))
                JToolBarHelper::addNewX('setdate_cont.setDateTimeForm', 'SetDate');
//             if ($u->usertype == 'Super Administrator' || $u->usertype == 'Administrator')
            JToolBarHelper::addNewX('backup_cont.index', 'Backup');
            JToolBarHelper::addNewX('search_cont.dashboard', 'Search');
        }
        JToolBarHelper::preferences(JRequest::getCmd('option'), '500');
    }

    function getBranchManagementToolBar() {
        JToolBarHelper::title('Manage Your Branches Here', 'generic.png');
        $u = JFactory::getUser();
        if ($u->username == 'admin')
            JToolBarHelper::addNewX('branch_cont.addnewform', 'New Branch');
        JToolBarHelper::cancel('com_xbank.index', 'cancle');
    }

    function getSchemesManagementToolBar() {
        JToolBarHelper::title('Manage Your Schemes Here', 'generic.png');
        $u = JFactory::getUser();
        if ($u->usertype == 'Super Administrator' || $u->usertype == 'Administrator')
            JToolBarHelper::addNewX('schemes_cont.addnewform', 'New Scheme');
        JToolBarHelper::cancel('com_xbank.index', 'cancle');
    }

    function getMemberManagementToolBar() {
        JToolBarHelper::title('Manage Branch Members Here', 'generic.png');
        JToolBarHelper::addNewX('member_cont.addmemberform', 'New Member');
        JToolBarHelper::cancel('com_xbank.index', 'cancel');
    }

    function getAgentManagementToolBar() {
        JToolBarHelper::title('Manage Branch Agent Here', 'generic.png');
        JToolBarHelper::addNewX('agent_cont.createAgentform', 'New Agent');
        JToolBarHelper::cancel('com_xbank.index', 'cancel');
    }

    function getStaffManagementToolBar() {
        JToolBarHelper::title('Manage Branch Staff Here', 'generic.png');
        JToolBarHelper::addNewX('staff_cont.createStaffform', 'New Staff');
        JToolBarHelper::cancel('com_xbank.index', 'cancel');
    }

    function getAccountsManagementToolBar() {
        JToolBarHelper::title('Manage Your Accounts Here', 'generic.png');
        JToolBarHelper::addNewX('accounts_cont.NewAccountForm', 'New Account');
        JToolBarHelper::cancel('com_xbank.index', 'cancle');
    }

    function getTransactionManagementToolBar() {
        JToolBarHelper::title('Do Transactions Here', 'generic.png');
        JToolBarHelper::addNewX('transaction_cont.deposit', 'Deposit');
        JToolBarHelper::addNewX('transaction_cont.withdrawl', 'Withdraw');
        JToolBarHelper::addNewX('transaction_cont.jv', 'JV');
        JToolBarHelper::cancel('com_xbank.index', 'cancle');
    }

    function getSearchManagementToolBar() {
        JToolBarHelper::title('Search Members and Accounts Here', 'generic.png');
        JToolBarHelper::addNewX('search_cont.searchMemberForm', 'Member Search');
        JToolBarHelper::addNewX('search_cont.searchAccountForm', 'Account Search');
        JToolBarHelper::cancel('com_xbank.index', 'cancel');
    }

    function onlyCancel($toGo, $text='cancel', $title="") {
        JToolBarHelper::title($title, 'generic.png');
        JToolBarHelper::cancel($toGo, $text);
    }

    function configToolBar() {
        JToolBarHelper::title('Manage Configurations Here', 'generic.png');
        JToolBarHelper::preferences('com_xbank', '500');
        JToolBarHelper::cancel('com_xbank.index');
    }

    function configEditToolBar($configFile) {
        JToolBarHelper::title("Edit $configFile Config Here", 'generic.png');
        JToolBarHelper::save('config_cont.saveConfig');
        JToolBarHelper::cancel('config_cont.index');
    }

    function getReportManagementToolBar() {
        JToolBarHelper::title('View Reports Here', 'generic.png');
        JToolBarHelper::addNewX('report_cont.balanceSheetForm', 'Balance Sheet');
        JToolBarHelper::addNewX('report_cont.pandlForm', 'Profit & Loss A/c');
        JToolBarHelper::addNewX('report_cont.accountstatementform', 'Account Statement');
        JToolBarHelper::addNewX('report_cont.AccountBook', 'Account Books');
        JToolBarHelper::addNewX('report_cont.trialbalanceForm', 'Trial Balance');
        JToolBarHelper::cancel('com_xbank.index', 'cancel');
    }

    function getAccountBookManagementToolBar() {
        JToolBarHelper::title('View AccountBooks Here', 'generic.png');
        JToolBarHelper::addNewX('report_cont.cashBookForm', 'Cash Book');
        JToolBarHelper::addNewX('report_cont.dayBookForm', 'Day Book');
        JToolBarHelper::cancel('report_cont.dashboard', 'cancel');
    }

}

?>