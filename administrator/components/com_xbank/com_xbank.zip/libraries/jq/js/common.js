shortcut.add("Alt+g",function() {
	window.open("index.php?option=com_xbank&task=setdate_cont.setDateTimeForm", "Set Date Window","menubar=no,location=yes,resizable=no,scrollbars=yes,status=yes,height=400,width=650,alwaysRaised=yes");
});

