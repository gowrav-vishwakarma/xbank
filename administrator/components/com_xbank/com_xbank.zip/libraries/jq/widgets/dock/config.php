<?php
/*
 * Created on Oct 30, 2010
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */
 $dock['default']['id']="dock";
 $dock['default']['container']="'.dock-container";
 $dock['default']['items']=array(
 							'<a class="dock-item2" href="#"><span>Home</span><img src="images/home.png" alt="home" /></a> ',
 							'<a class="dock-item2" href="#"><span>Home</span><img src="images/home.png" alt="home" /></a> ',
 							'<a class="dock-item2" href="#"><span>Home</span><img src="images/home.png" alt="home" /></a> ',
 							'<a class="dock-item2" href="#"><span>Home</span><img src="images/home.png" alt="home" /></a> ',
 							'<a class="dock-item2" href="#"><span>Home</span><img src="images/home.png" alt="home" /></a> '
 							);
?>
