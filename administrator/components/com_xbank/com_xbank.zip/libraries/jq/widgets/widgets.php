<?php
/*
 * Created on Oct 17, 2010
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */
interface JQWidgets{
//	public function addCss($cssArray);
//	public function addJs($jsArray);
	public function display();
	
}
?>
