<?php

class Account extends DataMapper {

    var $table = 'xaccounts';
    var $has_one = array(
        'branch' => array(
            'class' => 'branch',
            'join_other_as' => 'branch',
            'join_table' => 'jos_xaccount',
            'other_field' => 'accounts'
        ),
        'member' => array(
            'class' => 'member',
            'join_other_as' => 'member',
            'join_table' => 'jos_xaccount',
            'other_field' => 'accounts'
        ),
        'scheme' => array(
            'class' => 'scheme',
            'join_other_as' => 'scheme',
            'join_table' => 'jos_xaccount',
            'other_field' => 'accounts'
        ),
        'opennedbystaff' => array(
            'class' => 'staff',
            'join_other_as' => 'staff',
            'join_table' => 'jos_xaccount',
            'other_field' => 'accountsopenned'
        ),
        'agent' => array(
            'class' => 'agent',
            'join_other_as' => 'agent',
            'join_table' => 'jos_xaccount',
            'other_field' => 'accountsopenned'
        )
    );
    var $has_many = array(
        'premiums' => array(
            'class' => 'premium',
            'join_self_as' => 'accounts',
            'join_table' => 'jos_xpremiums',
            'other_field' => 'account'
        ),
        'transactions' => array(
            'class' => 'transaction',
            'join_self_as' => 'accounts',
            'join_table' => 'jos_xtransactions',
            'other_field' => 'account'
        ),
        'documents' => array(
            'class' => 'document',
            'join_self_as' => 'accounts',
            'join_other_as' => 'documents',
            'join_table' => 'jos_xdocuments_submitted',
            'other_field' => 'submited_in_accounts'
        )
    );
    
   
    public static function getAccountForCurrentBranch($ac,$addCodeInfront=true){
        if($addCodeInfront){
			$acc=Branch::getCurrentBranch()->Code.SP.$ac;
			$returnAccount=new Account();
                        $returnAccount->where("branch_id",Branch::getCurrentBranch()->id);
                        $returnAccount->where("AccountNumber",$acc)->get();
			if($returnAccount->result_count() == 0){
//				echo $acc . " Not found searching " . $AccountNumber . "<br>";
				$acc=$ac;
//				$returnAccount=Doctrine::getTable("Accounts")->findOneByBranch_idAndAccountnumber(Branch::getCurrentBranch()->id,$acc);
                                $returnAccount=new Account();
                                $returnAccount->where("branch_id",Branch::getCurrentBranch()->id);
                                $returnAccount->where("AccountNumber",$acc)->get();
			}
		}
		else{
//			$returnAccount=Doctrine::getTable("Accounts")->findOneByBranch_idAndAccountnumber(Branch::getCurrentBranch()->id,$AccountNumber);
//			print_r($returnAccount);
                        $returnAccount=new Account();
                        $returnAccount->where("branch_id",Branch::getCurrentBranch()->id);
                        $returnAccount->where("AccountNumber",$ac)->get();
                }
		return $returnAccount;
        
    }
        
}


?>