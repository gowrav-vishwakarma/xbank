<?php
class Scheme extends DataMapper {
    var $table='xschemes';
    var $has_one=array(
        'branch'=>array(
            'class'=>'branch',
            'join_other_as'=>'branch',
            'join_table'=>'jos_xschemes',
            'other_field'=>'schemes'
            ),
        'balancesheet'=>array(
            'class'=>'balance_sheet',
            'join_other_as'=>'balance_sheet',
            'join_table'=>'jos_xschemes',
            'other_field'=>'schemes'
            )
        );
    var $has_many = array(
      'accounts'=>array(
            'class'=>'account',
            'join_self_as'=>'schemes',
            'join_table'=>'jos_xaccount',
            'other_field'=>'scheme'
          )
        );
    public static function getScheme($id){
        $s=new Scheme();
        $s->where("id",$id)->get();
        return $s;
           // return Doctrine::getTable("Schemes")->find($id);
        }
}
?>
