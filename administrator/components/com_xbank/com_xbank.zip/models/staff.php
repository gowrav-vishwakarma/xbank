<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class Staff extends DataMapper {

    var $table = "xstaff";
    var $auto_populate_has_one = TRUE;

    var $has_one = array(
        "branch" => array(
            'class' => 'branch',
            'join_other_as' => 'branch',
            'join_table' => 'jos_xstaff',
            'other_field' => 'staffs'
        ),
        'details' => array(
            'class' => 'staff_detail',
            'join_self_as'=>'staff',
            'join_table' => 'jos_xstaff_details',
            'other_field' => 'detailsof'
        )
    );
    var $has_many = array(
        'accountsopenned' => array(
            'class' => 'account',
            'join_table' => 'jos_xaccounts',
            'other_field' => 'opennedbystaff'
        ),
        'membershandled' => array(
            'class' => 'member',
            'join_table' => 'jos_xmembers',
            'other_field' => 'staff',
            'join_self_as'=>'staff'
        ),
        'attendance' => array(
            'class' => 'attendance',
            'join_table' => 'jos_xstaff_attandance',
            'other_field' => 'staff'
        ),
        'salaryreceived' => array(
            'class' => 'staff_payment',
            'join_table' => 'jos_xstaff_payments',
            'other_field' => 'paidto',
            'join_self_as'=>'staff'
        ),
        'transactions' => array(
            'class' => 'transaction',
            'join_table' => 'jos_xtransactions',
            'other_field' => 'bystaff'
        )
        
    );
    var $validation = array(
        'StaffID' => array(
            'label' => 'Staff ID',
            'rules' => array('required', 'trim', 'unique')
        ),
    );


     function getDefaultStaff(){
		$b = Branch::getDefaultBranch();
		$s = $this->db->query("select s.* from jos_xstaff s join jos_users u on s.jid=u.id where s.branch_id = $b->id ")->row();
		return $s;

	}

    public static function getCurrentStaff(){
        if(! $staff_id=JFactory::getUser()->id){
 				return FALSE;
 			}
 			$s = new Staff();
                        $s->get_by_jid(JFactory::getUser()->id);
 			if($s->result_count() == 0){
 				return FALSE;
 			}
 			return $s;
    }

    

}