<?php
/*------------------------------------------------------------------------
# com_xcideveloper - Seamless merging of CI Development Style with Joomla CMS
# ------------------------------------------------------------------------
# author    Xavoc International / Gowrav Vishwakarma
# copyright Copyright (C) 2011 xavoc.com. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://www.xavoc.com
# Technical Support:  Forum - http://xavoc.com/index.php?option=com_discussions&view=index&Itemid=157
-------------------------------------------------------------------------*/
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
?><?php

$lang['ut_test_name']		= 'Test Name';
$lang['ut_test_datatype']	= 'Test Datatype';
$lang['ut_res_datatype']	= 'Expected Datatype';
$lang['ut_result']			= 'Result';
$lang['ut_undefined']		= 'Undefined Test Name';
$lang['ut_file']			= 'File Name';
$lang['ut_line']			= 'Line Number';
$lang['ut_passed']			= 'Passed';
$lang['ut_failed']			= 'Failed';
$lang['ut_boolean']			= 'Boolean';
$lang['ut_integer']			= 'Integer';
$lang['ut_float']			= 'Float';
$lang['ut_double']			= 'Float'; // can be the same as float
$lang['ut_string']			= 'String';
$lang['ut_array']			= 'Array';
$lang['ut_object']			= 'Object';
$lang['ut_resource']		= 'Resource';
$lang['ut_null']			= 'Null';
$lang['ut_notes']			= 'Notes';


/* End of file unit_test_lang.php */
/* Location: ./system/language/english/unit_test_lang.php */