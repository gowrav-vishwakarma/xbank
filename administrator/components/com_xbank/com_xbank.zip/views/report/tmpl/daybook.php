<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

$debit = 0;$credit = 0;
$openingbalance = $OpeningBalance + $transactionOpeningBalance;
$debitopeningbalance = ($openingbalance > 0 ? round(abs($openingbalance),2):'');
$creditopeningbalance = ($openingbalance < 0 ? round(abs($openingbalance),2):'');

$html = "<table class='ui-widget ui-widget-content ui-corner-all' width='100%'>";
$html .="<tr class='ui-widget-header'><td colspan=4 align='center'>DAY BOOK</td></tr>";
$html .="<tr class='ui-widget-header'><td colspan=4 align='center'>for ".date("j M, Y", strtotime(inp("dateFrom")))."</center></tr>";
$html .="<tr class='ui-widget-header'>";
foreach (array_values($keyandvalues) as $header) {
    $html .="<th>$header</th>";
}
$html .="</tr>";
//$html .="<tr>";
//$html .="<td>".inp("dateFrom")."</td>";
//$html .="<td><b>".($openingbalance > 0 ? "TO Opening Balance" : "BY Opening Balance")."</b></td>";
//$html .="<td></td><td></td><td><b>". $debitopeningbalance."</b></td><td><b>".$creditopeningbalance ."</b></td>";
//$html .="</tr>";
foreach ($results as $rs) {
    $html .= "<tr>";
    foreach (array_keys($keyandvalues) as $field) {
        $field = trim($field);
        if($field =="voucher_no")
            $html .=( "<td><a class='alertinwindow' href='index.php?option=com_xbank&task=report_cont.transactionDetails&vn=".($rs->$field)."&format=raw/0'>" . ($rs->$field) . "</a></td>");
        else
            $html .= ( "<td>" . ($rs->$field) . "</td>");
//        if($field == "Debit")
//            $debit +=$rs->$field;
//        if($field == "Credit")
//            $credit +=$rs->$field;
    }
    $html .="</tr>";
}

//$html .="<tr>";
//$html .="<td></td>";
//$html .="<td></td>";
//$html .="<td></td><td></td><td><b>".($debit) ."</b></td><td><b>".($credit) ."</b></td>";
//$html .="</tr>";
//
//$html .="</tr>";
//$html .="<tr>";
//$html .="<td></td>";
//$html .="<td><b>".(($debit + $debitopeningbalance) > ($credit + $creditopeningbalance) ? "BY Closing Balance" : "TO Closing Balance")."</b></td>";
//$html .="<td></td><td></td><td>". (($debit + $debitopeningbalance) > ($credit + $creditopeningbalance)?'': abs(($debit + $debitopeningbalance) - ($credit + $creditopeningbalance)))."</td>
//    <td>".(($debit + $debitopeningbalance) > ($credit + $creditopeningbalance)? abs(($debit + $debitopeningbalance) - ($credit + $creditopeningbalance)) : '')."</td>";
//$html .="</tr>";
//
//$html .="<tr>";
//$html .="<td></td>";
//$html .="<td></td>";
//$html .="<td></td><td></td><td><b>".((($debit + $debitopeningbalance) > ($credit + $creditopeningbalance)?0: abs(($debit + $debitopeningbalance) - ($credit + $creditopeningbalance)))+($debit + $debitopeningbalance)) ."</b></td>
//    <td><b>".((($debit + $debitopeningbalance) > ($credit + $creditopeningbalance)? abs(($debit + $debitopeningbalance) - ($credit + $creditopeningbalance)) : 0)+($credit + $creditopeningbalance) )."</b></td>";
//$html .="</tr>";

$html .="</table>";

echo $html;
?>

