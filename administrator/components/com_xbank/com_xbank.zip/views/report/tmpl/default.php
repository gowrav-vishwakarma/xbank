<?php
if(isset($contents)) echo $contents;
?>
