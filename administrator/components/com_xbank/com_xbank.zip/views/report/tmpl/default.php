<?php
echo $contents;
?>
