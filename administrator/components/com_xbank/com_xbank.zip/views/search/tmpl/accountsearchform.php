<?php
echo $contents;

?>
