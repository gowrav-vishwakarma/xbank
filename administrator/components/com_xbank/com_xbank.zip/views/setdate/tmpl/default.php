<script type="text/javascript">
     window.opener.location.reload();
</script>
<?php
echo $contents;
?>