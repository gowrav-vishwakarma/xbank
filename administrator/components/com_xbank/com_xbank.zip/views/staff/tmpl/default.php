<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<table width="100%" class="adminlist">
    <thead>
        <tr>
            <th class="title" width="10">#</th>
            <th class="title" width="15">Staff Name</th>
            <th class="title" width="15">Branch Name</th>
<!--            <th class="title">Address</th>
            <th class="title">Phone Number</th>
            <th class="title">Branch</th>-->
            <th class="title">Edit</th>
        </tr>
    </thead>
    <tbody>
        <?php
        jimport('joomla.html.html');
        $i = 0;
        foreach ($staff as $s) :
//            $id = JHTML::_('grid.id', ++$i, $m->id);
//            $published = JHTML::_('grid.published', $m, $i
            ?>
            <tr class="row<?php echo ++$i ?>">
                <td><?php echo $s->id; ?></td>
                <td><?php echo $s->StaffID; ?></td>
                <td><?php echo $s->branch->Name; ?></td>
<!--                <td class="title" align="center"><?php echo $m->PermanentAddress; ?></td>
                <td class="title" align="center"><?php echo $m->PhoneNos; ?></td>
                <td class="title" align="center"><?php echo $m->registeredinbranch->Name; ?></td>-->
                <td class="title" align="center"><a title="Edit Staff <?php echo $s->StaffID; ?>" href="index.php?option=com_xbank&task=staff_cont.edit&id=<?php echo $s->id; ?>&format=raw" class="alertinwindow">Edit</a></td>
            </tr>
            <?php
        endforeach;
        ?>
    </tbody>
</table>

<?php $x = ($start-$count) < 0 ? 0 : ($start-$count);
      $y = ($start+$count) > $i ? $start : ($start+$count);
?>
<p class="ui-widget ui-widget-header"><a style="float:left;" href="<?= site_url()."?option=com_xbank&task=staff_cont.dashboard&pagestart=".$x ?>">Previous</a>
  <a style="float:right;" href="<?= site_url()."?option=com_xbank&task=staff_cont.dashboard&pagestart=".$y ?>">Next</a><p>
