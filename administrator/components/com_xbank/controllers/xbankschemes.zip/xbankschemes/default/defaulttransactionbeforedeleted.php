<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
//$diff = my_date_diff($closing->yearly ,$t->updated_at);
//    if($diff['years'] >= 1){
//        throw new Exception("transaction cannot be deleted after closing has run");
//     }
?>
