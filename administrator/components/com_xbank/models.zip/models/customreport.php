<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
class customreport extends DataMapper{
    var $table = "xreports";
}
?>
