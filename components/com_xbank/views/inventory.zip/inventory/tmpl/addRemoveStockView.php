<table width="100%" border="1" class="ui-widget">
  <tr class="ui-widget-header">
    <td>S.No.</td>
    <td>Item Name</td>
    <td>Stock Added/Removed Date</td>
    <td>Quantity</td>
    <td>Stock Status</td>
    <td>Edit</td>


  </tr>
 <?php
 $i=1;
   foreach($result as $r)
  {
 ?>
        <tr>
        <td><?php echo $i;?></td>
        <td><?php echo $r->itemName;?></td>
        <td><?php echo $r->StockAllotedDate;?></td>
        <td><?php echo $r->Quantity; ?></td>
        <td><?php echo ($r->StockStatus ==1)?"Added" : "Removed"; ?></td>
        <td><a href="index.php?//mod_inventory/inventory_cont/editNewStockForm/<?php echo $r->id ?>">Edit</a></td>
        </tr>
<?php
$i++;
  } // end
?>
</table>
