<?php
echo $contents;
?>