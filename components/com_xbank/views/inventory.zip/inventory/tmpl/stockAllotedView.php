<table width="100%" border="1" class="ui-widget">
  <tr class="ui-widget-header">
    <td>S.No.</td>
    <td>Item Name</td>
    <td>Stock Alloted Date</td>
    <td>Quantity Alloted</td>
    <td>Branch Name</td>


  </tr>
 <?php
 $i=1;
   foreach($result as $r)
  {
 ?>
        <tr>
        <td><?php echo $i;?></td>
        <td><?php echo $r->itemName;?></td>
        <td><?php echo $r->StockAllotedDate;?></td>
        <td><?php echo $r->QuantityAlloted; ?></td>
        <td><?php echo $r->BranchName; ?></td>

        </tr>
<?php
$i++;
  } // end
?>
</table>
