<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * mod_accounts/account_cont Controller : module to perform various Accounts based function
 * 
 * This Module is linked with Accounts Menu, by cliecking this you can manage all your Accounts realated functions
 * 
 * 
 * @todo Dashboard Design :: what to show
 * 
 * accounts_cont class extended from CI Controller
 * 
 * @package    xBank
 * @subpackage xModules
 * @author     Gowrav  <GowravVishwakarma@gmail.com>
 * @version    1.0.0
 * @category Timestampable
 */
class accounts_cont extends CI_Controller {

    function __construct() {
        parent::__construct();
    }

    /**
     * default function to called when {@link accounts_cont accounts_cont} is called
     * @todo design the dashboard
     */
    function index() {
        xDeveloperToolBars::getAccountsManagementToolBar();
        $data['records'] = $this->db->query("select s.Name as `Name`,count(a.AccountNumber) as Accounts, s.id as ID from jos_xaccounts a join jos_xschemes s on a.schemes_id=s.id where a.branch_id=" . Branch::getCurrentBranch()->id . " group By s.Name")->result();
        $this->load->view("accounts.html", $data);
        $this->jq->getHeader();
    }

    /**
     *
     * @param <type> $id
     * function to view the Cr and Dr balance of accounts under scheme with id as $id
     */
    function accountForScheme() {
        xDeveloperToolBars::onlyCancel("accounts_cont.index", "cancel", "Check your Accounts here");
        $id = JRequest::getVar("id");
        $data['accounts'] = $this->db->query("select a.AccountNumber as AccountNo,a.CurrentBalanceCr as Cr, a.CurrentBalanceDr as Dr from jos_xaccounts a  where a.schemes_id =" . $id . " and a.branch_id=" . Branch::getCurrentBranch()->id)->result();
//        $data['contents'] = $this->load->view("accdashboard", $data);
        JRequest::setVar("layout", "accountsdashboard");
        $this->load->view("accounts.html", $data);
        $this->jq->getHeader();
    }

    /**
     * function to create new Account <B>FORM</b> no new account is actually created by this function just the form
     * sends data to {@link NewAccountCreate NewAccountCreate function}
     *
     * STEPS
     * - gets all schemes by {@link Schemes::getAllSchemesForCurrentBranch}
     * {@source 1 5}
     * - generate Form
     *
     */
    function NewAccountForm() {
        xDeveloperToolBars::onlyCancel("accounts_cont.index", "cancel", "Open Accounts here");
        global $com_params;

        $b = Branch::getCurrentBranch();
        $branchCode = $b->Code;

        $this->jq->addInfo("Agent", "Default branch Agent");
        $defaultAgent = $this->jq->flashMessages(true);

        $this->jq->addInfo("Member", "Member Details");
        $member = $this->jq->flashMessages(true);

        $this->jq->addInfo("Accounts", "Accounts Details");
        $accounts = $this->jq->flashMessages(true);

        $documents = $this->db->query("Select * from jos_xdocuments")->result();
        $i = 1;

        $schemeTypes = explode(",", $com_params->get('ACCOUNT_TYPES'));
        $i = 0;


        foreach ($schemeTypes as $st) {
            include(xBANKSCHEMEPATH . "/" . strtolower($st) . "/" . strtolower($st) . "accountopenform.php");

//            echo xBANKSCHEMEPATH . "/" . strtolower($st) . "/" . strtolower($st) . "accountopenform.php"."<br>";
        }



        $data['tabs'] = $this->jq->getTab(1);
        JRequest::setVar("layout", "accountopenform");
        $this->load->view('accounts.html', $data);
        $this->jq->getHeader();
    }

    function confirmAccountCreateForm() {

//        Staff::accessibleTo(POWER_USER);
        $err = false;
        $msg = "";
        $debitAccount = array();
        $creditAccount = array();
        try {
            include(xBANKSCHEMEPATH . "/" . strtolower(inp("CurrentScheme")) . "/" . strtolower(inp("CurrentScheme")) . "accountconfirm.php");
        } catch (Exception $e) {
            $msg = "Not the usual way to make account .. check the form again for errors<br>falsefalse";
        }
        echo $msg;
    }

    /**
     * Actually creates an Account
     *
     * takes data from NewAccountForm function and performs following action
     *  - get the given agent if not found then getDefault Agent for CURRENT BRANCH AGENT
     *  - set all input data
     *  - save account
     *  - these accounts are not Default so <b>DefaultAC=0</b>
     *
     * @todo what about RD AND Daily deposit type accounts
     */
    function NewAccountCreate() {
        $debitAccount = array();
        $creditAccount = array();
        try {
            $this->db->trans_begin();
            $a = inp('Agents_Id');



            $Ac = new Account();
            $Ac->member_id = inp('UserID');
            $Ac->schemes_id = inp('AccountType');

            $Agent = new Agent($a);
//            $Agent->where('member_id', $a)->get();
            if ($Agent->result_count() == 0) {
                $Agent = null; //Branch::getDefaultAgent();
            }


            $Ac->agents_id = $Agent->id; // TODO - Can any other Agent give you id or only your own agent can give you this ...
            $Ac->staff_id = Staff::getCurrentStaff()->id; //Current_Staff::staff()->id;
            $Ac->branch_id = Branch::getCurrentBranch()->id;
            $Ac->ActiveStatus = inp('ActiveStatus');
            $Ac->Nominee = inp('Nominee');  // IMP : used as guarantor for loan accounts
            $Ac->NomineeAge = inp('NomineeAge');
            $Ac->RelationWithNominee = inp('RelationWithNominee');
            $Ac->MinorNomineeDOB = "'" . inp('MinorNomineeDOB') . "'";
            $Ac->MinorNomineeParentName = inp('MinorNomineeParentName');   // IMP : used as guarantor Address for loan accounts
            $Ac->ModeOfOperation = (inp('ModeOfOperation') == "") ? "Self" : inp('ModeOfOperation');
            $Ac->AccountNumber = inp('AccountNumber');
            $Ac->RdAmount = inp("rdamount");
            $Ac->DefaultAC = '0';
            $Ac->LastCurrentInterestUpdatedAt = getNow();
            $Ac->save();


            $Ac = new Account($Ac->id);
            switch ($Ac->scheme->SchemeType) {
                case ACCOUNT_TYPE_DEFAULT:

                    break;
                case ACCOUNT_TYPE_BANK:
                    $Ac->RdAmount = inp("rdamount");
                    break;
                case ACCOUNT_TYPE_FIXED:
                    $Ac->RdAmount = inp("initialAmount");

                    $sc = Scheme::getScheme(inp("AccountType"));
                    if ($sc->InterestToAnotherAccount == 1) {
                        $iac = Account::getAccountForCurrentBranch(inp("InterestTo"));
                        $Ac->InterestToAccount = $iac->id;
                    }
                    break;
                case ACCOUNT_TYPE_LOAN:
//                    $Ac->dealer_id = inp('Dealer');
                    $accountAmt = LOAN_AMOUNT;
                    $Ac->$accountAmt = inp('initialAmount');
                    $Ac->LoanInsurranceDate = inp("LoanInsurranceDate");
                    if (inp("LoanAgSecurity") == 1) {
                        $s = inp('SecurityAccount');
                        $account = new Account();
                        $account->where('id', $s)->get();
                        //$account = Doctrine::getTable("Accounts")->findOneById(inp("SecurityAccount"));
                        $account->LockingStatus = true;
                        $account->save();
                        $Ac->LoanAgainstAccount = $account->id;
                    }

                    break;
                case ACCOUNT_TYPE_RECURRING:
                    $Ac->RdAmount = inp("rdamount");
                    $Ac->collector_id = inp("CollectorID");
                    $Ac->CollectorAccountNumber = inp("CollectorAccountNumber");
                    break;
                case ACCOUNT_TYPE_DDS:
                    $Ac->RdAmount = inp("rdamount");
                    break;
                case ACCOUNT_TYPE_CC:
                    $Ac->{CC_AMOUNT} = inp("initialAmount");
                    break;
            }

            $Ac->save();
            log_message('error', __FILE__ . " " . __FUNCTION__ . " $Ac->AccountNumber with id $Ac->id created from " . $this->input->ip_address());

            $voucherNo = array('voucherNo' => Transaction::getNewVoucherNumber(), 'referanceAccount' => $Ac->id);
            $Ac = new Account($Ac->id);

//			Commission transfer		
            if (($Ac->scheme->AccountOpenningCommission != "" OR $Ac->scheme->AccountOpenningCommission != null) AND ($Ac->agents_id != null OR $Ac->agents_id != 0)) {
                switch ($Ac->scheme->SchemeType) {
                    case ACCOUNT_TYPE_DEFAULT:

                        break;
                    case ACCOUNT_TYPE_BANK:

                        // GIVES TOTAL COMMISSION AMOUNT....THEREAFTER DISTRIBUTE IT TO ALL LEVELS
//                        $commissionAmount = getComission($Ac->scheme->AccountOpenningCommission, OPENNING_COMMISSION);
                        break;
                    case ACCOUNT_TYPE_FIXED:
                        $commissionAmount = getComission($Ac->scheme->AccountOpenningCommission, OPENNING_COMMISSION);
                        $commissionAmount = $commissionAmount * inp("initialAmount") / 100.00;
                        break;
                    case ACCOUNT_TYPE_LOAN:
                        $commissionAmount = getComission($Ac->scheme->AccountOpenningCommission, OPENNING_COMMISSION);
                        break;
                    case ACCOUNT_TYPE_RECURRING:
                        $commissionAmount = getComission($Ac->scheme->AccountOpenningCommission, OPENNING_COMMISSION);
                        $commissionAmount = $commissionAmount * inp("initialAmount") / 100.00;
                        break;
                    case ACCOUNT_TYPE_DDS:
                        $commissionAmount = getComission($Ac->scheme->AccountOpenningCommission, OPENNING_COMMISSION);
                        break;

                    case ACCOUNT_TYPE_DHANSANCHAYA:
                        $commissionAmount = getComission($Ac->scheme->AccountOpenningCommission, OPENNING_COMMISSION);
                        break;

                    case ACCOUNT_TYPE_MONEYBACK:
                        $commissionAmount = getComission($Ac->scheme->AccountOpenningCommission, OPENNING_COMMISSION);
                        break;
                }
                $ag = new xConfig("agent");

                if ($Agent->result_count() == 0) {
                    $Agent = null; //Branch::getDefaultAgent();
                } else {

                    $levels = $ag->getKey("number_of_agent_levels");

                    if ($levels > 1 && !$ag->getKey("manually_promote_agent"))
                        $Agent->updateAncestors();
                    else {
                        $agentAncestor = $Agent;
                        while($agentAncestor->id){
                        $agentAncestor->BusinessCreditPoints = $agentAncestor->BusinessCreditPoints + $Ac->scheme->SchemePoints / 100 * $Ac->RdAmount;
                        $agentAncestor->CumulativeBusinessCreditPoints += $Ac->scheme->SchemePoints / 100 * $Ac->RdAmount;
                        $agentAncestor->save();
                        $agentAncestor = $agentAncestor->sponsor;
                        }
                    }
                }


                if ($Agent->result_count() && $commissionAmount != 0) {
                    $s = $Agent->AccountNumber;
                    $agents = new Account();
                    $agents->where('AccountNumber', $s)->get();
                    // $agents = Doctrine::getTable("Accounts")->findOneByAccountNumber($Agent->AccountNumber);

                    $totalCommission = $commissionAmount;

                    do {

                        $agentSponsorCommission = json_decode($Ac->scheme->AgentSponsorCommission, true);
                        $agentSponsorCommission = $agentSponsorCommission[$Agent->Rank];
                        $commissionAmount = ($ag->getKey("number_of_agent_levels") > 0 ? (getComission($agentSponsorCommission, OPENNING_COMMISSION) / 100 * $totalCommission) : $commissionAmount);


                        if ($agents->branch_id != Branch::getCurrentBranch()->id) {
                            $s = $agents->branch_id;
                            $otherbranch = new Branch();
                            $otherbranch->where('id', $s)->get();

                            $vchNo = array('voucherNo' => Transaction::getNewVoucherNumber(), 'referanceAccount' => $Ac->id);
                            $debitAccount += array(
                                Branch::getCurrentBranch()->Code . SP . COMMISSION_PAID_ON . SP . $Ac->scheme->Name => $commissionAmount,
                            );
                            $creditAccount += array(
                                // get agents' account number
                                //                                            Branch::getCurrentBranch()->Code."_Agent_SA_". $ac->Agents->member_id  => ($amount  - ($amount * 10 /100)),
                                $otherbranch->Code . SP . BRANCH_AND_DIVISIONS . SP . "for" . SP . Branch::getCurrentBranch()->Code => ($commissionAmount - ($commissionAmount * TDS_PERCENTAGE / 100)),
                                Account::getAccountForCurrentBranch(BRANCH_TDS_ACCOUNT)->AccountNumber => ($commissionAmount * TDS_PERCENTAGE / 100),
                            );
                            Transaction::doTransaction($debitAccount, $creditAccount, "Agent Account openning commision Transaction for account $Ac->AccountNumber", TRA_ACCOUNT_OPEN_AGENT_COMMISSION, $vchNo);



                            $vchNo1 = array('voucherNo' => Transaction::getNewVoucherNumber(), 'referanceAccount' => $Ac->id);
                            $debitAccount = array(
                                Branch::getCurrentBranch()->Code . SP . BRANCH_AND_DIVISIONS . SP . "for" . SP . $otherbranch->Code => ($commissionAmount - ($commissionAmount * TDS_PERCENTAGE / 100)),
                            );

                            if ($ag->getKey("transfer_commission_to_agents_account")) {
                                $creditAccount = array(
                                    // get agents' account number
                                    $Agent->AccountNumber => ($commissionAmount - ($commissionAmount * TDS_PERCENTAGE / 100)),
                                );
                            } else {
                                $creditAccount = array(
                                    // get agents' account number
                                    Branch::getCurrentBranch()->Code . SP . COMMISSION_PAYABLE_ON . SP . $Ac->scheme->Name => ($commissionAmount - ($commissionAmount * TDS_PERCENTAGE / 100)),
                                );

                                $agentReport = new Agentcommissionreport();
                                $agentReport->agents_id = $Agent->id;
                                $agentReport->accounts_id = $Ac->id;
                                $agentReport->Commission = $commissionAmount;
                                $agentReport->CommissionPayableDate = getNow("Y-m-d");
                                $agentReport->Narration = "Agent Account opening commission payable for account $Ac->AccountNumber";
                                $agentReport->save();
                            }
                            Transaction::doTransaction($debitAccount, $creditAccount, "Agent Account opening commission for account $Ac->AccountNumber", TRA_ACCOUNT_OPEN_AGENT_COMMISSION, $vchNo1, false, $otherbranch->id);
                        } else {
//                        TO TRANSFER COMMISSION IN LEVELS
                            $debitAccount = array(Branch::getCurrentBranch()->Code . SP . COMMISSION_PAID_ON . $Ac->scheme->Name => $commissionAmount);

                            if ($ag->getKey("transfer_commission_to_agents_account")) {
                                $creditAccount = array(
//                            TRANSFER COMMISSION TO AGENT ACCOUNT
                                    $Agent->AccountNumber => ($commissionAmount - ($commissionAmount * TDS_PERCENTAGE / 100)),
                                    Account::getAccountForCurrentBranch(BRANCH_TDS_ACCOUNT)->AccountNumber => ($commissionAmount * TDS_PERCENTAGE / 100),
                                );
                            } else {
                                $creditAccount = array(
//                            TRANSFER COMMISSION TO COMMISSION PAYABLE ACCOUNT
                                    Branch::getCurrentBranch()->Code . SP . COMMISSION_PAYABLE_ON . SP . $Ac->scheme->Name => ($commissionAmount - ($commissionAmount * TDS_PERCENTAGE / 100)),
                                    Branch::getCurrentBranch()->Code . SP . TDS_PAYABLE => ($commissionAmount * TDS_PERCENTAGE / 100),
                                );

                                $agentReport = new Agentcommissionreport();
                                $agentReport->agents_id = $Agent->id;
                                $agentReport->accounts_id = $Ac->id;
                                $agentReport->Commission = $commissionAmount;
                                $agentReport->CommissionPayableDate = getNow("Y-m-d");
                                $agentReport->Narration = "Agent Account opening commission payable for account $Ac->AccountNumber";
                                $agentReport->save();
                            }
                            $vchNo2 = array('voucherNo' => Transaction::getNewVoucherNumber(), 'referanceAccount' => $Ac->id);
                            Transaction::doTransaction($debitAccount, $creditAccount, "Agent Account openning commision for $Ac->AccountNumber", TRA_ACCOUNT_OPEN_AGENT_COMMISSION, $vchNo2);
                        }
                        $Agent = $Agent->sponsor;
                    } while ($Agent->id);
                }
            }


            switch ($Ac->scheme->SchemeType) {
                case ACCOUNT_TYPE_DEFAULT:
                    break;
                case ACCOUNT_TYPE_BANK:
                    $this->createBankTypeAccount($Ac, $voucherNo);
                    break;
                case ACCOUNT_TYPE_FIXED:
                    $this->createFixedTypeAccount($Ac, $voucherNo);
                    break;
                case ACCOUNT_TYPE_LOAN:
                    $this->createLoanTypeAccount($Ac, $voucherNo);
                    break;
                case ACCOUNT_TYPE_RECURRING:
                    $this->createRecurringTypeAccount($Ac, $voucherNo);
                    break;
                case ACCOUNT_TYPE_DDS:
                    $this->createDDSTypeAccount($Ac, $voucherNo);
                    break;
                case ACCOUNT_TYPE_CC:
                    $this->createCCTypeAccount($Ac, $voucherNo);
                case ACCOUNT_TYPE_DHANSANCHAYA:
                    $this->createDhanSanchayaTypeAccount($Ac, $voucherNo);
                    break;
                case ACCOUNT_TYPE_MONEYBACK:
                    $this->createMoneyBackTypeAccount($Ac, $voucherNo);
            }

            // save the documents submitted
            $documents = $this->db->query("Select * from jos_xdocuments")->result();
            $z = 1;
            foreach ($documents as $d) {

                if (inp("Documents_$z") != "") {
                    $docsSubmitted = new DocumentsSubmitted();
                    $docsSubmitted->accounts_id = $Ac->id;
                    $docsSubmitted->documents_id = inp("Documents_$z");
                    $docsSubmitted->Description = inp("Description_$z");
                    $docsSubmitted->save();
                }
                $z++;
            }
            log_message('error', __FILE__ . " " . __FUNCTION__ . " Documents saved for $Ac->AccountNumber with id $Ac->id from " . $this->input->ip_address());
            $this->db->trans_commit();
            log_message('error', __FILE__ . " " . __FUNCTION__ . " Data commited for $Ac->AccountNumber with id $Ac->id from " . $this->input->ip_address());
        } catch (Exception $e) {
            $this->db->trans_rollback();
            echo $e->getMessage();
            return;
        }

        re("accounts_cont.NewAccountForm", "New Account with Account Number $Ac->AccountNumber has been created sucessfully");
    }

    /**
     * Acatual account already created in NewAcccountCreate function
     * @param <type> $ac
     * @param <type> $voucherNo
     *
     * - function is accessible to POWER_USER
     * - Credit the newly created account and debit the Branch's Cash Account with the initial Amount if Amount != 0
     * - Do the transaction
     */
    function createBankTypeAccount($ac, $voucherNo) {
//        Staff::accessibleTo(POWER_USER);

        /*         if(inp("initialAmount") < $ac->Schemes->MinLimit){
          $ac->ActiveStatus=0;
          $ac->save();
          }
         */
        if (inp("initialAmount") != 0) {
            $debitAccount = array(
                Branch::getCurrentBranch()->Code . SP . CASH_ACCOUNT => inp("initialAmount"),
            );
            $creditAccount = array(
                $ac->AccountNumber => inp("initialAmount"),
            );
            Transaction::doTransaction($debitAccount, $creditAccount, "Initial Saving Amount Deposit in $ac->AccountNumber", TRA_SAVING_ACCOUNT_AMOUNT_DEPOSIT, $voucherNo);
        }
    }

    /**
     * Acatual account already created in NewAcccountCreate function
     * @param <type> $ac
     * @param <type> $voucherNo
     *
     * - function is accessible to POWER_USER
     * - Credit the newly created account and debit the Branch's Cash Account with the initial Amount if Amount != 0
     * - Do the transaction
     */
    function createFixedTypeAccount($ac, $voucherNo) {
//        Staff::accessibleTo(POWER_USER);

        if (inp("initialAmount") != 0) {

            $debitTo = "";
            if (inp("DebitTo")) {
                $debitTo = Account::getAccountForCurrentBranch(inp("DebitTo"));
            }
            if ($debitTo)
                $debitToAccount = inp("DebitTo");
            else
                $debitToAccount = Branch::getCurrentBranch()->Code.SP.CASH_ACCOUNT;
            $debitAccount = array(
                $debitToAccount => inp("initialAmount"),
            );
            $creditAccount = array(
                $ac->AccountNumber => inp("initialAmount"),
            );
            Transaction::doTransaction($debitAccount, $creditAccount, "Initial Fixed Amount Deposit in $ac->AccountNumber", TRA_FIXED_ACCOUNT_DEPOSIT, $voucherNo);
        }
    }

    /**
     * Acatual account already created in NewAcccountCreate function
     * @param <type> $ac
     * @param <type> $voucherNo
     *
     * - function is accessible to POWER_USER
     * - calculate the processing fees. Processing fee rate retrieved from Schemes table
     * - Debit the newly created account
     * - Credit the Branch's Processing Fee Received Account and one of the Bank's account with the processing fees
     * - Do the transaction
     * - Check for the premiums mode from Schemes
     * - Set the premiums with due date
     */
    function createLoanTypeAccount($ac, $voucherNo) {
//        Staff::accessibleTo(POWER_USER);

        $sc = Scheme::getScheme(inp("AccountType"));
        $schemeName = $sc->Name;

        if (inp("initialAmount") != 0) {
            if ($sc->ProcessingFeesinPercent == 1) {
                $processingfee = $sc->ProcessingFees * inp("initialAmount") / 100;
            } else {
                $processingfee = $sc->ProcessingFees;
            }
            $i = inp("InterestTo");
            $loanFromAccount = new Account();
            $loanFromAccount->where('AccountNumber', $i)->get();

            $debitAccount = array(inp("AccountNumber") => inp("initialAmount"),);
            $creditAccount = array(Branch::getCurrentBranch()->Code . SP . PROCESSING_FEE_RECEIVED . $schemeName => $processingfee,);
            $creditAccount +=array(inp("InterestTo") => inp("initialAmount") - $processingfee,); //Interestto is :: loan from account
            Transaction::doTransaction($debitAccount, $creditAccount, "Loan Account Opened " . inp("AccountNumber"), TRA_LOAN_ACCOUNT_OPEN, $voucherNo);
//            }
        }

        switch ($sc->PremiumMode) {
            case RECURRING_MODE_YEARLY:
                $toAdd = " +1 year";
                break;
            case RECURRING_MODE_HALFYEARLY:
                $toAdd = " +6 month";
                break;
            case RECURRING_MODE_QUATERLY:
                $toAdd = " +3 month";
                break;
            case RECURRING_MODE_MONTHLY:
                $toAdd = " +1 month";
                break;
            case RECURRING_MODE_DAILY:
                $toAdd = " +1 day";
                break;
        }

        $lastPremiumPaidDate = getNow("Y-m-d");
        $rate = $sc->Interest;
        $premiums = $sc->NumberOfPremiums;
//        FOR FLAT RATE OF INTEREST
//        $emi = ((inp('initialAmount') * $rate * ($premiums + 1)) / 1200 + inp('initialAmount')) / $premiums;
//        FOR REDUCING RATE OF INTEREST
        $emi = (inp('initialAmount') * ($rate / 1200) / (1 - (pow(1 / (1 + ($rate / 1200)), $premiums))));

        $emi = round($emi);
        for ($i = 1; $i <= $sc->NumberOfPremiums; $i++) {
            $prem = new Premium();
            $prem->accounts_id = $ac->id;
            $prem->Amount = $emi;
//                $prem->Paid=($i <= $premiumsSubmited ) ?  $i : 0 ;
            $prem->Paid = 0;
            $prem->Skipped = 0;
//                $prem->PaidOn=($i <= $premiumsSubmited ) ? getNow() : null ;
            $prem->PaidOn = null;
            $prem->AgentCommissionSend = 0;
//                if($i==1){
//                    $prem->DueDate=getNow("Y-m-d");
//                }else{
            $prem->DueDate = date("Y-m-d", strtotime(date("Y-m-d", strtotime($lastPremiumPaidDate)) . $toAdd));
//                }
            $lastPremiumPaidDate = $prem->DueDate;
//                $prem->AgentCommissionPercentage=getComission($ac->Schemes->AccountOpenningCommission, PREMIUM_COMMISSION,$i);
            $prem->save();
        }
    }

    /**
     * Acatual account already created in NewAcccountCreate function
     * @param <type> $ac
     * @param <type> $voucherNo
     *
     * - function is accessible to POWER_USER
     * - calculate the processing fees. Processing fee rate retrieved from Schemes table
     * - Debit the newly created account with the processing fees
     * - Credit the Branch's Cash Account with the processing fees
     * - Do the transaction
     */
    function createCCTypeAccount($ac, $voucherNo) {
//        Staff::accessibleTo(POWER_USER);

        $sc = Scheme::getScheme(inp("AccountType"));
        $schemeName = $sc->Name;

        if (inp("initialAmount") != 0) {
            $processingfee = $sc->ProcessingFees * inp("initialAmount") / 100;
            $creditAccount = array(
                Branch::getCurrentBranch()->Code . SP . PROCESSING_FEE_RECEIVED . $schemeName => $processingfee,
            );
            $debitAccount = array(
                $ac->AccountNumber => $processingfee,
            );
            Transaction::doTransaction($debitAccount, $creditAccount, "CC Account Opened", TRA_CC_ACCOUNT_OPEN, $voucherNo);
        }
    }

    /**
     * Acatual account already created in NewAcccountCreate function
     * @param <type> $ac
     * @param <type> $voucherNo
     *
     * - function is accessible to POWER_USER
     * - Debit the Branch's Cash account with initial amount deposited at the time of account creation
     * - Credit the new Account
     * - Do the transaction
     * - Check for the premiums mode from Schemes
     * - Set the premiums with due date
     */
    function createRecurringTypeAccount($ac, $voucherNo) {
//        Staff::accessibleTo(POWER_USER);

        if (inp("initialAmount") != 0) {
            $debitAccount = array(
                Branch::getCurrentBranch()->Code . SP . CASH_ACCOUNT => inp("initialAmount"),
            );
            $creditAccount = array(
                $ac->AccountNumber => inp("initialAmount"),
            );
            Transaction::doTransaction($debitAccount, $creditAccount, "Initial Recurring Amount Deposit in $ac->AccountNumber", TRA_RECURRING_ACCOUNT_AMOUNT_DEPOSIT, $voucherNo);
        }

        $premiumsSubmited = (int) (inp("initialAmount") / inp("rdamount"));
        $ac_id = $ac->id;

        switch ($ac->scheme->PremiumMode) {
            case RECURRING_MODE_YEARLY:
                $toAdd = " +1 year";
                break;
            case RECURRING_MODE_HALFYEARLY:
                $toAdd = " +6 month";
                break;
            case RECURRING_MODE_QUATERLY:
                $toAdd = " +3 month";
                break;
            case RECURRING_MODE_MONTHLY:
                $toAdd = " +1 month";
                break;
            case RECURRING_MODE_DAILY:
                $toAdd = " +1 day";
                break;
        }

        $lastPremiumPaidDate = getNow("Y-m-d");
        for ($i = 1; $i <= $ac->scheme->NumberOfPremiums; $i++) {
            $prem = new Premium();
            $prem->accounts_id = $ac_id;
            $prem->Amount = inp("rdamount");
            $prem->Paid = ($i <= $premiumsSubmited ) ? $i : 0;
            $prem->Skipped = 0;
            $prem->PaidOn = ($i <= $premiumsSubmited ) ? getNow() : null;
            $prem->AgentCommissionSend = 0;
            if ($i == 1) {
                $prem->DueDate = getNow("Y-m-d");
            } else {
                $prem->DueDate = date("Y-m-d", strtotime(date("Y-m-d", strtotime($lastPremiumPaidDate)) . $toAdd));
            }
            $lastPremiumPaidDate = $prem->DueDate;
            $prem->AgentCommissionPercentage = getComission($ac->scheme->AccountOpenningCommission, PREMIUM_COMMISSION, $i);
            $prem->save();
        }
//        if ($ac->Agents)
//            Premiums::setCommissions($ac, $voucherNo);
    }

    function createDDSTypeAccount($ac, $voucherNo) {
        if (inp("initialAmount") != 0) {
            $debitAccount = array(
                Branch::getCurrentBranch()->Code . SP . CASH_ACCOUNT => inp("initialAmount"),
            );
            $creditAccount = array(
                $ac->AccountNumber => inp("initialAmount"),
            );
            Transaction::doTransaction($debitAccount, $creditAccount, "Initial DDS Amount Deposit", TRA_DDS_ACCOUNT_AMOUNT_DEPOSIT, $voucherNo);
        }
    }

    function createDhanSanchayaTypeAccount($Ac, $voucherNo) {
        if (inp("initialAmount") != 0) {
            $debitAccount = array(
                Branch::getCurrentBranch()->Code . SP . CASH_ACCOUNT => inp("initialAmount"),
            );
            $creditAccount = array(
                $ac->AccountNumber => inp("initialAmount"),
            );
            Transaction::doTransaction($debitAccount, $creditAccount, "Initial Amount Deposit in DhanSanchaya account $ac->AccountNumber", TRA_SAVING_ACCOUNT_AMOUNT_DEPOSIT, $voucherNo);
        }
    }

    function createMoneyBackTypeAccount($Ac, $voucherNo) {
        if (inp("initialAmount") != 0) {
            $debitAccount = array(
                Branch::getCurrentBranch()->Code . SP . CASH_ACCOUNT => inp("initialAmount"),
            );
            $creditAccount = array(
                $ac->AccountNumber => inp("initialAmount"),
            );
            Transaction::doTransaction($debitAccount, $creditAccount, "Initial Amount Deposit in Money Back Account $ac->AccountNumber", TRA_RECURRING_ACCOUNT_AMOUNT_DEPOSIT, $voucherNo);
        }

        $premiumsSubmited = (int) (inp("initialAmount") / inp("rdamount"));
        $ac_id = $ac->id;

        switch ($ac->scheme->PremiumMode) {
            case RECURRING_MODE_YEARLY:
                $toAdd = " +1 year";
                break;
            case RECURRING_MODE_HALFYEARLY:
                $toAdd = " +6 month";
                break;
            case RECURRING_MODE_QUATERLY:
                $toAdd = " +3 month";
                break;
            case RECURRING_MODE_MONTHLY:
                $toAdd = " +1 month";
                break;
            case RECURRING_MODE_DAILY:
                $toAdd = " +1 day";
                break;
        }

        $lastPremiumPaidDate = getNow("Y-m-d");
        for ($i = 1; $i <= $ac->scheme->NumberOfPremiums; $i++) {
            $prem = new Premium();
            $prem->accounts_id = $ac_id;
            $prem->Amount = inp("rdamount");
            $prem->Paid = ($i <= $premiumsSubmited ) ? $i : 0;
            $prem->Skipped = 0;
            $prem->PaidOn = ($i <= $premiumsSubmited ) ? getNow() : null;
            $prem->AgentCommissionSend = 0;
            if ($i == 1) {
                $prem->DueDate = getNow("Y-m-d");
            } else {
                $prem->DueDate = date("Y-m-d", strtotime(date("Y-m-d", strtotime($lastPremiumPaidDate)) . $toAdd));
            }
            $lastPremiumPaidDate = $prem->DueDate;
            $prem->AgentCommissionPercentage = getComission($ac->scheme->AccountOpenningCommission, PREMIUM_COMMISSION, $i);
            $prem->save();
        }
    }

    /**
     * function to search for all existing accounts
     * sends the link to {@link searchAccount}
     * - generate form
     */
    function searchAccountForm() {
        $accountTypeArray = explode(",", ACCOUNT_TYPES);
        $accountTypeArray = array_merge(array("Any"), $accountTypeArray);
        $accountTypeArray = array_combine($accountTypeArray, $accountTypeArray);
        $documents = $this->db->query("Select * from jos_xdocuments")->result();
        $i = 1;
        //setInfo("SEARCH ACCOUNT", "");
        $this->load->library('form');
        $form = $this->form->open("one", 'index.php?//mod_accounts/accounts_cont/searchAccount')
                        ->setColumns(2)
                        ->text("Account Number", "name='AccountNumber' class='input'")
                        ->select("Account Type", "name='SchemeType'", $accountTypeArray)
                        ->lookupDB("Member ID", "name='UserID' class='input ui-autocomplete-input'", "index.php?//ajax/lookupDBDQL",
                                array("select" => "m.id AS ID, m.Name AS Name, m.PhoneNos",
                                    "from" => "jos_xmember m",
                                    "leftJoin" => "m.Branch b",
                                    "where" => "m.branch_id=" . Branch::getCurrentBranch()->id,
                                    "andWhere" => "m.Name Like '%\$term%'",
                                    "orWhere" => "m.id Like '%\$term%'"),
                                array("ID", "Name"), "ID")
//                ->lookupDB("Agent's Member ID","name='Agents_Id' class='input ui-autocomplete-input'","index.php?//ajax/lookupDBDQL",array("select"=>"m.id AS ID, m.Name AS Name, m.PhoneNos","from"=>"Member m","innerJoin"=>"m.Branch b","innerJoin"=>"m.Agents a","where"=>"b.id=".Branch::getCurrentBranch()->id,"andWhere"=>"m.Name Like '%\$term%'","orWhere"=>"m.id Like '%\$term%'"),array("ID","Name"),"ID")
//                ->lookupDB("Agent's Member ID","name='Agents_Id' class='input ui-autocomplete-input'","index.php?//ajax/lookupDBDQL",array("select"=>"m.id AS ID, m.Name AS Name, m.PanNo AS PanNo, m.PhoneNos","from"=>"Member m","innerJoin"=>"m.Agents a","where"=>"m.branch_id=".Branch::getCurrentBranch()->id,"andWhere"=>"m.Name Like '%\$term%' or m.id Like '%\$term%'"),array("id","Name","PanNo"),"id")//"orWhere"=>"m.id Like '%\$term%'"),array("id","Name","PanNo"),"id")
                        ->select("Active Status", "name='ActiveStatus'", array("Any" => '%', "Active" => '1', "DeActive" => '0'))
                        ->_()
//                foreach($documents as $d){
//                    $form=$form->checkBox($d->Name,"name='Documents_$i' class='input' value='$d->id'")
//                    ->textArea("Description for $d->Name","name='Description_$i'");
//                    $i++;
//               }
//               $i--;
// 		$form=$form->hidden("","name='ivalue' value='$i'")
                        ->submit('Search');
        $data['contents'] = $this->form->get();
        $this->load->view('template', $data);
    }

    /**
     * function simply search for accounts based on input given in searchAccountForm
     */
    function searchAccount() {
//        Staff::accessibleTo(POWER_USER);

        $query = "select a.*, m.Name as MemberName, s.Name as SchemeName from jos_xaccounts a join jos_xmember m on a.member_id=m.id join jos_xschemes s on s.id=a.schemes_id ";
//                $join=" join documents_submitted ds on a.id=ds.accounts_id join documents d on d.id=ds.documents_id";
        $where = " where a.branch_id = " . Branch::getCurrentBranch()->id;
        if (inp("AccountNumber") != "") {
            $where .=" AND a.AccountNumber like '%" . inp("AccountNumber") . "%' ";
        }
        if (inp("SchemeType") != "Any") {
            $where .=" AND s.SchemeType like '%" . inp("SchemeType") . "%' ";
        }
        if (inp("UserID") != "") {
            $where .=" AND (m.Name like '%" . inp("UserID") . "%'  or m.id =" . (inp("UserID")) . ")";
        }
        if (inp("ActiveStatus") != "%") {
            $where .=" AND a.ActiveStatus =" . inp("ActiveStatus");
        }

        $query .= $where . " ORDER BY id";
        $result = $this->db->query($query)->result();
        $data['accounts'] = $result;


        $accountTypeArray = explode(",", ACCOUNT_TYPES);
        $accountTypeArray = array_merge(array("Any"), $accountTypeArray);
        $accountTypeArray = array_combine($accountTypeArray, $accountTypeArray);
        $documents = $this->db->query("Select * from jos_xdocuments")->result();
        $i = 1;
        //setInfo("SEARCH ACCOUNT", "");
        //$this->load->library('form');
        $form = $this->form->open("one", 'index.php?//mod_accounts/accounts_cont/searchAccount')
                        ->setColumns(2)
                        ->text("Account Number", "name='AccountNumber' class='input'")
                        ->select("Account Type", "name='SchemeType' ", $accountTypeArray)
                        ->lookupDB("Member ID", "name='UserID' class='input ui-autocomplete-input'", "index.php?//ajax/lookupDBDQL",
                                array("select" => "m.id AS ID, m.Name AS Name, m.PhoneNos",
                                    "from" => "jos_xmember m",
                                    "leftJoin" => "m.Branch b",
                                    "where" => "m.branch_id=" . Branch::getCurrentBranch()->id,
                                    "andWhere" => "m.Name Like '%\$term%'",
                                    "orWhere" => "m.id Like '%\$term%'"),
                                array("ID", "Name"), "ID")
//                ->lookupDB("Agent's Member ID","name='Agents_Id' class='input ui-autocomplete-input'","index.php?//ajax/lookupDBDQL",array("select"=>"m.id AS ID, m.Name AS Name, m.PhoneNos","from"=>"Member m","innerJoin"=>"m.Branch b","innerJoin"=>"m.Agents a","where"=>"b.id=".Branch::getCurrentBranch()->id,"andWhere"=>"m.Name Like '%\$term%'","orWhere"=>"m.id Like '%\$term%'"),array("ID","Name"),"ID")
//                ->lookupDB("Agent's Member ID","name='Agents_Id' class='input ui-autocomplete-input'","index.php?//ajax/lookupDBDQL",array("select"=>"m.id AS ID, m.Name AS Name, m.PanNo AS PanNo, m.PhoneNos","from"=>"Member m","innerJoin"=>"m.Agents a","where"=>"m.branch_id=".Branch::getCurrentBranch()->id,"andWhere"=>"m.Name Like '%\$term%' or m.id Like '%\$term%'"),array("id","Name","PanNo"),"id")//"orWhere"=>"m.id Like '%\$term%'"),array("id","Name","PanNo"),"id")
                        ->select("Active Status", "name='ActiveStatus'", array("Any" => '%', "Active" => '1', "DeActive" => '0'))
                        ->_()
//                foreach($documents as $d){
//                    $form=$form->checkBox($d->Name,"name='Documents_$i' class='input' value='$d->id'")
//                    ->textArea("Description for $d->Name","name='Description_$i'");
//                    $i++;
//               }
//               $i--;
// 		$form=$form->hidden("","name='ivalue' value='$i'")
                        ->submit('Search');


        $data['contents'] = $this->form->get();
        $data['contents'] .=$this->load->view("searchAccountsView", $data, true);
        $this->load->view("template", $data);
    }

    /**
     * function generates a form to edit the accounts
     * - sends link to {@link editAccounts}
     */
    function editAccountsForm($id) {
//        Staff::accessibleTo(POWER_USER);

        $schemes = Branch::getAllSchemesForCurrentBranch();


        $i = inp('$id');
        $acc = new Account();
        $acc->where('id', $i)->get();

        $s = $acc->schemes_id;
        $sc = new Scheme();
        $sc->where('id', $s)->get();
        //$acc = Doctrine::getTable("Accounts")->findOneById($id);
        //$sc = Doctrine::getTable("Schemes")->findOneById($acc->schemes_id);
        $schemeType = $sc->SchemeType;

        //$this->load->library('form');
        $b = Branch::getCurrentBranch();
        $branchCode = $b->Code;

        $this->jq->addInfo("Agent", "Default branch Agent");
        $defaultAgent = $this->jq->flashMessages(true);

        $this->jq->addInfo("Member", "Member Details");
        $member = $this->jq->flashMessages(true);

        $this->jq->addInfo("Accounts", "Accounts Details");
        $accounts = $this->jq->flashMessages(true);

        $this->jq->addInfo("Dealer", $acc->Dealer->id . " :: " . $acc->Dealer->DealerName . " :: " . $acc->Dealer->Address);
        $dealer = $this->jq->flashMessages(true);


        $documents = $this->db->query("Select * from jos_xdocuments")->result();



        setInfo("EDIT ACCOUNT", "");

        if ($schemeType == ACCOUNT_TYPE_BANK) {
            $form = $this->form->open("NewBankAccount", "index.php?//mod_accounts/accounts_cont/editAccounts/$id")
                            ->setColumns(2)
                            ->text("Account number : $branchCode - ", "name='AccountNumber' class='input req-string' value='$acc->AccountNumber' DISABLED")
//                            ->lookupDB("Account number : $branchCode - ", "name='AccountNumber' class='input req-string' value='$acc->AccountNumber'", "index.php?//ajax/lookupDBDQL", array("select" => "a.*, m.Name as MemberName", "from" => "Accounts a", "leftJoin" => "a.Branch b", "leftJoin" => "a.Member m", "where" => "a.AccountNumber Like '%\$term%'", "andWhere" => "b.id='$b->id'", "limit" => "10"), array("AccountNumber","MemberName"), "")
                            ->text("Member Name", "name='UserID' class='input req-string' value='" . $acc->Member->Name . "' DISABLED")
//                        ->lookupDB("Member ID","name='UserID' class='input req-string' onblur='javascript:$(\"#memberDetailsB\").load(\"index.php?//mod_member/member_cont/memberDetails/\"+this.value);'","index.php?//ajax/lookupDBDQL",array("select"=>"m.id AS ID, m.Name AS Name, m.PanNo AS PanNo, m.PhoneNos","from"=>"Member m, m.Branch b","where"=>"b.id=$b->id","andWhere"=>"m.Name Like '%\$term%'","orWhere"=>"m.id Like '%\$term%'"),array("id","Name"),"id")
//                        ->div("memberDetailsB","",$member)
//                        ->selectAjax("Account Under","name='AccountType' class='req-string not-req' not-req-val='Select_Account_Type'",Branch::getAllSchemesForCurrentBranchOfType(ACCOUNT_TYPE_BANK))
                            ->text("Account Under", "name='AccountType' class='input req-string' value='" . $acc->Schemes->Name . "' DISABLED")
//                        ->text("Initial Opening Amount","name='initialAmount' class='input req-numeric tooltip' title='Put the initial opening amount for account'")
                            ->text("Agent's Name", "name='Agents_Id' class='input req-string' value='" . $acc->Agents->Member->Name . "' DISABLED")
//                        ->div("agentDetails","",$defaultAgent)
                            // 		->text("RD/EMI for amount","name='rdamount' class='input req-string'")
                            // 		->text("Openning Balance","name='OpenningBalance' class='input req-string'")
                            ->select("Active Status", "name='ActiveStatus'", array("Active" => '1', "DeActive" => '0'), $acc->ActiveStatus);
            // 		->text("Nominee","name='Nominee' class='input req-string'")
            // 		->text("Nominee Age","name='NomineeAge' class='input req-numeric req-min' minlength ='1'")
            // 		->text("Relation With Nominee","Name='RelationWithNominee' class='input req-string'")
            // 		->dateBox("Minor Nominee DOB","name='MinorNomineeDOB' class='input req-string'")
            // 		->text("Minor Parent Name","name='MinorNomineeParentName' class='input req-string'")
            $form = $form->select("Operation Mode", "name='ModeOfOperation'", array("Select_Mode" => '-1', "Self" => 'Self', "Joint" => 'Joint', "Any One" => 'Any', "Otehr" => 'Other'), $acc->ModeOfOperation);
            // 		->lookupDB("Interest To Account number : $branchCode - ","name='InterestTo' class='input'","index.php?//ajax/lookupDBDQL",array("select"=>"a.*, m.Name AS Name, m.PanNo AS Pan","from"=>"Accounts a","leftJoin"=>"a.Branch b, a.Member m","where"=>"a.AccountNumber Like '%\$term%'","andWhere"=>"b.id='$b->id'","orWhere"=>"m.Name like '%\$term%'","limit"=>"10"),array("Name","PanNo","AccountNumber"),"AccountNumber")
            // Documents to be submitted
            $i = 1;
            foreach ($documents as $d) {
                if ($d->SavingAccount == "" or $d->SavingAccount == 0) {
                    $i++;
                    continue;
                }
                $documents_submitted = $this->db->query("Select documents_id,Description from jos_xdocuments_submitted where accounts_id=$id and documents_id=$d->id")->row();
                if ($documents_submitted) {
                    $form = $form->checkBox($d->Name, "name='Documents_$i' class='input' value='$d->id' CHECKED")
                                    ->textArea("Description for $d->Name", "name='Description_$i'", "", $documents_submitted->Description);
                } else {
                    $form = $form->checkBox($d->Name, "name='Documents_$i' class='input' value='$d->id'")
                                    ->textArea("Description for $d->Name", "name='Description_$i'");
                }
                $i++;
            }

            $form = $form->_()
                            ->submit('Edit')
                            ->resetBtn('Reset');
            $this->jq->addTab(1, "Saving Current Account", $form->get());
        }

        if ($schemeType == ACCOUNT_TYPE_FIXED) {
            $form = $this->form->open("FixedAndMIS", "index.php?//mod_accounts/accounts_cont/editAccounts/$id")
                            ->setColumns(2)
//                        ->text("AccountID","name='AccountID' class='input ' DISABLED value='Auto Generated'")
                            ->text("Account number : $branchCode - ", "name='AccountNumber' class='input req-string' value='$acc->AccountNumber' DISABLED")
                            ->text("Member Name", "name='UserID' class='input req-string' value='" . $acc->Member->Name . "' DISABLED")
                            ->text("Account Under", "name='AccountType' class='input req-string' value='" . $acc->Schemes->Name . "' DISABLED")
//                        ->text("FD Amount","name='initialAmount' class='input req-numeric'")
                            ->text("Agent's Name", "name='Agents_Id' class='input' value='" . $acc->Agents->Member->Name . "' DISABLED")
                            ->_()
                            // 		->text("RD for amount","name='rdamount' class='input req-string'")
                            // 		->text("Openning Balance","name='OpenningBalance' class='input req-string'")
                            ->select("Active Status", "name='ActiveStatus'", array("Active" => '1', "DeActive" => '0'), $acc->ActiveStatus)
                            // 		->text("Nominee","name='Nominee' class='input req-string'")
                            // 		->text("Nominee Age","name='NomineeAge' class='input req-numeric req-min' minlength ='1'")
                            // 		->text("Relation With Nominee","Name='RelationWithNominee' class='input req-string'")
                            // 		->dateBox("Minor Nominee DOB","name='MinorNomineeDOB' class='input req-string'")
                            // 		->text("Minor Parent Name","name='MinorNomineeParentName' class='input req-string'")
                            ->select("Operation Mode", "name='ModeOfOperation'", array("Select_Mode" => '-1', "Self" => 'Self', "Joint" => 'Joint', "Any One" => 'Any', "Otehr" => 'Other'), $acc->ModeOfOperation)
//                        ->lookupDB("Interest To Account number : $branchCode - ","name='InterestTo' class='input'","index.php?//ajax/lookupDBDQL",array("select"=>"a.*, m.Name AS Name, m.PanNo AS Pan, s.Name as Scheme","from"=>"Accounts a","leftJoin"=>"a.Branch b, a.Member m, a.Schemes s","where"=>"a.AccountNumber Like '%\$term%'","andWhere"=>"b.id='$b->id'","limit"=>"10"),array("Name","Pan","AccountNumber","Scheme"),"AccountNumber")
                            ->_();
            $i = 1;
            foreach ($documents as $d) {
                if ($d->FixedMISAccount == "" or $d->FixedMISAccount == 0) {
                    $i++;
                    continue;
                }
                $documents_submitted = $this->db->query("Select documents_id,Description from jos_xdocuments_submitted where accounts_id=$id and documents_id=$d->id")->row();
                if ($documents_submitted) {
                    $form = $form->checkBox($d->Name, "name='Documents_$i' class='input' value='$d->id' CHECKED")
                                    ->textArea("Description for $d->Name", "name='Description_$i'", "", $documents_submitted->Description);
                } else {
                    $form = $form->checkBox($d->Name, "name='Documents_$i' class='input' value='$d->id'")
                                    ->textArea("Description for $d->Name", "name='Description_$i'");
                }
                $i++;
            }


            $form = $form->_()
                            ->submit('Edit')
                            ->resetBtn('Reset');
            $this->jq->addTab(1, "Fixed And MIS Accounts", $this->form->get());
        }

        if ($schemeType == ACCOUNT_TYPE_LOAN) {
            $form = $this->form->open("LoanAccounts", "index.php?//mod_accounts/accounts_cont/editAccounts/$id")
                            ->setColumns(2)
//                        ->text("AccountID","name='AccountID' class='input ' DISABLED value='Auto Generated'")
                            ->text("Account number : $branchCode - ", "name='AccountNumber' class='input req-string' value='$acc->AccountNumber' DISABLED")
                            ->text("Member Name", "name='UserID' class='input req-string' value='" . $acc->Member->Name . "' DISABLED")
                            ->text("Account Under", "name='AccountType' class='input req-string' value='" . $acc->Schemes->Name . "' DISABLED")
                            ->text("Loan Amount", "name='initialAmount' class='input req-numeric' value='$acc->RdAmount' DISABLED")
                            ->text("Agent's Name", "name='Agents_Id' class='input' value='" . $acc->Agents->Member->Name . "' DISABLED")
                            ->_()
//                        ->div("agentDetails","",$defaultAgent)
                            //		->text("EMI for amount","name='rdamount' class='input req-string'")
                            // 		->text("Openning Balance","name='OpenningBalance' class='input req-string'")
                            ->select("Active Status", "name='ActiveStatus'", array("Active" => '1', "DeActive" => '0'), $acc->ActiveStatus)
                            // 		->text("Nominee","name='Nominee' class='input req-string'")
                            // 		->text("Nominee Age","name='NomineeAge' class='input req-numeric req-min' minlength ='1'")
                            // 		->text("Relation With Nominee","Name='RelationWithNominee' class='input req-string'")
                            // 		->dateBox("Minor Nominee DOB","name='MinorNomineeDOB' class='input req-string'")
                            // 		->text("Minor Parent Name","name='MinorNomineeParentName' class='input req-string'")
                            //                ->text("Gaurantor","name='Nominee' class='input req-string'")
                            // 		->text("Gaurantor Age","name='NomineeAge' class='input req-numeric req-min' minlength ='1'")
                            ->text("Gaurantor", "name='Nominee' class='input' value='$acc->Nominee' ")
                            ->text("Gaurantor Address", "name='MinorNomineeParentName' class='input' value='$acc->MinorNomineeParentName'")  // IMP : Used as gaurantor address in loan accounts
                            ->text("Gaurantor Phone Nos.", "Name='RelationWithNominee' class='input' value='$acc->RelationWithNominee'")
                            ->select("Operation Mode", "name='ModeOfOperation'", array("Select_Mode" => '-1', "Self" => 'Self', "Joint" => 'Joint', "Any One" => 'Any', "Otehr" => 'Other'), $acc->ModeOfOperation)
                            // 		->selectAjax("Loan Amount From Account","name='InterestTo' class='req-string not-req' not-req-val='Select_Account_Type'",Branch::getAllSchemesForCurrentBranchOfName('Bank Accounts'))
//                        ->lookupDB("Loan Amount From Account : $branchCode - ","name='InterestTo' class='input'","index.php?//ajax/lookupDBDQL",array("select"=>"a.*, s.Name","from"=>"Accounts a, a.Schemes s, a.Branch b","where"=>"a.AccountNumber Like '%\$term%' AND (s.Name='Bank Accounts' OR s.Name='Cash Account' OR s.Name='Saving Account') AND b.id='$b->id' AND a.LockingStatus<>1 AND a.ActiveStatus<>0","limit"=>"10"),array("AccountNumber"),"AccountNumber")
                            ->dateBox("Loan Insurrance Date", "name='LoanInsurranceDate' value='$acc->LoanInsurranceDate'");
            //                ->selectAjax("Select Account if Loan Ag. Security","name='SecurityAccount' class='req-string not-req' not-req-val='Select_Account'",$this->db->query("select a.id, a.AccountNumber,m.Name,DATE_ADD(a.created_at,INTERVAL s.MaturityPeriod MONTH) as MaturityDate, (a.CurrentBalanceCr - a.CurrentBalanceDr) from accounts a join member m on a.member_id=m.id join schemes s on a.schemes_id=s.id where (s.SchemeType='Deposit' or s.SchemeType='Fixed & Mis' or s.SchemeType='Recurring') and a.branch_id=".Branch::getCurrentBranch()->id." and  a.member_id=".inp("UserID")." and a.ActiveStatus=1")->result())
            //                ->lookupDB("Select Account if Loan Ag. Security","name='SecurityAccount' class='input req-string' onblur='javascript:$(\"#accountsDetails\").load(\"mod_accounts/accounts_cont/accountsDetails/\"+this.value);'","index.php?//ajax/lookupDBDQL",array("select"=>"a.id AS Id,a.AccountNumber AS AccNum, m.Name AS Name, DATE_ADD(a.created_at,INTERVAL s.MaturityPeriod MONTH) AS MaturityDate, (a.CurrentBalanceCr - a.CurrentBalanceDr) AS CurrentBalance","from"=>"Accounts a","leftJoin"=>"a.member m","leftJoin"=>"a.schemes s","where"=>"s.SchemeType='Deposit'","orWhere"=>"s.SchemeType='Fixed & Mis'","orWhere"=>"s.SchemeType='Recurring'","andWhere"=>"a.branch_id='$b->id'","andWhere"=>"a.ActiveStatus =1","andWhere"=>"a.AccountNumber Like '%\$term%'"),array("Id"),"Id")
            //                ->lookupDB("Select Member(if Loan Ag. Security)","name='memberid' class='input req-string' onblur='javascript:$(\"#accountsDetailsF\").load(\"index.php?//mod_accounts/accounts_cont/accountsDetails/\"+this.value);'","index.php?//ajax/lookupDBDQL",array("select"=>"m.id AS ID, m.Name AS Name, m.PanNo AS PanNo, m.PhoneNos","from"=>"Member m, m.Branch b","where"=>"b.id=$b->id","andWhere"=>"m.Name Like '%\$term%'","orWhere"=>"m.id Like '%\$term%'"),array("id","Name"),"id")
//                        ->checkbox("Loan Ag Security","name='LoanAgSecurity' class='input' value='1'")
//                        ->_()
            $securityAcc = "";

            if ($acc->LoanAgainstAccount != "")
                $securityAcc = $this->db->query("Select AccountNumber as accNum from jos_xaccounts where id=$acc->LoanAgainstAccount")->row()->accNum;
            $form = $form->text("Account Number(if Loan Ag. Security)", "Name='SecurityAccount' class='input' value='$securityAcc' DISABLED")
//                        ->div("accountsDetailsF","",$accounts);
                            ->_()
                            ->lookupDB("Dealer ID", "name='Dealer' class='input' onblur='javascript:$(\"#DealerDetails\").load(\"index.php?//mod_member/member_cont/dealerDetails/\"+this.value);'", "index.php?//ajax/lookupDBDQL", array("select" => "d.*", "from" => "Dealer d", "where" => "d.DealerName Like '%\$term%'", "orWhere" => "d.id Like '%\$term%'", "limit" => "10"), array("id", "DealerName", "Address"), "id")
                            ->div("DealerDetails", "", $dealer);
            $i = 1;
            foreach ($documents as $d) {
                if ($d->LoanAccount == "" or $d->LoanAccount == 0) {
                    $i++;
                    continue;
                }
                $documents_submitted = $this->db->query("Select documents_id,Description from jos_xdocuments_submitted where accounts_id=$id and documents_id=$d->id")->row();
                if ($documents_submitted) {
                    $form = $form->checkBox($d->Name, "name='Documents_$i' class='input' value='$d->id' CHECKED")
                                    ->textArea("Description for $d->Name", "name='Description_$i'", "", $documents_submitted->Description);
                } else {
                    $form = $form->checkBox($d->Name, "name='Documents_$i' class='input' value='$d->id'")
                                    ->textArea("Description for $d->Name", "name='Description_$i'");
                }
                $i++;
            }

            $form = $form->_()
                            ->submit('Edit')
                            ->resetBtn('Reset');
            $this->jq->addTab(1, "Loan Account", $this->form->get());
        }

        if ($schemeType == ACCOUNT_TYPE_RECURRING) {
            $form = $this->form->open("RD", "index.php?//mod_accounts/accounts_cont/editAccounts/$id")
                            ->setColumns(2)
//                        ->text("AccountID","name='AccountID' class='input ' DISABLED value='Auto Generated'")
                            ->text("Account number : $branchCode - ", "name='AccountNumber' class='input req-string' value='$acc->AccountNumber' DISABLED")
                            ->text("Member Name", "name='UserID' class='input req-string' value='" . $acc->Member->Name . "' DISABLED")
                            ->text("Account Under", "name='AccountType' class='input req-string' value='" . $acc->Schemes->Name . "' DISABLED")
//                        ->text("Initial Opening Amount","name='initialAmount' class='input req-numeric'")
                            ->text("Agent's Name", "name='Agents_Id' class='input' value='" . $acc->Agents->Member->Name . "' DISABLED")
                            ->text("RECURRING amount", "name='rdamount' class='input req-string' value='$acc->RdAmount'")
                            // 		->text("Openning Balance","name='OpenningBalance' class='input req-string'")
                            ->select("Active Status", "name='ActiveStatus'", array("Active" => '1', "DeActive" => '0'), $acc->ActiveStatus);

            // 		->text("Nominee","name='Nominee' class='input req-string'")
            // 		->text("Nominee Age","name='NomineeAge' class='input req-numeric req-min' minlength ='1'")
            // 		->text("Relation With Nominee","Name='RelationWithNominee' class='input req-string'")
            // 		->dateBox("Minor Nominee DOB","name='MinorNomineeDOB' class='input req-string'")
            // 		->text("Minor Parent Name","name='MinorNomineeParentName' class='input req-string'")
            //
            // 		->selectAjax("Operation Mode","name='ModeOfOperation' class='not-req req-string' not-req-val='Select_Mode'",array("Select_Mode"=>'-1',"Self"=>'Self',"Joint"=>'Joint',"Any One"=>'Any',"Otehr"=>'Other'))
            // 		->lookupDB("Interest To Account number : $branchCode - ","name='InterestTo' class='input'","index.php?//ajax/lookupDBDQL",array("select"=>"a.*, m.Name AS Name, m.PanNo AS Pan, s.Name as Scheme","from"=>"Accounts a","leftJoin"=>"a.Branch b, a.Member m, a.Schemes s","where"=>"a.AccountNumber Like '%\$term%'","andWhere"=>"b.id='$b->id'","limit"=>"10"),array("Name","Pan","AccountNumber","Scheme"),"AccountNumber")
            $i = 1;
            foreach ($documents as $d) {
                if ($d->RDandDDSAccount == "" or $d->RDandDDSAccount == 0) {
                    $i++;
                    continue;
                }
                $documents_submitted = $this->db->query("Select documents_id,Description from jos_xdocuments_submitted where accounts_id=$id and documents_id=$d->id")->row();
                if ($documents_submitted) {
                    $form = $form->checkBox($d->Name, "name='Documents_$i' class='input' value='$d->id' CHECKED")
                                    ->textArea("Description for $d->Name", "name='Description_$i'", "", $documents_submitted->Description);
                } else {
                    $form = $form->checkBox($d->Name, "name='Documents_$i' class='input' value='$d->id'")
                                    ->textArea("Description for $d->Name", "name='Description_$i'");
                }
                $i++;
            }

            $form = $form->_()
                            ->submit('Edit')
                            ->resetBtn('Reset');
            $this->jq->addTab(1, "RD Accounts", $this->form->get());
        }

        if ($schemeType == ACCOUNT_TYPE_DDS) {
            $form = $this->form->open("DDS", "index.php?//mod_accounts/accounts_cont/editAccounts/$id")
                            ->setColumns(2)
//                        ->text("AccountID","name='AccountID' class='input ' DISABLED value='Auto Generated'")
                            ->text("Account number : $branchCode - ", "name='AccountNumber' class='input req-string' value='$acc->AccountNumber' DISABLED")
                            ->text("Member Name", "name='UserID' class='input req-string' value='" . $acc->Member->Name . "' DISABLED")
                            ->text("Account Under", "name='AccountType' class='input req-string' value='" . $acc->Schemes->Name . "' DISABLED")
//                        ->text("Initial Opening Amount","name='initialAmount' class='input req-numeric'")
                            ->text("Agent's Name", "name='Agents_Id' class='input' value='" . $acc->Agents->Member->Name . "' DISABLED")
                            ->text("DDS amount", "name='rdamount' class='input req-string' value='$acc->RdAmount'")
                            // 		->text("Openning Balance","name='OpenningBalance' class='input req-string'")
                            ->select("Active Status", "name='ActiveStatus'", array("Active" => '1', "DeActive" => '0'), $acc->ActiveStatus);

            // 		->text("Nominee","name='Nominee' class='input req-string'")
            // 		->text("Nominee Age","name='NomineeAge' class='input req-numeric req-min' minlength ='1'")
            // 		->text("Relation With Nominee","Name='RelationWithNominee' class='input req-string'")
            // 		->dateBox("Minor Nominee DOB","name='MinorNomineeDOB' class='input req-string'")
            // 		->text("Minor Parent Name","name='MinorNomineeParentName' class='input req-string'")
            //
            // 		->selectAjax("Operation Mode","name='ModeOfOperation' class='not-req req-string' not-req-val='Select_Mode'",array("Select_Mode"=>'-1',"Self"=>'Self',"Joint"=>'Joint',"Any One"=>'Any',"Otehr"=>'Other'))
            // 		->lookupDB("Interest To Account number : $branchCode - ","name='InterestTo' class='input'","index.php?//ajax/lookupDBDQL",array("select"=>"a.*, m.Name AS Name, m.PanNo AS Pan, s.Name as Scheme","from"=>"Accounts a","leftJoin"=>"a.Branch b, a.Member m, a.Schemes s","where"=>"a.AccountNumber Like '%\$term%'","andWhere"=>"b.id='$b->id'","limit"=>"10"),array("Name","Pan","AccountNumber","Scheme"),"AccountNumber")
            $i = 1;
            foreach ($documents as $d) {
                if ($d->RDandDDSAccount == "" or $d->RDandDDSAccount == 0) {
                    $i++;
                    continue;
                }
                $documents_submitted = $this->db->query("Select documents_id,Description from jos_xdocuments_submitted where accounts_id=$id and documents_id=$d->id")->row();
                if ($documents_submitted) {
                    $form = $form->checkBox($d->Name, "name='Documents_$i' class='input' value='$d->id' CHECKED")
                                    ->textArea("Description for $d->Name", "name='Description_$i'", "", $documents_submitted->Description);
                } else {
                    $form = $form->checkBox($d->Name, "name='Documents_$i' class='input' value='$d->id'")
                                    ->textArea("Description for $d->Name", "name='Description_$i'");
                }
                $i++;
            }

            $form = $form->_()
                            ->submit('Edit')
                            ->resetBtn('Reset');
            $this->jq->addTab(1, "DDS Accounts", $this->form->get());
        }


        if ($schemeType == ACCOUNT_TYPE_CC) {
            $form = $this->form->open("CCAccounts", "index.php?//mod_accounts/accounts_cont/editAccounts/$id")
                            ->setColumns(2)
//                        ->text("AccountID","name='AccountID' class='input ' DISABLED value='Auto Generated'")
                            ->text("Account number : $branchCode - ", "name='AccountNumber' class='input req-string' value='$acc->AccountNumber' DISABLED")
                            ->text("Member Name", "name='UserID' class='input req-string' value='" . $acc->Member->Name . "' DISABLED")
                            ->text("Account Under", "name='AccountType' class='input req-string' value='" . $acc->Schemes->Name . "' DISABLED")
                            ->text("CC Limit", "name='initialAmount' class='input req-numeric' value='$acc->RdAmount' DISABLED")
                            ->text("Agent's Name", "name='Agents_Id' class='input' value='" . $acc->Agents->Member->Name . "' DISABLED")
                            // 		->text("EMI for amount","name='rdamount' class='input req-string'")
                            //		->_()
                            // 		->text("Openning Balance","name='OpenningBalance' class='input req-string'")
                            ->select("Active Status", "name='ActiveStatus'", array("Active" => '1', "DeActive" => '0'), $acc->ActiveStatus);
            // 		->text("Nominee","name='Nominee' class='input req-string'")
            // 		->text("Nominee Age","name='NomineeAge' class='input req-string'")
            // 		->text("Relation With Nominee","Name='RelationWithNominee' class='input req-string'")
            // 		->dateBox("Minor Nominee DOB","name='MinorNomineeDOB' class='input req-string'")
            // 		->text("Minor Parent Name","name='MinorNomineeParentName' class='input req-string'")
            // 		->selectAjax("Operation Mode","name='ModeOfOperation' class='not-req req-string' not-req-val='Select_Mode'",array("Select_Mode"=>'-1',"Self"=>'Self',"Joint"=>'Joint',"Any One"=>'Any',"Otehr"=>'Other'))
            // 		->lookupDB("Interest To Account number : $branchCode - ","name='InterestTo' class='input'","index.php?//ajax/lookupDBDQL",array("select"=>"a.*, m.Name AS Name, m.PanNo AS Pan","from"=>"Accounts a","leftJoin"=>"a.Branch b, a.Member m","where"=>"a.AccountNumber Like '%\$term%'","andWhere"=>"b.id='$b->id'","orWhere"=>"m.Name like '%\$term%'","limit"=>"10"),array("Name","PanNo","AccountNumber"),"AccountNumber")
            $i = 1;
            foreach ($documents as $d) {
                if ($d->CCAccount == "" or $d->CCAccount == 0) {
                    $i++;
                    continue;
                }
                $documents_submitted = $this->db->query("Select documents_id,Description from jos_xdocuments_submitted where accounts_id=$id and documents_id=$d->id")->row();
                if ($documents_submitted) {
                    $form = $form->checkBox($d->Name, "name='Documents_$i' class='input' value='$d->id' CHECKED")
                                    ->textArea("Description for $d->Name", "name='Description_$i'", "", $documents_submitted->Description);
                } else {
                    $form = $form->checkBox($d->Name, "name='Documents_$i' class='input' value='$d->id'")
                                    ->textArea("Description for $d->Name", "name='Description_$i'");
                }
                $i++;
            }

            $form = $form->_()
                            ->submit('Edit')
                            ->resetBtn('Reset');

            $this->jq->addTab(1, "CC Accounts", $this->form->get());
        }

        if ($schemeType == ACCOUNT_TYPE_DEFAULT) {
            $form = $this->form->open("OtherAccounts", "index.php?//mod_accounts/accounts_cont/editAccounts/$id")
                            ->setColumns(2)
                            ->text("Account number : $branchCode - ", "name='AccountNumber' class='input req-string' value='$acc->AccountNumber' DISABLED")
                            ->text("Member Name", "name='UserID' class='input req-string' value='" . $acc->Member->Name . "' DISABLED")
                            ->text("Account Under", "name='AccountType' class='input req-string' value='" . $acc->Schemes->Name . "' DISABLED")
                            // 		->text("Initial Opening Amount","name='initialAmount' class='input req-numeric'")
                            ->text("Agent's Name", "name='Agents_Id' class='input' value='" . $acc->Agents->Member->Name . "' DISABLED")
                            // 		->text("EMI for amount","name='rdamount' class='input req-string'")
                            //		->_()
                            // 		->text("Openning Balance","name='OpenningBalance' class='input req-string'")
                            ->select("Active Status", "name='ActiveStatus'", array("Active" => '1', "DeActive" => '0'), $acc->ActiveStatus);
            // 		->text("Nominee","name='Nominee' class='input req-string'")
            // 		->text("Nominee Age","name='NomineeAge' class='input req-string'")
            // 		->text("Relation With Nominee","Name='RelationWithNominee' class='input req-string'")
            // 		->dateBox("Minor Nominee DOB","name='MinorNomineeDOB' class='input req-string'")
            // 		->text("Minor Parent Name","name='MinorNomineeParentName' class='input req-string'")
            // 		->selectAjax("Operation Mode","name='ModeOfOperation' class='not-req req-string' not-req-val='Select_Mode'",array("Select_Mode"=>'-1',"Self"=>'Self',"Joint"=>'Joint',"Any One"=>'Any',"Otehr"=>'Other'))
            // 		->lookupDB("Interest To Account number : $branchCode - ","name='InterestTo' class='input'","index.php?//ajax/lookupDBDQL",array("select"=>"a.*, m.Name AS Name, m.PanNo AS Pan","from"=>"Accounts a","leftJoin"=>"a.Branch b, a.Member m","where"=>"a.AccountNumber Like '%\$term%'","andWhere"=>"b.id='$b->id'","orWhere"=>"m.Name like '%\$term%'","limit"=>"10"),array("Name","PanNo","AccountNumber"),"AccountNumber")
            $i = 1;
            foreach ($documents as $d) {
                if ($d->OtherAccounts == "" or $d->OtherAccounts == 0) {
                    $i++;
                    continue;
                }
                $documents_submitted = $this->db->query("Select documents_id,Description from jos_xdocuments_submitted where accounts_id=$id and documents_id=$d->id")->row();
                if ($documents_submitted) {
                    $form = $form->checkBox($d->Name, "name='Documents_$i' class='input' value='$d->id' CHECKED")
                                    ->textArea("Description for $d->Name", "name='Description_$i'", "", $documents_submitted->Description);
                } else {
                    $form = $form->checkBox($d->Name, "name='Documents_$i' class='input' value='$d->id'")
                                    ->textArea("Description for $d->Name", "name='Description_$i'");
                }
                $i++;
            }
            $form = $form->_()
                            ->submit('Edit')
                            ->resetBtn('Reset');

            $this->jq->addTab(1, "Other Accounts", $this->form->get());
        }

        $data['contents'] = $this->jq->getTab(1);
//                echo $data['contents'];
        $this->load->view('template', $data);
    }

    /**
     *
     * @param <type> $id
     * function edits the accounts and redirects the page to the function mod_accounts/accounts_cont/index
     */
    function editAccounts($id) {
//        Staff::accessibleTo(POWER_USER);
        try {
            //$conn = Doctrine_Manager::connection();
            //$conn->beginTransaction();
            $this->db->trans_begin();
            $Ac = new Account();
            $Ac->where('id', $id)->get();
            //$Ac = Doctrine::getTable('Accounts')->find($id);
            $Ac->ActiveStatus = inp('ActiveStatus');
            $Ac->Nominee = inp('Nominee');  // IMP : used as guarantor for loan accounts
//			$Ac->NomineeAge=inp('NomineeAge');
            $Ac->RelationWithNominee = inp('RelationWithNominee');  // IMP : Used as Gaurantor Phone nos. for loan accounts
//			$Ac->MinorNomineeDOB="'".inp('MinorNomineeDOB')."'";
            $Ac->MinorNomineeParentName = inp('MinorNomineeParentName');   // IMP : used as guarantor Address for loan accounts
            $Ac->ModeOfOperation = (inp('ModeOfOperation') == "") ? "Self" : inp('ModeOfOperation');

            if (inp("Dealer") != "")
                $Ac->dealer_id = inp('Dealer');

            $Ac->save();
            log_message('error', __FILE__ . " " . __FUNCTION__ . " $Ac->AccountNumber with id $Ac->id edited from " . $this->input->ip_address());
            // save the documents submitted
            $documents = $this->db->query("Select * from jos_xdocuments")->result();
            $i = 1;
            foreach ($documents as $d) {

                if (inp("Documents_$i") != "") {

                    //$docs=$this->db->query("select * from jos_xdocuments_submitted where accounts_id=".$id." and documents_id=".inp("Documents_$i"))->result();
                    $d = inp("Documents_$i");
                    $docs = new Documents_submitted();
                    $docs->where('accounts_id', $id)->where('documents_id', $d)->get();
                    //$docs = Doctrine::getTable("DocumentsSubmitted")->findOneByAccounts_idAndDocuments_id($id, inp("Documents_$i"));
                    if (!$docs) {
                        $docsSubmitted = new DocumentsSubmitted();
                        $docsSubmitted->accounts_id = $Ac->id;
                        $docsSubmitted->documents_id = inp("Documents_$i");
                        $docsSubmitted->Description = inp("Description_$i");
                        $docsSubmitted->save();
                    } else {

                        $docs->documents_id = inp("Documents_$i");
                        $docs->Description = inp("Description_$i");
                        $docs->save();
                    }
                }
//
                $i++;
            }
            log_message('error', __FILE__ . " " . __FUNCTION__ . " Documents saved for $Ac->AccountNumber with id $Ac->id from " . $this->input->ip_address());
            $conn->commit();
            log_message('error', __FILE__ . " " . __FUNCTION__ . " Account Editing committed $Ac->AccountNumber with id $Ac->id from " . $this->input->ip_address());
        } catch (Doctrine_Exception $e) {
            $this->db->trans_rollback();
            //$conn->rollback();
            echo $e->getMessage();
            return;
        }

        redirect('mod_accounts/accounts_cont/searchAccountForm');
    }

    function printToPDF($id) {
        $a = new Account();
        $aa = $a->where('id', $id)->get();
        $data['account'] = $aa;
        //$data['account'] = Doctrine::getTable("Accounts")->findOneById($id);
        $html = $this->load->view('AccountsPDFView', $data, true);
        $this->load->plugin("to_pdf");
        pdf_create($html, 'chequedata', true);
    }

    function accountsInfo($id) {
        $a = new Account();
        $aa = $a->where('id', $id)->get();
        $data['account'] = $aa;
        //$data['account'] = Doctrine::getTable("Accounts")->findOneById($id);
        $data['contents'] = "<a href='index.php?//mod_accounts/accounts_cont/printToPDF/$id' target='_blank'>Click Here</a> to print the receipt of Acccount " . $data['account']->AccountNumber;
        $this->load->view("template", $data);
    }

    /**
     *
     * @param <type> $id
     * Change the status of the account
     */
    function statusChange($id) {
//        Staff::accessibleTo(BRANCH_ADMIN);
        $ac = new Account();
        $ac->where('id', $id)->get();
        //$ac = Doctrine::getTable("Accounts")->findOneById($id);
        if ($ac->ActiveStatus == 1) {

            $this->load->library('form');
            $this->form->open("one", "index.php?/mod_accounts/accounts_cont/statusChangeConfirm/$id")
                    ->setColumns(2)
                    ->checkBox("Check if account $ac->AccountNumber affects Balance Sheet", "name='affectsBalanceSheet' class='input' value='1'", "CHECKED")
//                ->confirmButton("Confirm","Change the status of Account Number $ac->AccountNumber","index.php?/mod_accounts/accounts_cont/statusChangeConfirm/$id",true)
                    ->submit('Change');
            $data['contents'] = $this->form->get();
            $this->load->view('template', $data);
        } else {
//
            $ac->ActiveStatus = ($ac->ActiveStatus == 0) ? 1 : 0;
            $ac->affectsBalanceSheet = 0;
            $ac->save();
            log_message('error', __FILE__ . " " . __FUNCTION__ . " Status of $ac->AccountNumber with id $ac->id changed to $ac->ActiveStatus from " . $this->input->ip_address());
            redirect('mod_accounts/accounts_cont');
        }
    }

    function statusChangeConfirm($id) {
//        Staff::accessibleTo(BRANCH_ADMIN);
        $ac = new Account();
        $ac->where('id', $id)->get();
        //$ac = Doctrine::getTable("Accounts")->findOneById($id);
        $ac->ActiveStatus = ($ac->ActiveStatus == 0) ? 1 : 0;
        if (inp("affectsBalanceSheet") == 1)
            $ac->affectsBalanceSheet = 1;
        $ac->save();
        log_message('error', __FILE__ . " " . __FUNCTION__ . " Status of $ac->AccountNumber with id $ac->id changed to $ac->ActiveStatus from " . $this->input->ip_address());
        redirect('mod_accounts/accounts_cont');
    }

    function deleteAccountConfirm($id) {
        $ac = new Account();
        $ac->where('id', $id)->get();
        //$ac = Doctrine::getTable("Accounts")->find($id);
        $branchid = Branch::getCurrentBranch()->id;
        $sum = array();
        $transactions = new Transaction();
        $transactions->where('accounts_id', $ac->id)->where('branch_id', $branchid)->get();
        // $transactions = Doctrine::getTable("Transactions")->findByAccounts_idAndBranch_id($ac->id, $branchid);
        foreach ($transactions as $tr) {
            $trans = new Transaction();
            $trans->where('voucher_no', $tr->voucher_no)->where('branch_id', $branchid)->get();
            //$trans = Doctrine::getTable("Transactions")->findByVoucher_noAndBranch_id($tr->voucher_no, $branchid);
//                if($trans->count()==2){
            foreach ($trans as $t) {
                if (!isset($sum[$t->Accounts->AccountNumber])) {
                    $sum[$t->Accounts->AccountNumber]['DR'] = 0;
                    $sum[$t->Accounts->AccountNumber]['CR'] = 0;
                }
                $sum[$t->Accounts->AccountNumber]['DR'] += $t->amountDr;
                $sum[$t->Accounts->AccountNumber]['CR'] += $t->amountCr;
            }
//                    continue;
//                }
        }
        $i = 0;
        $acc = array_keys($sum);
        foreach ($sum as $s) {

            echo $acc[$i] . " :: " . $sum[$acc[$i]]['DR'] . " :: " . $sum[$acc[$i]]['CR'] . "<br>";
            $i++;
        }

//            echo "<a href='index.php?//mod_accounts/accounts_cont/deleteAccount/$id'>OK</a>";
    }

    function deleteAccount($id) {
//           echo "done hagaa ". $id;
//           return;
        Staff::accessibleTo(BRANCH_ADMIN);
        $branchid = Branch::getCurrentBranch()->id;
        $ac = new Account();
        $ac->where('id', $id)->where('branch_id', $branchid)->get();
        // $ac = Doctrine::getTable("Accounts")->findOneByIdAndBranch_id($id, $branchid);
        if (!$ac) {
            echo "Account Does not Exists";
            return;
        }
        try {
            $conn = Doctrine_Manager::connection();
            $this->db->trans_begin();
            // $conn->beginTransaction();
            $sc = Schemes::getScheme($ac->schemes_id);
            $schemeName = $sc->Name;

            $transactions = new Transaction();
            $transactions->where('accounts_id', $ac->id)->where('branch_id', $branchid)->get();
            // $transactions = Doctrine::getTable("Transactions")->findByAccounts_idAndBranch_id($ac->id, $branchid);
            foreach ($transactions as $tr) {
                $trans = new Transaction();
                $trans->where('voucher_no', $tr->voucher_no)->where('branch_id', $branchid)->get();
                //$trans = Doctrine::getTable("Transactions")->findByVoucher_noAndBranch_id($tr->voucher_no, $branchid);

                foreach ($trans as $t) {
                    if ($t->accounts_id == $ac->id)
                        continue;
                    $otherac = new Account();
                    $otherac->where('id', $t->accounts_id)->get();
                    //$otherac = Doctrine::getTable("Accounts")->findOneById($t->accounts_id);
                    $otherac->CurrentBalanceCr = $otherac->CurrentBalanceCr - $t->amountCr;
                    $otherac->CurrentBalanceDr = $otherac->CurrentBalanceDr - $t->amountDr;
                    $otherac->save();

                    $q = "delete from jos_xtransactions where voucher_no = $t->voucher_no and branch_id = $branchid";
                    executeQuery($q);
                }
            }

//            $q = "delete from transactions where voucher_no = $transactions->voucher_no and branch_id = $branchid";
//            executeQuery($q);
            $query = "delete from jos_xpremiums where accounts_id = $ac->id";
            executeQuery($query);
            $query = "delete from jos_xaccounts where id = $ac->id";
            executeQuery($query);

            $this->db->trans_commit();
            echo "Done";
        } catch (Doctrine_Exception $e) {
            $this->db->trans_rollback();
            echo $e->getMessage();
            return;
        }
    }

    function AccountNumber() {
        $list = array();
        //$q = "select a.* from jos_xaccounts a join jos_xschemes s on a.schemes_id = s.id where  (a.AccountNumber like '%" . $this->input->post("term") . "%' or a.id like '%" . $this->input->post("term") . "%') and s.`Name`='" . SAVING_ACCOUNT_SCHEME . "'";
        $q = "select a.*, m.Name from jos_xaccounts a join jos_xschemes s on a.schemes_id = s.id join jos_xmember m on a.member_id = m.id where a.AccountNumber Like '%" . $this->input->post("term") . "%' or a.id like '%" . $this->input->post("term") . "%' limit 10 ";
        $result = $this->db->query($q)->result();
        foreach ($result as $dd) {
            $list[] = array('id' => $dd->id, 'AccountNumber' => $dd->AccountNumber, 'Name' => $dd->Name);
        }
        echo '{"tags":' . json_encode($list) . '}';
    }

    function MemberID() {
        $list = array();
        $q = "select m.id AS ID, m.Name AS Name, m.FatherName as FatherName, m.PanNo AS PanNo, m.PhoneNos, b.Name AS BranchName from jos_xmember m join jos_xbranch b on m.branch_id=b.id where( m.Name Like '%" . $this->input->post("term") . "%' or m.id Like '%" . $this->input->post("term") . "%') and m.IsMember = 1 order by m.id limit 0,10";
        $result = $this->db->query($q)->result();
        foreach ($result as $dd) {
            $list[] = array('id' => $dd->ID, 'Name' => $dd->Name, "FatherName" => $dd->FatherName, "BranchName" => $dd->BranchName);
        }
        echo '{"tags":' . json_encode($list) . '}';
    }

    function CustomerID() {
        $list = array();
        $q = "select m.id AS ID, m.Name AS Name, m.FatherName as FatherName, m.PanNo AS PanNo, m.PhoneNos, b.Name AS BranchName from jos_xmember m join jos_xbranch b on m.branch_id=b.id where( m.Name Like '%" . $this->input->post("term") . "%' or m.id Like '%" . $this->input->post("term") . "%') and m.IsCustomer = 1 order by m.id limit 0,10";
        $result = $this->db->query($q)->result();
        foreach ($result as $dd) {
            $list[] = array('id' => $dd->ID, 'Name' => $dd->Name, "FatherName" => $dd->FatherName, "BranchName" => $dd->BranchName);
        }
        echo '{"tags":' . json_encode($list) . '}';
    }

    function AgentMemberID() {
        $list = array();
        $q = "select a.id as id, m.id AS ID, m.Name AS Name, m.PanNo AS PanNo, m.PhoneNos, m.FatherName as FatherName,b.Name AS BranchName from jos_xmember m join jos_xagents a on a.member_id = m.id join jos_xbranch b on m.branch_id=b.id where(a.id='%" . $this->input->post("term") . "%' or m.Name Like '%" . $this->input->post("term") . "%' )";
        //$q = "select m.id AS ID, m.Name AS Name, m.FatherName as FatherName, m.PanNo AS PanNo, m.PhoneNos, b.Name AS BranchName from jos_xmember m, m.jos_xbranch b where( m.Name Like '%".$this->input->post("term"). "%' or m.id Like '%".$this->input->post("term")."%')";
        $result = $this->db->query($q)->result();
        foreach ($result as $dd) {
            $list[] = array('id' => $dd->id, 'Name' => $dd->Name, "FatherName" => $dd->FatherName, "BranchName" => $dd->BranchName);
        }
        echo '{"tags":' . json_encode($list) . '}';
    }

    function AccountToDebit() {
        $list = array();
        $b = Branch::getCurrentBranch()->id;
        //$q="select m.id AS ID, m.Name AS Name, m.PanNo AS PanNo, m.PhoneNos from jos_xmember m join jos_xagents a on a.member_id = m.id where(m.id='%".$this->input->post("term")."%' or m.Name Like '%".$this->input->post("term")."%' )";
        $q = "select a.*, s.Name, m.Name as MemberName from jos_xaccounts a join jos_xschemes s on a.schemes_id=s.id join jos_xbranch b on a.branch_id=b.id join jos_xmember m on a.member_id=m.id where(a.AccountNumber Like '%" . $this->input->post("term") . "%' AND (s.Name='Bank Accounts' OR s.Name='Cash Account' OR s.Name='Saving Account') or a.id Like '%" . $this->input->post("term") . "%' AND a.branch_id = $b and a.LockingStatus<>1 AND a.ActiveStatus<>0)";
        $result = $this->db->query($q)->result();
        foreach ($result as $dd) {
            $list[] = array('AccountNumber' => $dd->AccountNumber, 'MemberName' => $dd->MemberName);
        }
        echo '{"tags":' . json_encode($list) . '}';
    }

    function InterestToAccountnumber() {
        $list = array();
        //$q="select m.id AS ID, m.Name AS Name, m.PanNo AS PanNo, m.PhoneNos from jos_xmember m join jos_xagents a on a.member_id = m.id where(m.id='%".$this->input->post("term")."%' or m.Name Like '%".$this->input->post("term")."%' )";
        $q = "select a.*, m.Name AS Name, m.PanNo AS Pan, s.Name As Scheme from jos_xaccounts a left join jos_xbranch b on a.branch_id=b.id left join jos_xmember m on a.member_id=m.id left join jos_xschemes s on a.schemes_id=s.id where a.AccountNumber Like '%" . $this->input->post("term") . "%' OR a.id Like '%" . $this->input->post("term") . "%' AND (s.SchemeType='" . ACCOUNT_TYPE_BANK . "')";
        $result = $this->db->query($q)->result();
        foreach ($result as $dd) {
            $list[] = array('Name' => $dd->Name, 'AccountNumber' => $dd->AccountNumber, 'Scheme' => $dd->Scheme);
        }
        echo '{"tags":' . json_encode($list) . '}';
    }

    /**
     * Function generates the member details based on the member id passed as a parameter
     */
    function memberDetails() {
//        Staff::accessibleTo(USER);
        // $m = Doctrine::getTable("Member")->findOneById($id);
        $id = JRequest::getVar("id");
        $m = new Member();
        $m->where('id', $id)->get();
        if (!$m) {
            showError($id . ": ", "Oops Not Found");
            //$this->jq->flashMessages();
            return;
        }
        $msg = $m->PanNo;
        if ($msg == "")
            $msg = $m->PhoneNos;
        if ($msg == "")
            $msg = $m->CurrentAddress;
        $this->jq->addInfo($id . ": $m->Name", $msg);
        $this->jq->flashMessages(true);
    }

    /**
     * Function generates the details of the agent based on the agent id
     */
    function agentDetails($id) {
        $id = JRequest::getVar("aid");
        $a = new Agent();
        $a->where('member_id', $id)->get();
        if (!$a or $id == ' ') {
            showError($id . ": ", "No user or User is not Agent <font size='+1'><b>NO COMMISSION GRANTED</b></font>");
            $this->jq->flashMessages();
            return;
        }
        $m = $a->Member;
        $msg = $m->PanNo;
        if ($msg == "")
            $msg = $m->PhoneNos;
        if ($msg == "")
            $msg = $m->CurrentAddress;
        $this->jq->addInfo($id . ": $m->Name", $msg);
        $this->jq->flashMessages();
    }

    function accountsDetails($id) {
//        $id = JRequest::getVar("id");
        $a = $this->db->query("select a.id, a.AccountNumber,m.Name,DATE_ADD(a.created_at,INTERVAL s.MaturityPeriod MONTH) as MaturityDate, (a.CurrentBalanceCr - a.CurrentBalanceDr) as CurrentBalance from accounts a join member m on a.member_id=m.id join schemes s on a.schemes_id=s.id where (s.SchemeType='" . ACCOUNT_TYPE_BANK . "' or s.SchemeType='" . ACCOUNT_TYPE_FIXED . "' or s.SchemeType='" . ACCOUNT_TYPE_RECURRING . "') and a.branch_id=" . Branch::getCurrentBranch()->id . " and  a.member_id=" . $id . " and a.ActiveStatus=1 and a.LockingStatus=0")->result();
        if (!$a) {
            $this->jq->addError($id . ": ", "Oops Not Found");
            $this->jq->flashMessages();
            return;
        }
        $msg = "";
        foreach ($a as $acc) {
            $msg = $acc->MaturityDate . ":" . $acc->CurrentBalance . "<br/>";
            $this->jq->addInfo($acc->id . ":" . $acc->AccountNumber, $msg);
            $this->jq->flashMessages();
        }
    }

    function loanFromAccount() {
        $list = array();
        $b = Branch::getCurrentBranch();
        $q = $this->db->query("select a.*,m.Name as MemberName, s.Name from jos_xaccounts a join jos_xmember m on a.member_id = m.id join jos_xschemes s on a.schemes_id = s.id join jos_xbranch b on a.branch_id = b.id where a.AccountNumber Like '%" . $this->input->post("term") . "%' AND (s.Name='Bank Accounts' OR s.Name='Cash Account' OR s.Name='Saving Account' OR s.Name = '" . BRANCH_AND_DIVISIONS . "') AND b.id='$b->id' AND a.LockingStatus<>1 AND a.ActiveStatus<>0 limit 10")->result();
        foreach ($q as $dd) {
            $list[] = array('AccountNumber' => $dd->AccountNumber, 'MemberName' => $dd->MemberName);
        }
        echo '{"tags":' . json_encode($list) . '}';
    }

    function test() {
//        $Ac = new Account();
//        $Ac->where("AccountNumber","SB111")->get();
//        echo $Ac->scheme->SchemeType;
//            $path = "000.010";
//            $p = explode(".",$path);
//            $np = (end($p)+1);
//            $newpath = $path .".".str_repeat(0,strlen("000")-strlen($np)).$np;
//            echo $newpath;
        // Create alarm
//$alarm = new Alarm();
//
//// Get all alarms that have not been fired for one or more users
//$alarm->where_join_field('user', 'wasfired', FALSE)->get();
        $xc = new Scheme(40);
//            $defaultAccounts = explode(",", $xc->getKey("Default_Accounts"));
        $defaultAccounts = json_decode($xc->AgentSponsorCommission, true);
        echo "<pre>";
        print_r($defaultAccounts);
        echo "</pre>";
        echo '$defaultAccounts[0] => ' . $defaultAccounts[1] . "<br>";
        foreach ($defaultAccounts as $d) {

//            $key = array_keys($d[0]);
//            $key = $key[0];
//            $val = array_values($d[0]);
//            $val = $val[0];
//            echo $key . "=>" . $val . "<br />";
            echo $d . "<br>";
        }
    }

}

?>