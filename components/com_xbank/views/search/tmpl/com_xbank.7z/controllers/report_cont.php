<?php
class report_cont extends CI_Controller{

    function __construct() {
        parent::__construct();
    }

    function dashboard() {
        xDeveloperToolBars::getReportManagementToolBar();
        $this->load->view("report.html", $data);
        $this->jq->getHeader();
}
  /**
     * Function generates a generalized report of all balance sheet heads
     * Shows the Total debit and credit balances under a head.
     * Provides a link to {@link schemesLevelDisplay} on each head to view the schemes' details
     */
    function index() {
        //Staff::accessibleTo(USER);

        $arr = array();
        $Heads=new BalanceSheet();
        $Heads->get();
        //$Heads = Doctrine::getTable("BalanceSheet")->findAll();
        $HeadsToTake = array("Expenses", "Income");
        $i = 1;
        foreach ($Heads as $h) {
// 			if(!in_array($h->Head,$HeadsToTake)) continue;
            $TotalDR = 0;
            $TotalCR = 0;
            $Schemes=new Scheme();
            $Schemes->where('balance_sheet_id',$h->id)->get();
           // $Schemes = Doctrine::getTable("Schemes")->findByBalance_sheet_id($h->id);
            foreach ($Schemes as $s) {
                $Accounts=new Account();
                $Accounts->where('branch_id',Branch::getCurrentBranch()->id)->where('schemes_id',$s->id);
                //$Accounts = Doctrine::getTable("Accounts")->findByBranch_idAndSchemes_id(Branch::getCurrentBranch()->id, $s->id);
                foreach ($Accounts as $a) {
                    $TotalDR += ( $a->CurrentBalanceDr);
                    $TotalCR += ( $a->CurrentBalanceCr);
                }
            }
            $arr[] = array("Head_id" => $h->id, "Sno" => $i++, "Head" => $h->Head, "DR" => $TotalDR, "CR" => $TotalCR);
// 			$arr[] = array("Head_id"=>$h->id,"Head"=>$h->Head,"TotalDR"=>$TotalDR,"TotalCR"=>$TotalCR);
        }
        $data['results'] = $arr;
        $data['results'] = $arr;
//        $data['backURL'] = "";
        $data['contents'] = $this->load->view('pandl', $data, true);
        $this->load->view('template', $data);
    }

    /**
     *
     * @param <type> $Head
     * Function shows details of all schemes under a particular balance sheet head
     * Shows total debit and credit balance of all the accounts under each scheme
     * Provides a link to {@link accountLevelDisplay} on each scheme to view the accounts under a particulsr scheme
     */
    function schemesLevelDisplay($Head) {
       // Staff::accessibleTo(USER);

        $arr = array();
        $this->session->set_userdata("Head", $Head);
        $Head=new BalanceSheet();
        $Head->where('id',$Head)->get();
        //$Head->get_by_id($Head);
        //$Head = Doctrine::getTable("BalanceSheet")->find($Head);
        $Schemes=new Scheme();
        $Schemes->where('balance_sheet_id',$Head->id)->get();
        //$Schemes->get_by_balance_sheet_id($Head->id);
        //$Schemes = Doctrine::getTable("Schemes")->findByBalance_sheet_id($Head->id);
        $i = 1;
        foreach ($Schemes as $s) {
            $data['TotalDR'] = 0;
            $data['TotalCR'] = 0;
            $Accounts=new Account();
            $Accounts->where('branch_id',Branch::getCurrentBranch()->id)->where('schemes_id',$s->id);
            //$Accounts = Doctrine::getTable("Accounts")->findByBranch_idAndSchemes_id(Branch::getCurrentBranch()->id, $s->id);
            foreach ($Accounts as $a) {
                $data['TotalDR'] += ( $a->CurrentBalanceDr);
                $data['TotalCR'] += ( $a->CurrentBalanceCr);
            }
            $arr[] = array("Head_id" => $s->id, "Sno" => $i++, "Head" => $s->Name, "DR" => $TotalDR, "CR" => $TotalCR);
//			$arr[] = array("Head_id"=>$s->id,"Head"=>$s->Name,"TotalDR"=>$TotalDR,"TotalCR"=>$TotalCR);
        }

        $data['results'] = $arr;
//        $data['backURL'] = "index.php?//mod_pandl/pandl_cont";
// 		print_r($data['results']);
        $data['contents'] = $this->load->view('pandl_schemes', $data, true);
        $this->load->view('template', $data);
    }

    /**
     *
     * @param <type> $scheme
     * Function to show the details of all the accounts under a particular scheme
     * Provides a link to {@link accountTransactions} to show the transactions of each account
     */
    function accountLevelDisplay() {

        //Staff::accessibleTo(USER);
       $scheme = JRequest::getVar("id");
        $arr = array();
        $this->session->set_userdata("Scheme", $scheme);
// 		$Head=Doctrine::getTable("BalanceSheet")->find($Head);
// 		$Schemes=Doctrine::getTable("Schemes")->findByBalance_sheet_id($Head->id);
// 		foreach($Schemes as $s){
        $data['TotalDR'] = 0;
        $data['TotalCR'] = 0;
        $i = 1;
        $Accounts=new Account();
        $Accounts->where('branch_id',Branch::getCurrentBranch()->id)->where('schemes_id',$scheme)->get();
        //$Accounts = Doctrine::getTable("Accounts")->findByBranch_idAndSchemes_id(Branch::getCurrentBranch()->id, $scheme);
        foreach ($Accounts as $a) {
            $data['TotalDR'] += ( $a->CurrentBalanceDr);
            $data['TotalCR'] += ( $a->CurrentBalanceCr);
            $arr[] = array("Account" => $a->id, "Sno" => $i++, "Transaction" => $a->AccountNumber . " [ " . $a->Member->Name . " ] ", "DR" => $a->CurrentBalanceDr, "CR" => $a->CurrentBalanceCr);
//                                $arr[] = array("Head_id"=>$a->id,"Head"=>$a->AccountNumber,"TotalDR"=>$a->CurrentBalanceDr,"TotalCR"=>$a->CurrentBalanceCr);
        }
//			$arr[] = array("Head_id"=>$a->id,"Head"=>$a->AccountNumber,"TotalDR"=>$a->CurrentBalanceDr,"TotalCR"=>$a->CurrentBalanceCr);
// 		}

        $data['results'] = $arr;
        $data['forScheme'] = $scheme;
//        $data['backURL'] = "index.php?//mod_pandl/pandl_cont/schemesLevelDisplay/" . $this->session->userdata("Head");
// 		print_r($data['results']);
//        $data['contents'] = $this->load->view('pandl_accounts', $data, true);
//        $this->load->view('template', $data);
        JRequest::setVar("layout", "pandl_accounts");
             $this->load->view('report.html',$data);
             $this->jq->getHeader();

    }

    /**
     *
     * @param <type> $account
     * Function shows the transactions carried out on each account
     * Provides a link to {@link transactionDetails} on each transaction to show the details of each transaction
     */
    //function accountTransactions($account) {
    function accountTransactions() {
       // Staff::accessibleTo(USER);
        $account = JRequest::getVar("id");
        $arr = array();
        $this->session->set_userdata("Account", $account);
        //     $Transactions=Doctrine::getTable("Transactions")->findByAccounts_idOrAccounts_id_to($account,$account);
        //$Transactions = Doctrine::getTable("Transactions")->findByAccounts_id($account);
        $Transactions=new Transaction();
        $Transactions->where('accounts_id',$account)->get();
        //$Acc = Doctrine::getTable("Accounts")->find($account);
        $Acc=new Account();
        $Acc->where('id',$account)->get();
        $data['TotalDR'] = $Acc->OpeningBalanceDr;
        $data['TotalCR'] = $Acc->OpeningBalanceCr;
        $data['AccountNumber'] = $Acc->AccountNumber;
        $arr[] = array("VoucherNumber" => 0, "Date" => '', "Transaction" => "OPENNING BALANCE", "DR" => $Acc->OpeningBalanceDr, "CR" => $Acc->OpeningBalanceCr, "referenceAccount" => "");
        foreach ($Transactions as $t) {
//                if($t->accounts_id == $account){
//                  //  $dr=$t->amount;
//                    $dr=$t->amountDr;
//                    $cr=0;
//                }else{
//                 //   $cr=$t->amount;
//                    $cr=$t->amountCr;
//                    $dr=0;
//                }
            $dr = $t->amountDr;
            $cr = $t->amountCr;
            $data['TotalDR'] += $t->amountDr;
            $data['TotalCR'] += $t->amountCr;
            $refAcc=new Account();
            $refAcc->where('id',$t->reference_account)->get();
            //$refAcc = Doctrine::getTable("Accounts")->find($t->reference_account);
            $refAcc = ($refAcc == null) ? "" : $refAcc->AccountNumber;
            $arr[] = array("VoucherNumber" => $t->voucher_no, "Date" => $t->created_at, "Transaction" => $t->Narration, "DR" => $dr, "CR" => $cr, "referenceAccount" => $refAcc);
        }
        $data['results'] = $arr;
        $data['account'] = $account;
//        $data['backURL'] = "index.php?//mod_pandl/pandl_cont/accountLevelDisplay/" . $this->session->userdata("Scheme");
        JRequest::setVar("layout", "pandl_accountTransactions");
        $data['contents'] = $this->load->view('report.html',$data);
        //$data['contents'] = $this->load->view('pandl_accountTransactions', $data, true);
        echo "<div id='accTRansactiondiv'>" . $data['contents'] . "</div>";
        //$this->jq->getHeader(true, "accTRansactiondiv");
        $this->jq->getHeader();
//        $this->load->view('template', $data);
    }

    /**
     *
     * @param <type> $voucher
     * Function shows transaction details by accepting voucher number as a parameter
     */

    function transactionDetails() {
        //function transactionDetails($voucher, $foraccount) {
        //Staff::accessibleTo(USER);
        $voucher = JRequest::getVar("vn");
//        $foraccount = JRequest::getVar("id");
        $arr = array();
        $Transactions=new Transaction();
        $Transactions->where('voucher_no',$voucher)->where('branch_id',Branch::getCurrentBranch()->id)->get();
        //$Transactions = Doctrine::getTable("Transactions")->findByVoucher_noAndBranch_id($voucher, Branch::getCurrentBranch()->id);
        $i = 1;
        foreach ($Transactions as $t) {
            /** Find whether the transaction is one to many or many to one
             *
             */
//                  $q=Doctrine::getTable("Transactions")->createQuery()
//                            ->where("amountDr > 0 AND voucher_no = ? ",array($voucher))->execute();
//                  $DrCount=$q->count();
//            $amount = 0;
//            if ($t->amountDr > 0) {
//                $drAccount = Doctrine::getTable("Accounts")->find($t->accounts_id);
//                $dr = $drAccount->AccountNumber;
//                $amount = $t->amountDr;
//            } else {
//                $dr = "";
//
//                //  $amount=0;
//            }
//            if ($t->amountCr > 0) {
//                $crAccount = Doctrine::getTable("Accounts")->find($t->accounts_id);
//                $cr = $crAccount->AccountNumber;
//                $amount = $t->amountCr;
//            } else {
//                $cr = "";
//
//                //     $amount=0;
//            }
//                $drAccount=Doctrine::getTable("Accounts")->find($t->accounts_id);
//                $crAccount=Doctrine::getTable("Accounts")->find($t->accounts_id_to);
            //$account = Doctrine::getTable("Accounts")->find($t->accounts_id);
            $account=new Account($t->accounts_id);
//            $account->where('id',$t->accounts_id)->get();
            $data['accountID'] = $account->id;
            $arr[] = array("Sno" => $i++, "Voucher" => $t->voucher_no, "Account" => $account->AccountNumber, "DR" => $t->amountDr, "CR" => $t->amountCr);
        }
        $data['foraccount'] = $foraccount;
        $data['results'] = $arr;
//        $data['backURL'] = "index.php?//mod_pandl/pandl_cont/accountTransactions/" . $this->session->userdata("Account");
         JRequest::setVar("layout", "pandl_transactionDetails");
        $data['contents'] = $this->load->view('report.html',$data,true);
        //$data['contents'] = $this->load->view('pandl_transactionDetails', $data, true);
        echo "<div id='transactionDetailsDIV'>" . $data['contents'] . "</div>";
        //$this->jq->getHeader(true, "transactionDetailsDIV");
         $this->jq->getHeader();
//        $this->load->view('template', $data);
    }

    /**
     * <b>FORM</b> is created to generate Profit & Loss A/c
     * Sends the link to {@link pandl_report}
     */
    function pandlForm() {
        xDeveloperToolBars::onlyCancel("report_cont.dashboard", "cancel", "View PandL Reports");
        //Staff::accessibleTo(USER);
        //setInfo("PROFIT & LOSS ACCOUNT", "");
        $this->load->library("form");
        $form = $this->form->open("pandl", "index.php?option=com_xbank&task=report_cont.pandl_report")
                        ->setColumns(2)
                        ->dateBox("P & L From", "name='fromDate' class='input'")
                        ->dateBox("P & L till", "name='toDate' class='input'")
                        ->checkbox("Print To PDF", "name='printToPDF' value=1");
        if (Branch::getCurrentBranch()->Code == "DFL") {
            //                    $branchNames=$this->db->query("select Name from branch")->result();
            $form = $form->select("Select Branch", "name='BranchId'", Branch::getAllBranchNames())
                            ->_();
        } else {
            $b = Branch::getCurrentBranch()->id;
            $form = $form->hidden("", "name='BranchId' value='$b'");
        }
        $form = $form->submit("Go");
        $data['contents'] = $this->form->get();
        //JRequest::setVar('layout','pandl');
        $this->load->view('report.html', $data);
        $this->jq->getHeader();
    }

    /**
     * Actual Profit & Loss A/c is generated here
     *
     * STEPS
     * - Get income and expenses heads for P&L A/c
     * - Get all the schemes under each head
     * - Get the sum of credit and debit balance of accounts under each scheme
     * - Generate the Profit & Loss A/c
     */
    function pandl_report() {
        //Staff::accessibleTo(USER);
        xDeveloperToolBars::onlyCancel("report_cont.pandlForm", "cancel", "PandL Report : ".inp('fromDate'). " TO ". inp('toDate'));

        if (inp("toDate") < inp("fromDate")) {
           // showError("To date can't be less than From date");
            $error="To date can't be less than From date";
            re("report_cont.pandlForm",$error);

        }

        /*          $arr=array();
          $sc_arr=array();
          $Heads=Doctrine::getTable("BalanceSheet")->findAll();
          $HeadsToTake=array("Expenses","Income");
          $i=1;
          $where="";
          foreach($Heads as $h){
          if(!in_array($h->Head,$HeadsToTake)) continue;
          $TotalDR=0;
          $TotalCR=0;
          $Schemes=Doctrine::getTable("Schemes")->findByBalance_sheet_id($h->id);
          foreach($Schemes as $s){
          $arr=array();
          // 					$Accounts=Doctrine::getTable("Accounts")->findByBranch_idAndSchemes_id(Branch::getCurrentBranch()->id ,$s->id);
          $q="select * from accounts a where a.schemes_id=".$s->id." and a.updated_at between '".inp("fromDate")."' and '".inp("toDate")."' and a.ActiveStatus = 1";
          if(inp("BranchId")!="%")
          $where .=" and a.branch_id=".inp("BranchId");
          $q .=$where;
          $Accounts=$this->db->query($q)->result();
          foreach($Accounts as $a){
          $TotalDR = ($a->CurrentBalanceDr);
          $TotalCR = ($a->CurrentBalanceCr);
          $balance = abs($TotalCR - $TotalDR);// ($TotalDR - $TotalCR >= 0) ? ($TotalDR - $TotalCR) : ($TotalCR - $TotalDR);
          $AccountNumber = $a->AccountNumber;
          $arr[]=array("Account"=>$AccountNumber,"DR"=>$TotalDR,"CR"=>$TotalCR,"Balance"=>$balance);
          }
          $sc_arr +=array($s->Name => $arr);
          }

          }
         *
         */
//                $data['scheme']=$Schemes->Name;
        $balance = $this->pandlBalance(inp("fromDate"), inp("toDate"), inp("BranchId"), false);
        $data['pandlBalance'] = $balance;
        $data['results'] = $this->balanceSheetarray(inp("fromDate"), inp("toDate"), inp("BranchId"));

                        //$data['results']=$sc_arr;
        if (inp("printToPDF") == null) {
             JRequest::setVar("layout", "pandlreportshow");
             $this->load->view('report.html',$data);
            //$data['contents']=$this->load->view('report.html',$data);
            //JRequest::setVar("layout", "pandlreport");
            //$this->load->view('report.html', $data);
            $this->jq->getHeader();
            //$data['contents'] = $this->load->view('pandl_report', $data, true);
            //$this->load->view('template', $data);
        } else {
            JRequest::setVar("layout", "pandlreportshow");
             $this->load->view('report.pdf',$data);
        }
    }

    /**
     * <b>FORM</b> is created to generate a balance sheet
     * Sends the link to {@link balanceSheet}
     */
    function balanceSheetForm() {
        //Staff::accessibleTo(USER);
        //setInfo("BALANCE SHEET", "");
        xDeveloperToolBars::onlyCancel("report_cont.dashboard", "cancel", "View BalanceSheets");

        $this->load->library("form");
        $form = $this->form->open("balanceSheet", "index.php?option=com_xbank&task=report_cont.balanceSheet")
                        ->setColumns(2)
                        ->dateBox("Balance Sheet From", "name='fromDate' class='input'")
                        ->dateBox("Balance Sheet till", "name='toDate' class='input'")
                        ->checkbox("Print To PDF", "name='printToPDF' value=1");
        if (Branch::getCurrentBranch()->Code == "DFL") {
            //                    $branchNames=$this->db->query("select Name from branch")->result();
            $form = $form->select("Select Branch", "name='BranchId'", Branch::getAllBranchNames())
                            ->_();
        } else {
            $b = Branch::getCurrentBranch()->id;
            $form = $form->hidden("", "name='BranchId' value='$b'");
        }
        $form = $form->submit("Go");
        $data['contents'] = $this->form->get();
        //JRequest::setVar('layout','balancesheet');
        $this->load->view("report.html", $data);
        $this->jq->getHeader();
    }

    /**
     * Actual balance sheet is generated here
     *
     * STEPS
     * - Get all the heads for balance sheet
     * - Get all the schemes under each head
     * - Get the sum of credit and debit balance of accounts under each scheme
     * - Get the value of Profit & Loss A/c
     * - Generate the balance sheet
     */
    function balanceSheet() {
        //Staff::accessibleTo(USER);
        xDeveloperToolBars::onlyCancel("report_cont.balanceSheetForm", "cancel", "BalanceSheet ".inp('fromDate')." To ".inp('toDate'));

        if (inp("toDate") < inp("fromDate")) {
            $error="To date can't be less than From date";
            //setError("To date can't be less than From date", "");
            re("report_cont.balanceSheetForm",$error);
        }

        $this->session->set_userdata("fromdate", inp("fromDate"));
        $this->session->set_userdata("todate", inp("toDate"));
        $balance = $this->pandlBalance(inp("fromDate"), inp("toDate"), inp("BranchId"));
        $data['pandlBalance'] = $balance;
        $data['results'] = $this->balanceSheetarray(inp("fromDate"), inp("toDate"), inp("BranchId"));
//		$data['backURL']="";


        if (inp("printToPDF") == null) {
            JRequest::setVar("layout", "balancesheetview");
             $this->load->view('report.html',$data);
             $this->jq->getHeader();
//            $data['contents'] = $this->load->view('balancesheetview1', $data, true);
//            $this->load->view('template', $data);
        } else {
            JRequest::setVar("layout", "balancesheetview");
             $this->load->view('report.pdf',$data);
        }
    }

    function trialbalanceForm() {
      xDeveloperToolBars::onlyCancel("report_cont.dashboard", "cancel", "View Trial Balance ");

       // Staff::accessibleTo(USER);
        //setInfo("TRIAL BALANCE", "");
        $this->load->library("form");
        $form = $this->form->open("trialbalance", "index.php?option=com_xbank&task=report_cont.trialbalance")
                        ->setColumns(2)
                        ->dateBox("Trial Balance From", "name='fromDate' class='input'")
                        ->dateBox("Trial Balance Till", "name='toDate' class='input'")
                        ->checkbox("Print To PDF", "name='printToPDF' value=1");
        if (Branch::getCurrentBranch()->Code == "DFL") {
            //                    $branchNames=$this->db->query("select Name from branch")->result();
            $form = $form->select("Select Branch", "name='BranchId'", Branch::getAllBranchNames())
                            ->_();
        } else {
            $b = Branch::getCurrentBranch()->id;
            $form = $form->hidden("", "name='BranchId' value='$b'");
        }
        $form = $form->submit("Go");
        $data['contents'] = $this->form->get();
        $this->load->view("report.html", $data);
        $this->jq->getHeader();
    }

    function trialbalance() {
      xDeveloperToolBars::onlyCancel("report_cont.trialbalanceForm", "cancel", "Trial Balance ".inp('fromDate')." To ".inp('toDate'));

        //Staff::accessibleTo(USER);

        if (inp("toDate") < inp("fromDate")) {
            $error="To date can't be less than From date";
            re("report_cont.trialbalanceForm",$error);
        }

        $arr = array();
        $sc_arr = array();
        $Heads=new BalanceSheet();
        $Heads->get();
        //$Heads = Doctrine::getTable("BalanceSheet")->findAll();
        $HeadsToTake = array("Expenses", "Income");
        $i = 1;
        $where = "";
        foreach ($Heads as $h) {
            if (!in_array($h->Head, $HeadsToTake))
                continue;
            $TotalDR = 0;
            $TotalCR = 0;
            $Schemes=new Scheme();
            $Schemes->where('balance_sheet_id',$h->id)->get();
            //$Schemes->get_by_balance_sheet_id($h->id);
            //$Schemes = Doctrine::getTable("Schemes")->findByBalance_sheet_id($h->id);
            foreach ($Schemes as $s) {
                $arr = array();
// 					$Accounts=Doctrine::getTable("Accounts")->findByBranch_idAndSchemes_id(Branch::getCurrentBranch()->id ,$s->id);
                $q = "select * from jos_xaccounts a where a.schemes_id=" . $s->id . " and a.updated_at between '" . inp("fromDate") . "' and '" . inp("toDate") . "' and a.ActiveStatus = 1";
                if (inp("BranchId") != "%")
                    $where .=" and a.branch_id=" . inp("BranchId");
                $q .=$where;
                $Accounts = $this->db->query($q)->result();
                foreach ($Accounts as $a) {
                    $TotalDR = ($a->CurrentBalanceDr);
                    $TotalCR = ($a->CurrentBalanceCr);
                    $balance = ($TotalDR - $TotalCR >= 0) ? ($TotalDR - $TotalCR) : ($TotalCR - $TotalDR);
                    $AccountNumber = $a->AccountNumber;
                    $arr[] = array("Account" => $AccountNumber, "DR" => $TotalDR, "CR" => $TotalCR, "Balance" => $balance);
                }
                $sc_arr +=array($s->Name => $arr);
            }
        }


        foreach ($Heads as $h) {
            $arr = array();
            $Schemes=new Scheme();
            $Schemes->where('balance_sheet_id',$h->id)->get();
            //$Schemes = Doctrine::getTable("Schemes")->findByBalance_sheet_id($h->id);
            foreach ($Schemes as $s) {
                $TotalDR = 0;
                $TotalCR = 0;
                $where = "";

// 					$Accounts=Doctrine::getTable("Accounts")->findByBranch_idAndSchemes_id(Branch::getCurrentBranch()->id ,$s->id);
                $q = "select * from jos_xaccounts a where a.schemes_id=" . $s->id . " and a.updated_at between '" . inp("fromDate") . "' and '" . inp("toDate") . "' and a.ActiveStatus = 1";
                if (inp("BranchId") != "%")
                    $where .=" and a.branch_id=" . inp("BranchId");
                $q .=$where;
                $Accounts = $this->db->query($q)->result();
                foreach ($Accounts as $a) {
                    $TotalDR += ( $a->CurrentBalanceDr);
                    $TotalCR += ( $a->CurrentBalanceCr);
                }
                $arr[] = array("Head" => $h->Head, "SchemeName" => $s->Name, "DR" => $TotalDR, "CR" => $TotalCR);
            }
//                        $arr[]=array("Head_id"=>$h->id,"Sno"=>$i++,"Head"=>$h->Head,"DR"=>$TotalDR,"CR"=>$TotalCR);
// 			$arr[] = array("Head_id"=>$h->id,"Head"=>$h->Head,"TotalDR"=>$TotalDR,"TotalCR"=>$TotalCR);
            $sc_arr +=array($h->Head => $arr);
        }

//                $data['scheme']=$Schemes->Name;


        $data['results'] = $sc_arr;
        if (inp("printToPDF") == null) {
            JRequest::setVar("layout","trial_balance");
            $this->load->view("report.html",$data);
            $this->jq->getHeader();
//            $data['contents'] = $this->load->view('trial_balance', $data, true);
//            $this->load->view('template', $data);
        } else {
            JRequest::setVar("layout","trial_balance");
            $this->load->view("report.pdf",$data);
        }
    }

    function pandlBalance($dateFrom, $dateTo, $branch_id, $showOpeningBalance=true) {
        $pnlarr = $this->balanceSheetarray($dateFrom, $dateTo, $branch_id);
        $HeadExpense = "Expenses";
        $HeadIncome = "Income";
        $HeadsToTake = array("Expenses", "Income");
        $balanceIncome = 0;
        $balanceExpenses = 0;
        $balance = 0;

        foreach ($pnlarr as $head => $scheme) {

            if (!in_array($head, $HeadsToTake))
                continue;
            foreach ($scheme as $sc => $account) {
                $total = 0;
                if ($head == $HeadExpense) {
                    foreach ($account["Account"] as $acc) {
                        if ($showOpeningBalance === true)
                            $total += ( $acc['OpeningBalanceDr'] - $acc['OpeningBalanceCr']) + ($acc['Debit'] - $acc['Credit']);
                        else
                            $total += ( $acc['Debit'] - $acc['Credit']);
                    }
                    $balanceExpenses +=$total;
                }
                if ($head == $HeadIncome) {
                    foreach ($account["Account"] as $acc) {
                        if ($showOpeningBalance === true)
                            $total += ( $acc['OpeningBalanceCr'] - $acc['OpeningBalanceDr']) + ($acc['Credit'] - $acc['Debit']);
                        else
                            $total += ( $acc['Debit'] - $acc['Credit']);
                    }
                    $balanceIncome +=$total;
                }
            }
        }
        return abs($balanceIncome) - abs($balanceExpenses);
    }

    function balanceSheetarray($dateFrom, $dateTo, $branch_id) {
        //set_time_limit(5000);
        //Staff::accessibleTo(USER);

        if ($dateTo < $dateFrom) {
           $error="To date can't be less than From date";
            //setError("To date can't be less than From date", "");
            re("report_cont.balanceSheetForm",$error);
        }

        $arr = array();
        $acc_arr = array();
        $sc_arr = array();
//                $temparr=array();
        $Heads=new BalanceSheet();
        $Heads->get();
        //$Heads = Doctrine::getTable("BalanceSheet")->findAll();
        $i = 1;
        $balance = 0;
        $where = "";
        foreach ($Heads as $h) {
            $arr = array();
            $Schemes=new Scheme();
            $Schemes->where('balance_sheet_id',$h->id);
            $Schemes->get();
            //$Schemes = Doctrine::getTable("Schemes")->findByBalance_sheet_id($h->id);
            foreach ($Schemes as $s) {
                $TotalDR = 0;
                $TotalCR = 0;
                $where = "";
//                if ($s['id'] == 9) {
//                    $xysss = 234234;
//                }
                $acc_arr = array();

                $q = "select * from jos_xaccounts a where a.schemes_id=" . $s->id . " and (a.ActiveStatus = 1 or a.affectsBalanceSheet = 1)";
                if (inp("BranchId") != "%")
                    $where .=" and a.branch_id=" . $branch_id;
                $q .=$where;
                $Accounts = $this->db->query($q)->result();
                foreach ($Accounts as $a) {
                    $openingBalanceCr = $this->db->query("select sum(t.amountCr) as Balance from jos_xtransactions t where t.accounts_id = $a->id and t.created_at < '" . $dateFrom . "'")->row()->Balance;
                    $openingBalanceCr += $a->OpeningBalanceCr;
                    $openingBalanceDr = $this->db->query("select sum(t.amountDr) as Balance from jos_xtransactions t where t.accounts_id = $a->id and t.created_at < '" . $dateFrom . "'")->row()->Balance;
                    $openingBalanceDr += $a->OpeningBalanceDr;
                    $q = "select sum(t.amountDr) as Debit from jos_xtransactions t where t.accounts_id = $a->id and t.created_at between '" . $dateFrom . "' and DATE_ADD('" . $dateTo . "',INTERVAL +1 DAY) ";
                    $Debit = $this->db->query($q)->row()->Debit;
                    $q = "select  sum(t.amountCr) as Credit from jos_xtransactions t where t.accounts_id = $a->id and t.created_at between '" . $dateFrom . "' and DATE_ADD('" . $dateTo . "',INTERVAL +1 DAY) ";
                    $Credit = $this->db->query($q)->row()->Credit;
                    if (($Debit + $openingBalanceDr) == 0 and ($Credit + $openingBalanceCr) == 0)
                        continue;

                    $acc_arr[] = array("AccountNumber" => $a->AccountNumber, "Debit" => $Debit, "Credit" => $Credit, "OpeningBalanceCr" => $openingBalanceCr, "OpeningBalanceDr" => $openingBalanceDr, "AccountId" => $a->id);
                }
                $arr[] = array("SchemeName" => $s->Name, "SchemeId" => $s->id, "SchemeType" => $s->SchemeType, "Account" => $acc_arr);
            }
            $sc_arr +=array($h->Head => $arr);
        }
        return $sc_arr;


//                echo "<pre>";
//                print_r($temparr);
//                echo "</pre>";
    }

    function accountStatementForm() {
   xDeveloperToolBars::onlyCancel("report_cont.dashboard", "cancel", "View Account Statement");

        //Staff::accessibleTo(USER);
        $b = Branch::getCurrentBranch();
       // setInfo("ACCOUNT DETAILS", "");
        $this->load->library("form");
        $form = $this->form->open("accountdetails", "index.php?option=com_xbank&task=report_cont.accountStatement")
                        ->setColumns(2)
                //->lookupDB("Account number", "name='AccountNumber' class='input req-string'", "index.php?option=com_xbank&task=accounts_cont.AccountNumber&format=raw", array("a"=>"b"), array("AccountNumber"), "")

                        ->lookupDB("Account number : $b->Code - ", "name='AccountNumber' class='input req-string'", "index.php?option=com_xbank&task=report_cont.AccountNumber&format=raw", array("a"=>"b"), array("id", "AccountNumber","MName"), "AccountNumber")
                        ->dateBox("Transactions from", "name='fromDate' class='input'")
                        ->dateBox("Transactions till", "name='toDate' class='input'");
        $form = $form->submit("Go");
        $data['contents'] = $this->form->get();
        $this->load->view("report.html",$data);
        $this->jq->getHeader();
        //$this->load->view("template", $data);
    }

    function accountStatement() {

        xDeveloperToolBars::onlyCancel("report_cont.accountstatementform", "cancel", "Account Statement for ".inp('AccountNumber'));

        $trans_arr = array();
        $ac = new Account();
        //echo inp("AccountNumber");
        $ac->where('AccountNumber',inp("AccountNumber"))->get();
        //echo $ac->id;
        //$ac = Doctrine::getTable("Accounts")->find(inp("AccountNumber"));
        if (!$ac)
           return;
////        $t = Doctrine::getTable("Transactions")->findByAccounts_id(inp("AccountNumber"));
        if (inp("fromDate") && inp("toDate")) {

        $query=$this->db->query("select * from jos_xtransactions t where t.accounts_id =" . $ac->id . " and created_at between '".inp("fromDate")."' and DATE_ADD('".inp("toDate")."',INTERVAL +1 DAY) order by created_at")->result();
        //$query=$this->db->query("select * from jos_xtransactions t where t.accounts_id =" .$ac->id . "and created_at between '".inp("fromDate")."' and '".inp("toDate")."' order by created_at")->result();

///            $query = Doctrine_Query::create()
////                            ->select("*")
////                            ->from("Transactions")
////                            ->where("accounts_id = " . $ac->id." and created_at between '".inp("fromDate")."' and DATE_ADD('".inp("toDate")."', INTERVAL +1 DAY)")
////                            ->orderBy("created_at");
       } else {
//
        $query=$this->db->query("select * from jos_xtransactions t where t.accounts_id =" . $ac->id . " order by created_at")->result();
//
////            $query = Doctrine_Query::create()
////                            ->select("*")
////                            ->from("Transactions")
////                            ->where("accounts_id = " . $ac->id)
////                            ->orderBy("created_at");
       }
        //$t = $query->execute();

//                foreach ($trans as $tr){
//                    $t=Doctrine::getTable("Transactions")->findByVoucher_noAndBranch_id($tr->voucher_no,  Branch::getCurrentBranch()->id);
//                    $trans_arr[] =array("Date"=>$t->updated_at,"To"=>);
//                }

        $data['openingbalance'] = $ac->OpeningBalanceDr - $ac->OpeningBalanceCr;
        $data['transactions'] = $query;
        //$data['transactions'] = $t;
//                $msg="<table><th>Transaction Date</th><th>Narration</th><th>Debit</th><th>Credit</th>";
//                foreach($t as $t){
//                    $msg .="<tr><td>$t->updated_at</td><td>$t->Narration</td><td><center>".round($t->amountDr,2)."</center></td><td><center>".round($t->amountCr,2)."</center></td></tr>";
//                }
//                $msg .="</table>";
        JRequest::setVar("layout","accountstatement");
        $this->load->view("report.html",$data);
        $this->jq->getHeader();
//        $data['contents'] = $this->load->view("accountstatement", $data, true);
//        $this->load->view("template", $data);
    }

    function balancesheetcondensed() {
        $CI = & get_instance();
        $fromdate = $CI->session->userdata('fromdate');
        $todate = $CI->session->userdata('todate');
        $balance = $this->pandlBalance($fromdate, $todate, Branch::getCurrentBranch()->id);
        $data['pandlBalance'] = $balance;
        $data['results'] = $this->balanceSheetarray($fromdate, $todate, Branch::getCurrentBranch()->id);
        $data['contents'] = $this->load->view('balancesheetcondensed', $data, true);
        $this->load->view('template', $data);
    }

    function cashBookForm() {
       xDeveloperToolBars::onlyCancel("report_cont.AccountBook", "cancel", "View CashBooks");

       // Staff::accessibleTo(USER);
        //setInfo("CASH BOOK", "");
        $this->load->library("form");
        $form = $this->form->open("one", "index.php?option=com_xbank&task=report_cont.cashBook")
                        ->dateBox("Date From", "name='dateFrom' class='input'")
                        ->dateBox("Date To", "name='dateTo' class='input'")
                        ->checkbox("Print To PDF", "name='printToPDF' value=1")
                        ->submit("go");
        $data['contents'] = $this->form->get();
        //JRequest::setVar("layout","cashbookform");
        $this->load->view("report.html", $data);
        $this->jq->getHeader();
    }

    function cashBook() {
        //Staff::accessibleTo(USER);
         $b = Branch::getCurrentBranch()->id;
       xDeveloperToolBars::onlyCancel("report_cont.cashBookForm", "cancel", "CashBook of : ".inp('dateFrom')." TO  ".inp('dateTo'));

        $b = Branch::getCurrentBranch()->id;
        $result = $this->db->query("SELECT * FROM(
                                            SELECT
                                                            DRTransaction.created_at as `Date`,
                                                            CONCAT('TO  ', if(m.`Name` like '%Default%',a.AccountNumber,m.`Name`)) as Particulars,
                                                            DRTransaction.Narration as Narration,
                                                            DRTransaction.voucher_no as Voucher_no,
                                                            DRTransaction.amountDr AS Debit,
                                                            '' as Credit
                                            FROM
                                                    jos_xtransactions AS DRTransaction
                                            INNER JOIN jos_xtransactions AS CRTransaction ON DRTransaction.voucher_no = CRTransaction.voucher_no
                                            INNER JOIN jos_xaccounts ON DRTransaction.accounts_id = jos_xaccounts.id
                                            INNER JOIN jos_xaccounts a ON CRTransaction.accounts_id = a.id
                                            INNER JOIN jos_xmember m ON m.id = a.member_id
                                            INNER JOIN jos_xschemes ON jos_xaccounts.schemes_id = jos_xschemes.id
                                            WHERE
                                                    DRTransaction.branch_id = $b
                                            AND CRTransaction.branch_id = $b
                                            AND jos_xschemes.`Name` = '" . CASH_ACCOUNT_SCHEME . "'
                                            AND DRTransaction.amountDr = CRTransaction.amountCr
                                            AND DRTransaction.amountDr > 0
                                            And DRTransaction.created_at BETWEEN '" . inp("dateFrom") . "' AND '" . inp("dateTo") . "'

                                            UNION
                                                    SELECT
                                                            CRTransaction.created_at as `Date`,
                                                            CONCAT('BY  ', if(m.`Name` like '%Default%',a.AccountNumber,m.`Name`)) as Particulars,
                                                            CRTransaction.Narration as Narration,
                                                            CRTransaction.voucher_no as Voucher_no,
                                                            '' as Debit,
                                                            CRTransaction.amountCr as Credit

                                                    FROM
                                                            jos_xtransactions AS DRTransaction
                                                    INNER JOIN jos_xtransactions AS CRTransaction ON DRTransaction.voucher_no = CRTransaction.voucher_no
                                            INNER JOIN jos_xaccounts ON CRTransaction.accounts_id = jos_xaccounts.id
                                            INNER JOIN jos_xaccounts a ON DRTransaction.accounts_id = a.id
                                            INNER JOIN jos_xmember m ON m.id = a.member_id
                                            INNER JOIN jos_xschemes ON jos_xaccounts.schemes_id = jos_xschemes.id
                                            WHERE
                                                    DRTransaction.branch_id = $b
                                            AND CRTransaction.branch_id = $b
                                            AND jos_xschemes.`Name` = '" . CASH_ACCOUNT_SCHEME . "'
                                            AND DRTransaction.amountCr = CRTransaction.amountDr
                                            AND CRTransaction.amountCr > 0
                                            AND DRTransaction.created_at BETWEEN '" . inp("dateFrom") . "' AND '" . inp("dateTo") . "'

                                            UNION

                                                    SELECT
                                                            DRTransaction.created_at as `Date`,
                                                            CONCAT('TO  ', if(m.`Name` like '%Default%',jos_xaccounts.AccountNumber,m.`Name`)) as Particulars,
                                                            DRTransaction.Narration as Narration,
                                                            DRTransaction.voucher_no as Voucher_no,
                                                            '' as Debit,
                                                            CRTransaction.amountCr as Credit
                                                    FROM
                                                            jos_xtransactions AS DRTransaction
                                                    INNER JOIN jos_xtransactions AS CRTransaction ON CRTransaction.voucher_no = DRTransaction.voucher_no
                                            INNER JOIN jos_xaccounts ON DRTransaction.accounts_id = jos_xaccounts.id
                                            INNER JOIN jos_xmember m ON m.id = jos_xaccounts.member_id
                                            INNER JOIN jos_xschemes ON jos_xaccounts.schemes_id = jos_xschemes.id
                                            WHERE
                                                    DRTransaction.branch_id = $b
                                            AND CRTransaction.branch_id = $b
                                            AND jos_xschemes.`Name` = '" . CASH_ACCOUNT_SCHEME . "'
                                            AND DRTransaction.amountDr > 0
                                            AND CRTransaction.amountCr > DRTransaction.amountDr
                                            AND DRTransaction.transaction_type_id = (select DISTINCT(tt.id) from jos_xtransaction_type tt join jos_xtransactions t on tt.id=t.transaction_type_id where tt.`Transaction` = '" . TRA_JV_ENTRY . "')
                                            AND DRTransaction.created_at BETWEEN '" . inp("dateFrom") . "' AND '" . inp("dateTo") . "'
                                            )
                                            AS cashbook

                                            ORDER BY voucher_no")->result();
        $data['OpeningBalance'] = $this->db->query("select (a.OpeningBalanceDr - a.OpeningBalanceCr) as OpeningBalance from jos_xaccounts a join jos_xschemes s on s.id=a.schemes_id where s.`Name`='" . CASH_ACCOUNT_SCHEME . "' and a.branch_id=$b")->row()->OpeningBalance;
        $data['transactionOpeningBalance'] = $this->db->query("select IF((select(sum(t.amountDr) - sum(t.amountCr)) from jos_xtransactions t
                                                    join jos_xaccounts a on t.accounts_id=a.id
                                                    join jos_xschemes s on s.id=a.schemes_id
                                                    where s.`Name`='" . CASH_ACCOUNT_SCHEME . "' and t.branch_id=$b and t.created_at < '" . inp("dateFrom") . "') is NULL,0,(select(sum(t.amountDr) - sum(t.amountCr)) from jos_xtransactions t
                                                    join jos_xaccounts a on t.accounts_id=a.id
                                                    join jos_xschemes s on s.id=a.schemes_id
                                                    where s.`Name`='" . CASH_ACCOUNT_SCHEME . "' and t.branch_id=$b and t.created_at < '" . inp("dateFrom") . "')) as transactionOpeningBalance")->row()->transactionOpeningBalance;
        $data['keyandvalues'] = array("Date" => "Date", "Particulars" => "Particulars", "Narration" => "Vch Type", "Voucher_no" => "Vch Number", "Debit" => "Debit", "Credit" => "Credit");
        $data['results'] = $result;

        JRequest::setVar("layout","cashbook");
            $this->load->view("report.html",$data);
            $this->jq->getHeader();
//        if (inp("printToPDF") == null) {
//            //setInfo("CASH BOOK", "");
//            $this->load->library("form");
//            $form = $this->form->open("one", "index.php?option=com_xbank&task=report_cont.cashBook")
//                            ->dateBox("Date From", "name='dateFrom' class='input'")
//                            ->dateBox("Date To", "name='dateTo' class='input'")
//                            ->checkbox("Print To PDF", "name='printToPDF' value=1")
//                            ->submit("go");
//            $data['contents'] = $this->form->get();
//            JRequest::setVar("layout","cashbook");
//            $this->load->view("report.html",$data);
//            $this->jq->getHeader();
////            $this->load->view("template", $data);
////            $data['contents'] .= $this->load->view('cashbook', $data, true);
////            $this->load->view('template', $data);
//        } else {
//            $html = $this->load->view('cashbook', $data, true);
//            $this->load->plugin("to_pdf");
//            pdf_create($html, 'chequedata', true);
//        }
    }

    //function confirmTransactionDelete($voucherno, $foraccount=0) {
        function confirmTransactionDelete() {

        $voucherno = JRequest::getVar("vn");
        $foraccount=0;
        $transaction=new Transaction();
        $transaction->where('voucher_no',$voucherno)->where('branch_id',Branch::getCurrentBranch()->id)->get();
        //$transaction = Doctrine::getTable("Transactions")->findByVoucher_noAndBranch_id($voucherno, Branch::getCurrentBranch()->id);
        $msg = "";
        $debitbeforeAccount = array();
        $creditbeforeAccount = array();

        $debitTransaction = array();
        $creditTransaction = array();

        $debitafterAccount = array();
        $creditafterAccount = array();
        foreach ($transaction as $t) {
            $acc=new Account();
            $acc->where('id',$t->accounts_id)->get();
            //$acc = Doctrine::getTable("Accounts")->find($t->accounts_id);
            $debitbeforeAccount += array($acc->AccountNumber => $acc->CurrentBalanceDr);
            $creditbeforeAccount += array($acc->AccountNumber => $acc->CurrentBalanceCr);

            $debitTransaction += array($acc->AccountNumber => $t->amountDr);
            $creditTransaction += array($acc->AccountNumber => $t->amountCr);

            $debitafterAccount += array($acc->AccountNumber => ($acc->CurrentBalanceDr - $t->amountDr));
            $creditafterAccount += array($acc->AccountNumber => ($acc->CurrentBalanceCr - $t->amountCr));
        }
        $msg .= "<h3>Current Account Position</h3>";
        $msg .=formatDrCr($debitbeforeAccount, $creditbeforeAccount);

        $msg .= "<h3>Transaction to reverse</h3>";
        $msg .=formatDrCr($debitTransaction, $creditTransaction);

        $msg .= "<h3>Account Position after transaction deletion</h3>";
        $msg .=formatDrCr($debitafterAccount, $creditafterAccount);
        echo $msg;
        $html = "<form method='post' action='index.php?option=com_xbank&task=report_cont.TransactionDelete&vn=".$voucherno."&id=$foraccount'>";
        $html .="<table>";
        $html .="<input type='submit' value='DELETE' >";
        $html .="</form>";
//        echo $html;
//        $this->jq->getHeader();
        echo "<div id='transactionDeleteDIV'>" . $html . "</div>";
        $this->jq->getHeader(true, "transactionDeleteDIV");

    }

    //function TransactionDelete($voucherno, $foraccount) {
         function TransactionDelete() {

        //set_time_limit(5000);
        $voucherno=JRequest::getVar("vn");
        $foraccount=JRequest::getVar("id");
        $branchid = Branch::getCurrentBranch()->id;
        $closing=new Closing();
        $closing->where('branch_id', $branchid)->get();
        //$closing = Doctrine::getTable("Closings")->findOneByBranch_id($branchid);
        $transactions=new Transaction();
        $transactions->where('voucher_no',$voucherno)->where('branch_id',$branchid)->get();
        //$transactions = Doctrine::getTable("Transactions")->findByVoucher_noAndBranch_id($voucherno, $branchid);
        //$conn = Doctrine_Manager::connection();
        try {
           // $conn->beginTransaction();
            $this->db->trans_begin();
            foreach ($transactions as $t) {
                $acc=new Account();
                $acc->where('id',$t->accounts_id)->get();
                //$acc = Doctrine::getTable("Accounts")->find($t->accounts_id);
                include(xBANKSCHEMEPATH . "/" . strtolower($acc->Schemes->SchemeType) . "/" . strtolower($acc->Schemes->SchemeType) . "transactionbeforedeleted.php");
                include(xBANKSCHEMEPATH . "/" . strtolower($acc->Schemes->SchemeType) . "/" . strtolower($acc->Schemes->SchemeType) . "transactionafterdeleted.php");
                $this->db->query("delete from jos_xtransactions where id = $t->id");
                //$q = "delete from jos_xtransactions where id = $t->id";
                //executeQuery($q);
            }
             $this->db->trans_commit();
            //redirect("mod_pandl/pandl_cont/accountTransactions/$foraccount");
            re("report_cont.accountTransactions");
        } catch (Exception $e) {
            $this->db->trans_rollback();
            echo $e->getMessage();
            return;
        }
    }

    //function confirmTransactionEdit($voucherno, $foraccount=0) {
        function confirmTransactionEdit() {

        $voucherno = JRequest::getVar("vn");
        $foraccount=0;
        $transaction=new Transaction();
        $transaction->where('voucher_no',$voucherno)->where('branch_id',Branch::getCurrentBranch()->id)->get();
        //$transaction = Doctrine::getTable("Transactions")->findByVoucher_noAndBranch_id($voucherno, Branch::getCurrentBranch()->id);
        $html = "";
        $html .="<form method='post' action='index.php?option=com_xbank&task=report_cont.TransactionEdit&vn=".$voucherno."id=$foraccount'>";
        $html .="<table>";
        $html .="<th>Voucher No.</th><th>Date</th><th>Account Number</th><th>DR</th><th>CR</th>";
        $i = 1;
        foreach ($transaction as $t) {
            $html .="<tr>";
            $html .="<td>" . $t->voucher_no . "</td>";
            $html .="<td><input id='datepicker_$i' type='text' name='created_at_$i' value = ' $t->created_at '/></td>";
            $html .="<td>" . $t->Accounts->AccountNumber . "</td>";
            $html .= "<td><input type='text' name='DR_$i' value='$t->amountDr'></td>";
            $html .= "<td><input type='text' name='CR_$i' value='$t->amountCr'></td>";
            $html .="</tr>";
            $script = "$(function() {
                        $( '#datepicker_$i' ).datepicker({ dateFormat: 'yy-mm-dd',changeMonth: true, changeYear: true});
                });
                \n";
            $this->jq->addDomReadyScript($script);
            $i++;
        }

        $html .="</table>";
        $html .="<input type='submit' value='EDIT' >";
        $html .="</form>";
//        echo $html;
//        $this->jq->getHeader();
        echo "<div id='transactionEditDIV'>" . $html . "</div>";
        $this->jq->getHeader(true, "transactionEditDIV");
    }

    //function TransactionEdit($voucherno, $foraccount) {
         function TransactionEdit() {

        $voucherno=JRequest::getVar("vn");
        //$foraccount=JRequest::getVar("id");
        $transaction=new Transaction();
        $transaction->where('voucher_no',$voucherno)->where('branch_id',Branch::getCurrentBranch()->id)->get();
       // $transaction = Doctrine::getTable("Transactions")->findByVoucher_noAndBranch_id($voucherno, Branch::getCurrentBranch()->id);
        $i = 1;
        //$conn = Doctrine_Manager::connection();
        $DR = 0;
        $CR = 0;
        $flag = true;
        foreach ($transaction as $t) {
                $DR += $this->input->post("DR_$i");
                $CR += $this->input->post("CR_$i");
                if($this->input->post("created_at_$i") =='0000-00-00 00:00:00' || $this->input->post("created_at_$i") =="")
                        $flag = false;
                $i++;
        }
        if($DR != $CR || $flag == false){
            echo "<h2>WARNING : You have made either of the mistakes</h2>
                <br>Credit Balance should be equal to the debit balance for a transaction.<br>
                The date of transaction is not entered correctly.";
        }
        else{
        try {
             $this->db->trans_begin();
            $i = 1;
            foreach ($transaction as $t) {
                $account=new Account();
                $account->where('id',$t->accounts_id)->get();
                //$account = Doctrine::getTable("Accounts")->find($t->accounts_id);
                $account->CurrentBalanceDr = $account->CurrentBalanceDr - $t->amountDr + $this->input->post("DR_$i");
                $account->CurrentBalanceCr = $account->CurrentBalanceCr - $t->amountCr + $this->input->post("CR_$i");
                $account->save();
                $t->amountDr = $this->input->post("DR_$i");
                $t->amountCr = $this->input->post("CR_$i");
                $t->created_at = $this->input->post("created_at_$i") . " " . getNow("H:i:s");
                $t->save();
                $i++;
            }
            $this->db->trans_commit();
            re("report_cont.accountTransactions");
           // redirect("mod_pandl/pandl_cont/accountTransactions/$foraccount");
        } catch (Exception $e) {
            $this->db->trans_rollback();
            echo $e->getMessage();
            return;
        }
        }
    }

    function dayBookForm() {
        //Staff::accessibleTo(USER);
        //setInfo("DAY BOOK", "");
        xDeveloperToolBars::onlyCancel("report_cont.AccountBook", "cancel", "View DayBooks");

        $this->load->library("form");
        $form = $this->form->open("one", "index.php?option=com_xbank&task=report_cont.dayBook")
                        ->dateBox("Day Book For Date", "name='dateFrom' class='input'")
                        ->checkbox("Print To PDF", "name='printToPDF' value=1")
                        ->submit("go");
        $data['contents'] = $this->form->get();
        $this->load->view("report.html", $data);
        $this->jq->getHeader();
    }

    function dayBook() {
        //Staff::accessibleTo(USER);
        xDeveloperToolBars::onlyCancel("report_cont.dayBookForm", "cancel", "DayBook of :".inp('dateFrom'));

        $b = Branch::getCurrentBranch()->id;
        $result = $this->db->query("select t.Narration, t.amountDr, t.amountCr ,
                                    t.created_at, t.voucher_no, a.AccountNumber,
                                    a.CurrentBalanceCr, a.CurrentBalanceDr
                                    from jos_xtransactions t
                                    join jos_xaccounts a on t.accounts_id=a.id
                                    where t.branch_id=".$b."  and
                                    t.created_at like '".inp("dateFrom")."%'
                                    ORDER BY voucher_no")->result();
        $data['OpeningBalance'] = $this->db->query("select (a.OpeningBalanceDr - a.OpeningBalanceCr) as OpeningBalance from jos_xaccounts a join jos_xschemes s on s.id=a.schemes_id where s.`Name`='" . CASH_ACCOUNT_SCHEME . "' and a.branch_id=$b")->row()->OpeningBalance;
        $data['transactionOpeningBalance'] = $this->db->query("select IF((select(sum(t.amountDr) - sum(t.amountCr)) from jos_xtransactions t
                                                    join jos_xaccounts a on t.accounts_id=a.id
                                                    join jos_xschemes s on s.id=a.schemes_id
                                                    where s.`Name`='" . CASH_ACCOUNT_SCHEME . "' and t.branch_id=$b and t.created_at < '" . inp("dateFrom") . "') is NULL,0,(select(sum(t.amountDr) - sum(t.amountCr)) from jos_xtransactions t
                                                    join jos_xaccounts a on t.accounts_id=a.id
                                                    join jos_xschemes s on s.id=a.schemes_id
                                                    where s.`Name`='" . CASH_ACCOUNT_SCHEME . "' and t.branch_id=$b and t.created_at < '" . inp("dateFrom") . "')) as transactionOpeningBalance")->row()->transactionOpeningBalance;
        $data['keyandvalues'] = array( "Narration" => "Particulars", "voucher_no" => "Vch Number", "amountDr" => "Debit", "amountCr" => "Credit");
        $data['results'] = $result;
        JRequest::setVar("layout","daybook");
        $this->load->view("report.html",$data);
        $this->jq->getHeader();


//        if (inp("printToPDF") == null) {
//            setInfo("DAY BOOK", "");
//        $this->load->library("form");
//        $form = $this->form->open("one", "index.php?//mod_pandl/pandl_cont/dayBook")
//                        ->dateBox("Day Book For Date", "name='dateFrom' class='input'")
//                        ->checkbox("Print To PDF", "name='printToPDF' value=1")
//                        ->submit("go");
//            $data['contents'] = $this->form->get();
////            $this->load->view("template", $data);
//            $data['contents'] .= $this->load->view('daybook', $data, true);
//            $this->load->view('template', $data);
//        } else {
//            $html = $this->load->view('daybook', $data, true);
//            $this->load->plugin("to_pdf");
//            pdf_create($html, 'chequedata', true);
//        }
    }


     function loanInterestForm() {
        Staff::accessibleTo(USER);
        setInfo("INTEREST ON LOAN ACCOUNTS", "");
        $this->load->library("form");
        $form = $this->form->open("1", "index.php?//mod_pandl/pandl_cont/loanInterestReport")
                        ->setColumns(2)
                        ->dateBox("Interest From", "name='fromDate' class='input'")
                        ->dateBox("Interest till", "name='toDate' class='input'")
                        ->checkbox("Print To PDF", "name='printToPDF' value=1");
        if (Branch::getCurrentBranch()->Code == "DFL") {
            //                    $branchNames=$this->db->query("select Name from branch")->result();
            $form = $form->select("Select Branch", "name='BranchId'", Branch::getAllBranchNames())
                            ->_();
        } else {
            $b = Branch::getCurrentBranch()->id;
            $form = $form->hidden("", "name='BranchId' value='$b'");
        }
        $form = $form->submit("Go");
        $data['contents'] = $this->form->get();
        $this->load->view("template", $data);
    }

    function loanInterestReport(){
        $data['result'] = $this->db->query("select a.AccountNumber as accnum, ROUND((a.RdAmount * s.Interest * (s.NumberOfPremiums + 1)/1200)/s.NumberOfPremiums) as InterestAmount
                                from accounts a
                                join premiums p on a.id=p.accounts_id
                                join schemes s on s.id=a.schemes_id
                                where p.DueDate >= '".inp('fromDate')."'
                                and p.DueDate <= '".inp('toDate')."'
                                and s.SchemeType = '".ACCOUNT_TYPE_LOAN."'
                                and a.ActiveStatus=1
                                and a.branch_id = ".Branch::getCurrentBranch()->id);
         if (inp("printToPDF") == null) {

             Staff::accessibleTo(USER);
        setInfo("INTEREST ON LOAN ACCOUNTS", "");
        $this->load->library("form");
        $form = $this->form->open("1", "index.php?//mod_pandl/pandl_cont/loanInterestReport")
                        ->setColumns(2)
                        ->dateBox("Interest From", "name='fromDate' class='input'")
                        ->dateBox("Interest till", "name='toDate' class='input'")
                        ->checkbox("Print To PDF", "name='printToPDF' value=1");
        if (Branch::getCurrentBranch()->Code == "DFL") {
            //                    $branchNames=$this->db->query("select Name from branch")->result();
            $form = $form->select("Select Branch", "name='BranchId'", Branch::getAllBranchNames())
                            ->_();
        } else {
            $b = Branch::getCurrentBranch()->id;
            $form = $form->hidden("", "name='BranchId' value='$b'");
        }
        $form = $form->submit("Go");
        $data['contents'] = $this->form->get();


            $data['contents'] .= $this->load->view('loaninterestreport', $data, true);
            $this->load->view('template', $data);
        } else {
            $html = $this->load->view('loaninterestreport', $data, true);
            $this->load->plugin("to_pdf");
            pdf_create($html, 'chequedata', true);
        }

    }

       function AccountNumber()
       {
        $list = array();
        $b = Branch::getCurrentBranch()->id;
        //$q="select a.* from jos_xaccounts a join jos_xschemes s on a.schemes_id = s.id where a.AccountNumber Like '%". $this->input->post("term") . "%' or a.id like '%". $this->input->post("term")."%' limit 10 ";
       //array("select" => "a.*, m.Name as MName", "from" => "Accounts a", "leftJoin" => "a.Branch b", "innerJoin"=>"a.Member m", "where" => "a.AccountNumber Like '%\$term%'", "andWhere" => "b.id='$b->id'", "limit" => "10"), array("id", "AccountNumber","MName"), "id")
         $q="select a.*,m.Name as MName from jos_xaccounts a left join jos_xbranch b on a.branch_id=b.id inner join jos_xmember m on a.member_id=m.id where a.AccountNumber Like '%". $this->input->post("term") . "%' and (b.id='$b')limit 10";
        $result = $this->db->query($q)->result();
        foreach ($result as $dd) {
            $list[] = array('id'=>$dd->id,'AccountNumber' => $dd->AccountNumber,'MName'=>$dd->MName);
        }
        echo '{"tags":' . json_encode($list) . '}';
       }

       function AccountBook()
       {
        xDeveloperToolBars::getAccountbookManagementToolBar();
        $this->load->view("report.html", $data);
        $this->jq->getHeader();
       }
}

?>
