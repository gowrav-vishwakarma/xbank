<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
class test extends CI_Controller{
    function index(){
        JRequest::setVar("layout","test");
        $this->load->view("member.html");
        $this->jq->getHeader();
    }
}
?>
