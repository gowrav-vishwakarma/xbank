<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

$debitAccount = array(
    $debitToAccount => inp('Amount')
);
$creditAccount = array(
    $ac->AccountNumber => inp('Amount')
);
$msg .= formatDrCr($debitAccount, $creditAccount);
?>
