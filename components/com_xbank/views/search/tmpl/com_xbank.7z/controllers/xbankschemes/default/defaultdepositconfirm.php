<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
echo "DIPOSIT not supported for this account<br>falsefalse";
return;
?>
