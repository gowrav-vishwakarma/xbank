<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
function inp($key) {
    $CI = & get_instance();
    return (($CI->input->post($key) == "") ? $CI->input->get($key) : $CI->input->post($key));
}

function re($url, $msg="", $type="message") {
    xRedirect("index.php?option=com_xbank&task=" . $url, $msg, $type);
}

function showError($msg){
    echo $msg;
}

function getNow($format="Y-m-d H:i:00"){
		date_default_timezone_set('Asia/Calcutta');
		$timeStamp = strtotime('now');
		$timeStamp=date($format,$timeStamp);
//		return $timeStamp;
//		echo date_default_timezone_get();
                $CI=& get_instance();
                if($currDate=$CI->session->userdata('currdate')){
                    $currDate = strtotime($currDate);
                    $currDate = date($format,$currDate);
                    return $currDate;
                }
                else{
                    return $timeStamp;
                }


	}


        function my_date_diff($d1, $d2){
		$d1 = (is_string($d1) ? strtotime($d1) : $d1);
		$d2 = (is_string($d2) ? strtotime($d2) : $d2);

		$diff_secs = abs($d1 - $d2);
		$base_year = min(date("Y", $d1), date("Y", $d2));

		$diff = mktime(0, 0, $diff_secs, 1, 1, $base_year);
		return array(
		"years" => date("Y", $diff) - $base_year,
		"months_total" => (date("Y", $diff) - $base_year) * 12 + date("n", $diff) - 1,
		"months" => date("n", $diff) - 1,
		"days_total" => floor($diff_secs / (3600 * 24)),
		"days" => date("j", $diff) - 1,
		"hours_total" => floor($diff_secs / 3600),
		"hours" => date("G", $diff),
		"minutes_total" => floor($diff_secs / 60),
		"minutes" => (int) date("i", $diff),
		"seconds_total" => $diff_secs,
		"seconds" => (int) date("s", $diff)
		);

	}

        function myinclude($file){
            if(file_exists(strtolower($file)))
                include($file);


        }

        function getComission($CommissionString, $whatToGet,$PremiumNumber=-1){
            $CommissionString=trim($CommissionString," ");
            $CommissionString=trim($CommissionString,",");
            $commArray=explode(",",$CommissionString);
            $result=array();
            $result["isPercentage"]=false;
            if(strpos("%", $commArray[0]) !== false ){
                $result["isPercentage"]=true;
//                $commArray[0]=str_replace("%", "");
            }
            switch($whatToGet){
                case OPENNING_COMMISSION:
                    $result["Commission"]=trim($commArray[0]);

                    break;
                case PREMIUM_COMMISSION:
                    if(count($commArray)  <= 1){
                        throw new Exception("Premium must start from second Commission", "PREMIUM ERR");
                    }

                    if($PremiumNumber >= count($commArray)){
                        $commArray[$PremiumNumber]=$commArray[count($commArray)-1];
                    }

                    if(strpos("%", $commArray[$PremiumNumber]) !== false ){
                        $result["isPercentage"]=true;
//                        $commArray[$PremiumNumber]=str_replace("%", "");
                    }

                    $result["Commission"]=trim($commArray[$PremiumNumber]);
                    $result["isPercentage"]=true;
                    break;
            }

            return $result["Commission"];
        }


        function formatDrCr($DR,$CR){
            $html='<table width="100%" border="1">
                  <tr class="ui-widget-header">
                    <th colspan="2"><div align="center">Debit Acocunts</div></th>
                    <th colspan="2"><div align="center">Credit Accounts</div></th>
                  </tr>
                  <tr>
                    <th>Account</th>
                    <th>Amount</th>
                    <th>Account</th>
                    <th>Amount</th>
                  </tr>';
            $DRKeys=array_keys($DR);
            $DRVals=array_values($DR);

            $CRKeys=array_keys($CR);
            $CRVals=array_values($CR);
            for($i=0;$i< max(count($DR),count($CR));$i++){

             $html .='<tr class="ui-widget-contents">
                    <td>'.  ((isset($DRKeys[$i]))? $DRKeys[$i] : "&nbsp;") .'</td>
                    <td>'. ((isset($DRKeys[$i]))? $DRVals[$i] : "&nbsp;") .'</td>
                    <td>'.  ((isset($CRKeys[$i]))? $CRKeys[$i] : "&nbsp;") .'</td>
                    <td>'. ((isset($CRKeys[$i]))? $CRVals[$i] : "&nbsp;") .'</td>
                  </tr>';
            }
            $html .='</table>';
            return $html;
        }

          function printTable($records,$title){
            $ci = & get_instance();
            $ci->load->library("table");
            $ci->table->set_heading($title);

            foreach($records as $r){
                $ci->table->add_row(array_values($r));
            }

            return $ci->table->generate($data);
        }

        function makeoperator($val,$whatis=''){
		$val=trim($val);
		while(strpos($val,"  ")){
			$val=str_replace("  "," ",$val);
		}
		switch(substr($val,0,2)){
			case "= ":
				$val="= '" . trim(substr($val,strpos($val," "))) . "'";
				break;
			case "> ":
				$val="> '" . trim(substr($val,strpos($val," "))) . "'";
				break;
                        case "< ":
				$val="< '" . trim(substr($val,strpos($val," "))) . "'";
				break;
			case ">=":
				$val=">= '" . trim(substr($val,strpos($val," "))) . "'";
				break;
			case "<=":
				$val="<= '" . trim(substr($val,strpos($val," "))) . "'";
				break;
			case "<>":
				$val="<> '" . trim(substr($val,strpos($val," "))) . "'";
				break;
			case "li":
				$val="like '%" . trim(substr($val,strpos($val," "))) . "%'";
				break;
			case "no":
				$val="not like '%" . trim(substr($val,strpos($val," ",5))) . "%'";
				break;
			case "be":
				$val1=trim(substr($val,strpos($val," "),strpos($val," and")-strpos($val," ")));
				$val2=trim(substr($val,strpos($val,"and ")+4));
				$val="between '" . $val1 . "' AND '". $val2 ."' ";
				break;
		}
		if($whatis=='select'){
			$val=" like '". $val ."'";
		}
		return " ".$val;
	}

        function executeQuery($query){
            $CI = & get_instance();
            $CI->db->query($query);
        }

        function extractNumberFromString($str){
            $no =false;
            $len = strlen($str);
            for($i=0;$i<$len;$i++){
                if(substr($str, $i, 1) != 0){
                    if(!is_numeric(substr($str, $i, 1)))
                        continue;
                        $no = substr($str,$i);
                        break;
                }
            }
            return $no;
        }

        function extractPrefixFromString($str){
            $no ="";
            $len = strlen($str);
            for($i=0;$i<$len;$i++){
                  if(!is_numeric(substr($str, $i, 1))){
                        $no .= substr($str,$i,1);
                        continue;
                    }
                        break;
            }
            return $no;
        }

       
/* function to generate the next code,
 * $query returns the count of the numbers generated
 * $originalcode refers to the default code for the series
 */
        function getNextCode($originalcode,$query){
            $CI = & get_instance();
            global $com_params;
            $acc = $CI->db->query($query)->row();
//            $a = array_values($acc);
            foreach($acc as $a)
                $nos = $a;

            $newno = $nos + 1;
//            if(!is_numeric($originalcode)){
                $pr=substr($originalcode,'0',strlen($originalcode)- strlen($newno));
                $pr .= $newno;
//            }
//            else
//                $pr = $originalcode + $newno;
            return $pr;
        }

        function getPath($path,$LegCount=0){
//            $p = explode(".",$path);
            $np = ($LegCount+1);
            $newpath = $path .".".str_repeat(0,strlen("000")-strlen($np)).$np;
            return $newpath;
        }
?>
