<?php
class Documents_submitted extends DataMapper{
    var $table='xdocuments_submitted';
    var $has_one=array(
        'document'=>array(        
                'class'=>'document',
                'join_other_as'=>'document',
                'join_table'=>'jos_xdocuments_submitted',
                'other_field'=>'documents_submitted'
        ),
        'account'=>array(        
                'class'=>'account',
                'join_other_as'=>'account',
                'join_table'=>'jos_xdocuments_submitted',
                'other_field'=>'documents'
            )
        );
}
?>
