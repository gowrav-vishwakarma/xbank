<?php
class Log extends DataMapper{
    var $table='xlog';
     var $has_one = array(
            'branch'=>array(
                'class'=>'branch',
                'join_other_as'=>'branch',
                'join_table'=>'jos_xlog',
                'other_field'=>'logs'
                )
         );
}
             

?>