<?php

class Transaction extends DataMapper {

    var $table = "xtransactions";
    var $has_one = array(
        'bystaff' => array(
            'class' => 'staff',
            'join_other_as' => 'staff',
            'join_table' => 'jos_xtransactions',
            'other_field' => 'transactions'
        ),
        'branch' => array(
            'class' => 'branch',
            'join_other_as' => 'branch',
            'join_table' => 'jos_xtransactions',
            'other_field' => 'transactions'
        ),
        'account' => array(
            'class' => 'account',
            'join_other_as' => 'accounts',
            'join_table' => 'jos_xtransactions',
            'other_field' => 'transactions'
        ),
        'transaction_type' => array(
            'class' => 'transaction_type',
            'join_other_as' => 'transaction_type',
            'join_table' => 'jos_xtransactions',
            'other_field' => 'transactions'
        )
    );

    public static function getNewVoucherNumber() {
        $CI = & get_instance();
        $q = $CI->db->query("select MAX(t.voucher_no) AS maxVoucher from jos_xtransactions t where t.branch_id= " . Branch::getCurrentBranch()->id)->row();
        $voucherNo = $q->maxVoucher;
        $voucherNo++;
        return $voucherNo;
    }

    public static function doTransaction($DRs, $CRs, $remarks='', $type='', $voucherNo='', $transactionDate=false, $branchid=false, $onlyTRansactionSaving=false) 
                {
        if (count($DRs) > 1 and count($CRs) > 1) {
            echo "Some thing is wrong ..looks like wrong entry.. many to many posting";
            throw new Exception("array to array transaction is not allowed");
        }

// 			get new voucher bnumber if ommited
//        if(!DO_TRANSACTION)
//            throw new Exception("Transactions NOT allowed for the moment.");

        if (count($DRs) > 1)
            Transaction::doManyToOneTransaction_alt($DRs, $CRs, $remarks, $type, $voucherNo, $transactionDate, $branchid, $onlyTRansactionSaving);
        else
            Transaction::doOneToManyTransaction_alt($DRs, $CRs, $remarks, $type, $voucherNo, $transactionDate, $branchid, $onlyTRansactionSaving);
    }

    public static function doOneToManyTransaction_alt($DRs, $CRs, $remarks='', $type='', $voucherNo='', $transactionDate, $branchid, $onlyTRansactionSaving=false) {
        $CI = & get_instance();
        $DRAccountNumber = array_keys($DRs);
        if (!is_array($DRs) or !is_array($DRAccountNumber)) {
            $xxx = 10;
        }
        if (count($DRAccountNumber) == 0) {
            $xxx = 10;
        }
        $DRAccountNumber = $DRAccountNumber[0];
        $DRAmount = array_values($DRs);
        $DRAmount = $DRAmount[0];
        if ($branchid != false)
            $currentbranchid = $branchid;
        else
            $currentbranchid = Branch::getCurrentBranch()->id;

        $DRAccount = $CI->db->query("select a.id as aid ,s.id as sid ,s.SchemeType as SchemeType from jos_xaccounts a join jos_xschemes s on a.schemes_id=s.id where (a.AccountNumber= '" . $DRAccountNumber . "' or a.AccountNumber ='" . Branch::getCurrentBranch()->Code . SP . $DRAccountNumber . "') and a.branch_id = " . $currentbranchid)->row();
        $accid = $DRAccount->aid;

        // Save transaction only when DRAmount > 0
        if ($DRAmount > 0) {

            $reference_account = ((is_array($voucherNo)) ? ($voucherNo['referanceAccount'] == Null ? 'NULL' : $voucherNo['referanceAccount']) : 'NULL');
            $tT = $CI->db->query("select * from jos_xtransaction_type where Transaction= '" . $type . "'")->row();

////                      TODO- remove this runtime transaction creation from here
            if (!$tT) {
                $query = $CI->db->query("insert into jos_xtransaction_type (Transaction,FromAC,ToAC) values('$type','xxx','yyy')");
                $tT = $CI->db->query("select * from jos_xtransaction_type where Transaction= '" . $type . "'")->row();
            }
            if ($transactionDate !== false) {
                $created_at = $transactionDate; //date("Y-m-d", strtotime(date("Y-m-d", strtotime(getNow("Y-m-d"))) . " -1 day"));
                $updated_at = $transactionDate; //date("Y-m-d", strtotime(date("Y-m-d", strtotime(getNow("Y-m-d"))) . " -1 day"));
            } else {
                $created_at = getNow();
                $updated_at = getNow();
            }
            $voucher_no = (is_array($voucherNo)) ? $voucherNo['voucherNo'] : $voucherNo;
            $staff_id = Staff::getCurrentStaff()->id;
            $query = $CI->db->query("insert into jos_xtransactions
                                (accounts_id,transaction_type_id,staff_id,voucher_no,Narration,
                                amountDr,updated_at,created_at,branch_id,reference_account)
                                values($accid,$tT->id,$staff_id,$voucher_no,'$remarks',
                                $DRAmount,'$updated_at','$created_at',$currentbranchid,$reference_account)");

            if (!$onlyTRansactionSaving) {
                include(xBANKSCHEMEPATH . "/" . strtolower($DRAccount->SchemeType) . "/" . strtolower($DRAccount->SchemeType) . "accountbeforedebited.php");
//                $query = $CI->db->query("update jos_xaccounts set CurrentBalanceDr = CurrentBalanceDr + $DRAmount where id = $accid");
                $ac = new Account($accid);
                $ac->CurrentBalanceDr = $ac->CurrentBalanceDr + $DRAmount;
                $ac->save();
                include(xBANKSCHEMEPATH . "/" . strtolower($DRAccount->SchemeType) . "/" . strtolower($DRAccount->SchemeType) . "accountafterdebited.php");
            }
        }

        foreach ($CRs as $account => $amount) {
            if ($amount > 0) {
                $CRAccount = $CI->db->query("select a.id as aid,s.id as sid,s.SchemeType as SchemeType from jos_xaccounts a join jos_xschemes s on a.schemes_id=s.id where (a.AccountNumber='" . $account . "' or a.AccountNumber='" . Branch::getCurrentBranch()->Code . SP . $account . "') and a.branch_id = " . $currentbranchid)->row();
                $accid = $CRAccount->aid;
                $reference_account = ((is_array($voucherNo)) ? ($voucherNo['referanceAccount'] == Null ? 'NULL' : $voucherNo['referanceAccount']) : 'NULL');
                $tT = $CI->db->query("select * from jos_xtransaction_type where Transaction ='" . $type."'")->row();
////                      TODO- remove this runtime transaction creation from here
                if (!$tT) {
                    $query = $CI->db->query("insert into jos_xtransaction_type (Transaction,FromAC,ToAC) values('$type','xxx','yyy')");
                    $tT = $CI->db->query("select * from jos_xtransaction_type where Transaction ='" .$type."'")->row();
                }
                if ($transactionDate !== false) {
                    $created_at = $transactionDate; //date("Y-m-d", strtotime(date("Y-m-d", strtotime(getNow("Y-m-d"))) . " -1 day"));
                    $updated_at = $transactionDate; //date("Y-m-d", strtotime(date("Y-m-d", strtotime(getNow("Y-m-d"))) . " -1 day"));
                } else {
                    $created_at = getNow();
                    $updated_at = getNow();
                }
                $voucher_no = (is_array($voucherNo)) ? $voucherNo['voucherNo'] : $voucherNo;
                $staff_id = Staff::getCurrentStaff()->id;
                $query = $CI->db->query("insert into jos_xtransactions
                                (accounts_id,transaction_type_id,staff_id,voucher_no,Narration,
                                amountCr,updated_at,created_at,branch_id,reference_account)
                                values($accid,$tT->id,$staff_id,$voucher_no,'$remarks',
                                $amount,'$updated_at','$created_at',$currentbranchid,$reference_account)");

                if (!$onlyTRansactionSaving) {
                    include(xBANKSCHEMEPATH . "/" . strtolower($CRAccount->SchemeType) . "/" . strtolower($CRAccount->SchemeType) . "accountbeforecredited.php");
//                    $query =  $CI->db->query("update jos_xaccounts set CurrentBalanceCr = CurrentBalanceCr + $amount where id = $accid");
                    $ac = new Account($accid);
                    $ac->CurrentBalanceCr = $ac->CurrentBalanceCr + $amount;
                    $ac->save();
                    include(xBANKSCHEMEPATH . "/" . strtolower($CRAccount->SchemeType) . "/" . strtolower($CRAccount->SchemeType) . "accountaftercredited.php");
                }
            }
        }
    }

    public static function doManyToOneTransaction_alt($DRs, $CRs, $remarks='', $type='', $voucherNo='', $transactionDate, $branchid, $onlyTRansactionSaving=false) {
        $CI = & get_instance();
        $CRAccountNumber = array_keys($CRs);
        $CRAccountNumber = $CRAccountNumber[0];
        $CRAmount = array_values($CRs);
        $CRAmount = $CRAmount[0];

        if ($branchid != false)
            $currentbranchid = $branchid;
        else
            $currentbranchid = Branch::getCurrentBranch()->id;

        $CRAccount = Account::getAccountForCurrentBranch($CRAccountNumber);
        if ($CRAmount > 0) {

            $CRAccount = $CI->db->query("select a.id as aid,s.id as sid, s.SchemeType as SchemeType from jos_xaccounts a join jos_xschemes s on a.schemes_id=s.id where (a.AccountNumber=" . $CRAccountNumber . "or a.AccountNumber=" . Branch::getCurrentBranch()->Code . SP . $CRAccountNumber . ") and a.branch_id=" . $currentbranchid)->row();
            $accid = $CRAccount->aid;

            $Branch = Branch::getCurrentBranch()->id;
            $reference_account = ((is_array($voucherNo)) ? ($voucherNo['referanceAccount'] == Null ? 'NULL' : $voucherNo['referanceAccount']) : 'NULL');
            $tT = $CI->db->query("select * from jos_xtransaction_type where Transaction ='".$type."'")->row();
////                      TODO- remove this runtime transaction creation from here
            if (!$tT) {
                $query = "insert into jos_xtransaction_type (Transaction,FromAC,ToAC) values('$type','xxx','yyy')";
                executeQuery($query);
                $tT = $CI->db->query("select * from jos_xtransaction_type where Transaction ='" . $type."'")->row();
            }
//
            if ($transactionDate !== false) {
                $created_at = $transactionDate; //date("Y-m-d", strtotime(date("Y-m-d", strtotime(getNow("Y-m-d"))) . " -1 day"));
                $updated_at = $transactionDate; //date("Y-m-d", strtotime(date("Y-m-d", strtotime(getNow("Y-m-d"))) . " -1 day"));
            } else {
                $created_at = getNow();
                $updated_at = getNow();
            }
            $voucher_no = (is_array($voucherNo)) ? $voucherNo['voucherNo'] : $voucherNo;
            $staff_id = Staff::getCurrentStaff()->id;
            $query = "insert into jos_xtransactions
                                (accounts_id,transaction_type_id,staff_id,voucher_no,Narration,
                                amountCr,updated_at,created_at,branch_id,reference_account)
                                values($accid,$tT->id,$staff_id,$voucher_no,'$remarks',
                                $CRAmount,'$updated_at','$created_at',$currentbranchid,$reference_account)";
            executeQuery($query);

            if (!$onlyTRansactionSaving) {
                include(xBANKSCHEMEPATH . "/" . strtolower($CRAccount->SchemeType) . "/" . strtolower($CRAccount->SchemeType) . "accountbeforecredited.php");
//                $query = "update jos_xaccounts set CurrentBalanceCr = CurrentBalanceCr + $CRAmount where id = $accid";
                $ac = new Account($accid);
                $ac->CurrentBalanceCr = $ac->CurrentBalanceCr + $CRAmount;
                $ac->save();
                executeQuery($query);
                include(xBANKSCHEMEPATH . "/" . strtolower($CRAccount->SchemeType) . "/" . strtolower($CRAccount->SchemeType) . "accountaftercredited.php");
            }
        }
        foreach ($DRs as $account => $amount) {
            if ($amount > 0) {
                $DRAccount = $CI->db->query("select a.id as aid,s.id as sid, s.SchemeType as SchemeType from jos_xaccounts a join jos_xschemes s on a.schemes_id=s.id where(a.AccountNumber=" . $account . "or a.AccountNumber=" . Branch::getCurrentBranch()->Code . SP . $account . ")and a.branch_id=" . $currentbranchid)->row();
                $accid = $DRAccount->aid;

                // Save transaction only when DRAmount > 0
//                $Branch = Branch::getCurrentBranch()->id;
                $reference_account = ((is_array($voucherNo)) ? ($voucherNo['referanceAccount'] == Null ? 'NULL' : $voucherNo['referanceAccount']) : 'NULL');
                $tT = $CI->db->query("select * from jos_xtransaction_type where Transaction ='".$type."'")->row();
////                      TODO- remove this runtime transaction creation from here
                if ($tT) {
                    $query = "insert into jos_xtransaction_type (Transaction,FromAC,ToAC) values('$type','xxx','yyy')";
                    executeQuery($query);
                    $tT = $this->db->query("select * from jos_xtransaction_type where Transaction ='" . $type."'")->row();
                }
                if ($transactionDate !== false) {
                    $created_at = $transactionDate; //date("Y-m-d", strtotime(date("Y-m-d", strtotime(getNow("Y-m-d"))) . " -1 day"));
                    $updated_at = $transactionDate; //date("Y-m-d", strtotime(date("Y-m-d", strtotime(getNow("Y-m-d"))) . " -1 day"));
                } else {
                    $created_at = getNow();
                    $updated_at = getNow();
                }
                $voucher_no = (is_array($voucherNo)) ? $voucherNo['voucherNo'] : $voucherNo;
                $staff_id = Staff::getCurrentStaff()->id;
                $query = "insert into jos_xtransactions
                                (accounts_id,transaction_type_id,staff_id,voucher_no,Narration,
                                amountDr,updated_at,created_at,branch_id,reference_account)
                                values($accid,$tT->id,$staff_id,$voucher_no,'$remarks',
                                $amount,'$updated_at','$created_at',$currentbranchid,$reference_account)";
                executeQuery($query);

                if (!$onlyTRansactionSaving) {
                    include(xBANKSCHEMEPATH . "/" . strtolower($DRAccount->SchemeType) . "/" . strtolower($DRAccount->SchemeType) . "accountbeforedebited.php");
//                    $query = "update jos_xaccounts set CurrentBalanceDr = CurrentBalanceDr + $amount where id = $accid";
                    $ac = new Account($accid);
                    $ac->CurrentBalanceDr = $ac->CurrentBalanceDr + $amount;
                    $ac->save();
                    executeQuery($query);
                    include(xBANKSCHEMEPATH . "/" . strtolower($DRAccount->SchemeType) . "/" . strtolower($DRAccount->SchemeType) . "accountafterdebited.php");
                }
            }
        }
    }

}

?>
