<?php
echo $contents;
?>