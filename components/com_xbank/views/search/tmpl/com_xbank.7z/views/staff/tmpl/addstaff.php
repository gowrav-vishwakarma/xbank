<?php
echo $contents;
?>
