<!--<script type="text/javascript" src="assets/common.js"/>-->
<?php
echo $contents;

?>
