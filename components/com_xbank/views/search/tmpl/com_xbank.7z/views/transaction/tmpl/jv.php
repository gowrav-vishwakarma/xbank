<?php
$this->load->library("formcomponents");
$branch=Branch::getCurrentBranch()->id;
$this->formcomponents->open("frm1","index.php?option=com_xbank&task=transaction_cont.doJV");
?>
<table width="100%" border="0">
  <tr>
    <th colspan="2">Debit</th>
    <th colspan="2">Credit</th>
  </tr>
  <tr>
    <td><div align="center">Account</div></td>
    <td><div align="center">Amount</div></td>
    <td><div align="center">Account</div></td>
    <td><div align="center">Amount</div></td>
  </tr>
  <tr>
    <td><?php $this->formcomponents->lookupDB("AccountNumber","name='DRAccount_1' class='input  req-string ui-autocomplete-input'","index.php?option=com_xbank&task=transaction_cont.lookupForJV&format=raw",
 			array("a"=>"b"),array("AccountNumber","Name","PanNo","Scheme"),"AccountNumber");?></td>
    <td><?php $this->formcomponents->text("Amount","name='dramount_1' class='input req-string req-numeric'");?></td>
    <td><?php $this->formcomponents->lookupDB("AccountNumber","name='CRAccount_1' class='input  req-string ui-autocomplete-input'","index.php?option=com_xbank&task=transaction_cont.lookupForJV&format=raw",
 			array("a"=>"b"),array("AccountNumber","Name","PanNo","Scheme"),"AccountNumber");?></td>
    <td><?php $this->formcomponents->text("Amount","name='cramount_1' class='input req-string req-numeric'");?></td>
  </tr>
   <tr>
    <td><?php $this->formcomponents->lookupDB("AccountNumber","name='DRAccount_2' class='input ui-autocomplete-input'","index.php?option=com_xbank&task=transaction_cont.lookupForJV&format=raw",
 			array("a"=>"b"),array("AccountNumber","Name","PanNo","Scheme"),"AccountNumber");?></td>
    <td><?php $this->formcomponents->text("Amount","name='dramount_2' class='input'");?></td>
    <td><?php $this->formcomponents->lookupDB("AccountNumber","name='CRAccount_2' class='input  ui-autocomplete-input'","index.php?option=com_xbank&task=transaction_cont.lookupForJV&format=raw",
 			array("a"=>"b"),array("AccountNumber","Name","PanNo","Scheme"),"AccountNumber");?></td>
    <td><?php $this->formcomponents->text("Amount","name='cramount_2' class='input'");?></td>
  </tr>
   <tr>
    <td><?php $this->formcomponents->lookupDB("AccountNumber","name='DRAccount_3' class='input  ui-autocomplete-input'","index.php?option=com_xbank&task=transaction_cont.lookupForJV&format=raw",
 			array("a"=>"b"),array("AccountNumber","Name","PanNo","Scheme"),"AccountNumber");?></td>
    <td><?php $this->formcomponents->text("Amount","name='dramount_3' class='input'");?></td>
    <td><?php $this->formcomponents->lookupDB("AccountNumber","name='CRAccount_3' class='input  ui-autocomplete-input'","index.php?option=com_xbank&task=transaction_cont.lookupForJV&format=raw",
 			array("a"=>"b"),array("AccountNumber","Name","PanNo","Scheme"),"AccountNumber");?></td>
    <td><?php $this->formcomponents->text("Amount","name='cramount_3' class='input'");?></td>
  </tr>
   <tr>
    <td><?php $this->formcomponents->lookupDB("AccountNumber","name='DRAccount_4' class='input ui-autocomplete-input'","index.php?option=com_xbank&task=transaction_cont.lookupForJV&format=raw",
 			array("a"=>"b"),array("AccountNumber","Name","PanNo","Scheme"),"AccountNumber");?></td>
    <td><?php $this->formcomponents->text("Amount","name='dramount_4' class='input'");?></td>
    <td><?php $this->formcomponents->lookupDB("AccountNumber","name='CRAccount_4' class='input  ui-autocomplete-input'","index.php?option=com_xbank&task=transaction_cont.lookupForJV&format=raw",
 			array("a"=>"b"),array("AccountNumber","Name","PanNo","Scheme"),"AccountNumber");?></td>
    <td><?php $this->formcomponents->text("Amount","name='cramount_4' class='input'");?></td>
  </tr>
   <tr>
    <td><?php $this->formcomponents->lookupDB("AccountNumber","name='DRAccount_5' class='input ui-autocomplete-input'","index.php?option=com_xbank&task=transaction_cont.lookupForJV&format=raw",
 			array("a"=>"b"),array("AccountNumber","Name","PanNo","Scheme"),"AccountNumber");?></td>
    <td><?php $this->formcomponents->text("Amount","name='dramount_5' class='input'");?></td>
    <td><?php $this->formcomponents->lookupDB("AccountNumber","name='CRAccount_5' class='input  ui-autocomplete-input'","index.php?option=com_xbank&task=transaction_cont.lookupForJV&format=raw",
 			array("a"=>"b"),array("AccountNumber","Name","PanNo","Scheme"),"AccountNumber");?></td>
    <td><?php $this->formcomponents->text("Amount","name='cramount_5' class='input'");?></td>
  </tr>
   <tr>
     <td colspan="2"><?php $this->formcomponents->textArea("Narration","name='Naration' rows=5 cols=50");?></td>
     <td><?php
	     $this->formcomponents->submit("Doit");
	 ?></td>
     <td><?php
	     $this->formcomponents->confirmButton("Confirm","The following transaction is about to happen","index.php?option=com_xbank&task=transaction_cont.checkJV&format=raw",true);
	 ?></td>
   </tr>
</table>
<?php
	$this->formcomponents->close();
?>